<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MabaController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\InformasiController;
use App\Http\Controllers\AsalSekolahController;
use App\Http\Controllers\PromoController;
use App\Http\Controllers\KelasController;
use App\Http\Controllers\ProdiController;
use App\Http\Controllers\VerifdaftarController;
use App\Http\Controllers\VerifregisController;
use App\Http\Controllers\ProvinsiController;
use App\Http\Controllers\KabupatenController;
use App\Http\Controllers\KecamatanController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BayarController;
use App\Http\Controllers\DataDiriController;
use App\Http\Controllers\OrangTuaController;
use App\Http\Controllers\RiwayatPendidikanController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\BayarRegisController;

// Halaman Utama
Route::get('/', [MabaController::class, 'index'])->name('beranda');
Route::get('/informasi', [MabaController::class, 'informasi'])->name('informasi');
Route::get('/kontak', [MabaController::class, 'kontak'])->name('kontak');

// Login & Password
Route::get('/login', [MabaController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'prosesLogin'])->name('login.proses');
Route::get('/logout', function () {
    session()->flush();
    return redirect()->route('login');
})->name('logout');

//password
Route::get('/lupa-password', [MabaController::class, 'lupaPassword'])->name('lupa.password');
Route::get('/password-baru', [MabaController::class, 'passwordBaru'])->name('password.baru');

//Lupa Password
Route::post('/lupa-password', [AuthController::class, 'cariEmail'])->name('lupa.password.proses');
Route::get('/reset-password/{token}', [MabaController::class, 'formResetPassword'])->name('reset.password.form');
Route::post('/reset-password', [AuthController::class, 'prosesResetPassword'])->name('reset.password.proses');

// Dashboard Mahasiswa Baru
Route::get('/dashboard', [MabaController::class, 'dashboard'])->name('maba.dashboard');

// Formulir Pendaftaran Mahasiswa Baru
Route::prefix('daftar')->group(function () {
    Route::get('/akun', [MabaController::class, 'buatAkun'])->name('form.akun');
    Route::post('/akun', [AuthController::class, 'prosesDaftar'])->name('form.akun.post');
    Route::get('/data-diri', [DataDiriController::class, 'create'])->name('form.data_diri');
    Route::get('/data-orangtua', [MabaController::class, 'dataOrangtua'])->name('form.data_orangtua');
    Route::get('/data-sekolah', [MabaController::class, 'dataSekolah'])->name('form.data_sekolah');
    Route::get('/pembayaran', [BayarController::class, 'create'])->name('form.pembayaran');
    Route::post('/pembayaran', [BayarController::class, 'store'])->name('form.pembayaran.store');
    Route::get('/registrasi', [BayarRegisController::class, 'create'])->name('form.registrasi');
    Route::post('/registrasi', [BayarRegisController::class, 'store'])->name('form.registrasi.store');
});

Route::get('/promo/cek/{kode}', [PromoController::class, 'cekKode']);
Route::get('/bukti-bayar-regis/{id}', [BayarRegisController::class, 'lihatBukti'])->name('bukti.bayarregis.lihat');
Route::get('/bukti-bayar/{id}', [VerifdaftarController::class, 'lihatBukti'])->name('bukti.bayar.lihat');



//Form Datadiri
Route::post('/form/data-diri/store', [DataDiriController::class, 'store'])->name('form.data-diri.store');
Route::prefix('admin')->group(function () {
    Route::get('/index', [AdminController::class, 'index'])->name('admin.index');
    //keuangan
    Route::get('/keuangan/pendaftaran', [AdminController::class, 'keuanganPendaftaran'])->name('admin.keuangan.pendaftaran');
    Route::get('/keuangan/registrasi', [AdminController::class, 'keuanganRegistrasi'])->name('admin.keuangan.registrasi');
});

//
Route::get('/get-kabupaten/{provinsi_id}', [DataDiriController::class, 'getKabupaten']);
Route::get('/get-kecamatan/{kabupaten_id}', [DataDiriController::class, 'getKecamatan']);

//Form Orang tua
Route::get('/daftar/data-orangtua', [OrangTuaController::class, 'create'])->name('form.data_orangtua');
Route::post('/form/data-orangtua/store', [OrangTuaController::class, 'store'])->name('form.data_orangtua.store');


//form asal sekolah
Route::get('/daftar/asal-sekolah', [RiwayatPendidikanController::class, 'create'])->name('form.asal_sekolah.create');
Route::post('/daftar/asal-sekolah', [RiwayatPendidikanController::class, 'store'])->name('form.asal_sekolah.store');

// Informasi
Route::prefix('informasi')->group(function () {
    Route::get('/index', [InformasiController::class, 'index']);
    Route::delete('/index/{id}', [InformasiController::class, 'destroy']);
    Route::get('/create', [InformasiController::class, 'create']);
    Route::post('/create', [InformasiController::class, 'store']);
    Route::get('/edit/{id}', [InformasiController::class, 'edit']);
    Route::put('/edit/{id}', [InformasiController::class, 'update']);
    Route::get('/show/{id}', [InformasiController::class, 'show']);
});
Route::get('/maba/informasi', [InformasiController::class, 'listForMaba'])->name('maba.informasi');

// Asal Sekolah
Route::prefix('asalsekolah')->group(function () {
    Route::get('/index', [AsalSekolahController::class, 'index']);
    Route::delete('/index/{id}', [AsalSekolahController::class, 'destroy']);
    Route::get('/create', [AsalSekolahController::class, 'create']);
    Route::post('/create', [AsalSekolahController::class, 'store']);
    Route::get('/edit/{id}', [AsalSekolahController::class, 'edit']);
    Route::put('/edit/{id}', [AsalSekolahController::class, 'update']);
    Route::get('/show/{id}', [AsalSekolahController::class, 'show']);
});

// Promo
Route::prefix('promo')->group(function () {
    Route::get('/index', [PromoController::class, 'index']);
    Route::delete('/index/{id}', [PromoController::class, 'destroy']);
    Route::get('/create', [PromoController::class, 'create']);
    Route::post('/create', [PromoController::class, 'store']);
    Route::get('/edit/{id}', [PromoController::class, 'edit']);
    Route::put('/edit/{id}', [PromoController::class, 'update']);
    Route::get('/show/{id}', [PromoController::class, 'show']);
    Route::get('/check-promo', [PromoController::class, 'check']);
});

// Prodi
Route::prefix('prodi')->group(function () {
    Route::get('/index', [ProdiController::class, 'index']);
    Route::delete('/index/{id}', [ProdiController::class, 'destroy']);
    Route::get('/create', [ProdiController::class, 'create']);
    Route::post('/create', [ProdiController::class, 'store']);
    Route::get('/edit/{id}', [ProdiController::class, 'edit']);
    Route::put('/edit/{id}', [ProdiController::class, 'update']);
    Route::get('/show/{id}', [ProdiController::class, 'show']);
});

// Kelas
Route::prefix('kelas')->group(function () {
    Route::get('/index', [KelasController::class, 'index']);
    Route::delete('/index/{id}', [KelasController::class, 'destroy']);
    Route::get('/create', [KelasController::class, 'create']);
    Route::post('/create', [KelasController::class, 'store']);
    Route::get('/edit/{id}', [KelasController::class, 'edit']);
    Route::put('/edit/{id}', [KelasController::class, 'update']);
    Route::get('/show/{id}', [KelasController::class, 'show']);
});

//user
Route::prefix('user')->group(function () {
    Route::get('/index', [UserController::class, 'index'])->name('user.index');
    Route::get('/create', [UserController::class, 'create'])->name('user.create');
    Route::post('/create', [UserController::class, 'store'])->name('user.store');
    Route::get('/edit/{id}', [UserController::class, 'edit'])->name('user.edit');
    Route::put('/edit/{id}', [UserController::class, 'update'])->name('user.update');
    Route::delete('/index/{id}', [UserController::class, 'destroy'])->name('user.destroy');
    Route::get('/show/{id}', [UserController::class, 'show'])->name('user.show');
});

// Kabupaten
Route::prefix('kabupaten')->group(function () {
    Route::get('/index', [KabupatenController::class, 'index']);
    Route::delete('/index/{id}', [KabupatenController::class, 'destroy']);
    Route::get('/create', [KabupatenController::class, 'create']);
    Route::post('/create', [KabupatenController::class, 'store']);
    Route::get('/edit/{id}', [KabupatenController::class, 'edit']);
    Route::put('/edit/{id}', [KabupatenController::class, 'update']);
    Route::get('/show/{id}', [KabupatenController::class, 'show']);
});

// Kecamatan
Route::prefix('kecamatan')->group(function () {
    Route::get('/index', [KecamatanController::class, 'index']);
    Route::delete('/index/{id}', [KecamatanController::class, 'destroy']);
    Route::get('/create', [KecamatanController::class, 'create']);
    Route::post('/create', [KecamatanController::class, 'store']);
    Route::get('/edit/{id}', [KecamatanController::class, 'edit']);
    Route::put('/edit/{id}', [KecamatanController::class, 'update']);
    Route::get('/show/{id}', [KecamatanController::class, 'show']);
});

//provinsi
Route::prefix('provinsi')->group(function () {
    Route::get('/index', [ProvinsiController::class, 'index']);
    Route::delete('/index/{id}', [ProvinsiController::class, 'destroy']);
    Route::get('/create', [ProvinsiController::class, 'create']);
    Route::post('/create', [ProvinsiController::class, 'store']);
    Route::get('/edit/{id}', [ProvinsiController::class, 'edit']);
    Route::put('/edit/{id}', [ProvinsiController::class, 'update']);
    Route::get('/show/{id}', [ProvinsiController::class, 'show']);
});


//verifikasi daftar
Route::prefix('verifdaftar')->group(function () {
    Route::get('/index', [VerifdaftarController::class, 'index'])->name('verifdaftar.index');
    Route::get('/edit/{id}', [VerifdaftarController::class, 'edit'])->name('verifdaftar.edit');
    Route::put('/update/{id}', [VerifdaftarController::class, 'update'])->name('verifdaftar.update');
    Route::get('/show/{id}', [VerifdaftarController::class, 'show'])->name('verifdaftar.show');
    Route::get('/lihat-bukti/{id}', [VerifdaftarController::class, 'lihatBukti'])->name('verifdaftar.lihatBukti');
    Route::get('/bukti/{id}', [VerifdaftarController::class, 'lihatBukti'])->name('bukti.bayar.lihat');
    Route::delete('{id}', [VerifdaftarController::class, 'destroy']);
    Route::post('/verifikasi/{id}', [VerifDaftarController::class, 'verifikasi']);
});

//verifikasi regis
Route::prefix('verifregis')->group(function () {
    Route::get('/index', [VerifregisController::class, 'index'])->name('verifregis.index');
    Route::get('/lihat-bukti/{id}', [VerifregisController::class, 'lihatBukti'])->name('verifregis.lihatBukti');
    Route::post('/verifikasi/{id}', [VerifregisController::class, 'verifikasi']);
    Route::delete('/{id}', [VerifregisController::class, 'destroy']);
    Route::get('/edit/{id}', [VerifregisController::class, 'edit'])->name('verifregis.edit'); // opsional
    Route::get('/show/{id}', [VerifregisController::class, 'show'])->name('verifregis.show'); // opsional
    Route::put('/{id}', [VerifregisController::class, 'update'])->name('verifregis.update');
    Route::post('/verifikasi/{id}', [VerifregisController::class, 'verifikasi']);

});


    Route::put('/verifregis/{calon}', [VerifregisController::class, 'update'])->name('verifregis.update');


//halaman Dasboard
Route::get('/admin/index', [DashboardController::class, 'index'])->name('admin.index');

Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
