<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    html, body {
      height: 100vh;
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', sans-serif;
      overflow: hidden;
      background-color: #fff;
    }

    /* Lingkaran Dekoratif */
    .circle-bottom-left,
    .circle-top-right {
      position: absolute;
      border-radius: 50%;
      z-index: 0;
    }

    .circle-bottom-left {
      position: fixed;
      width: 800px;
      height: 800px;
      bottom: -300px;
      left: -250px;
      background: radial-gradient(circle at center, #019BA4, #004168);
      z-index: 0;
    }

    .brand-ambassador {
      position: fixed;
      bottom: 0;
      left: 30px;
      z-index: 2;
      height: 600px;
      max-height: 90vh;
    }

    .circle-top-right {
      position: fixed;
      width: 300px;
      height: 300px;
      background: radial-gradient(circle at center, #019BA4, #004168);
      top: -100px;
      right: -100px;
    }

    /* Header */
    .header {
      padding: 10px 16px;
      position: relative;
      z-index: 3;
    }

    .header h1 {
      font-size: 1.8rem;
      font-weight: 700;
      color: #004168;
      margin: 0;
    }

    .header p {
      font-size: 1.2rem;
      color: #004168;
      margin: 0;
    }

    /* Login Card - Updated to match registration form */
    .login-card {
      background-color: white;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.1);
      max-width: 500px;
      width: 100%;
      position: relative;
      z-index: 3;
      margin-right: 100px;
      margin-bottom: 100px;
    }

    .login-card h3 {
      text-align: center;
      font-weight: bold;
      margin-bottom: 30px;
      font-size: 28px;
      color: #004168;
    }

    /* Form styling to match registration */
    .form-label {
      font-weight: 600;
      color: #333;
      margin-bottom: 8px;
      font-size: 14px;
    }

    .form-control {
      border: 2px solid #e9ecef;
      border-radius: 10px;
      padding: 12px 16px;
      font-size: 14px;
      transition: all 0.3s ease;
      height: 48px;
    }

    .form-control:focus {
      border-color: #019BA4;
      box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.15);
      outline: none;
    }

    .input-group .form-control {
      border-right: none;
      border-top-right-radius: 0;
      border-bottom-right-radius: 0;
    }

    .btn-eye {
      background: none;
      border: 2px solid #e9ecef;
      border-left: none;
      border-top-left-radius: 0;
      border-bottom-left-radius: 0;
      border-top-right-radius: 10px;
      border-bottom-right-radius: 10px;
      padding: 0 12px;
      cursor: pointer;
      color: #6c757d;
      transition: all 0.3s ease;
    }

    .btn-eye:hover {
      color: #019BA4;
      border-color: #019BA4;
    }

    .input-group:focus-within .btn-eye {
      border-color: #019BA4;
    }

    .btn-primary {
      background: linear-gradient(135deg, #004168 0%, #019BA4 100%);
      color: white;
      border: none;
      padding: 15px 40px;
      border-radius: 12px;
      font-weight: 700;
      font-size: 16px;
      width: 100%;
      transition: all 0.3s ease;
    }

    .btn-primary:hover {
      color: white;
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.2);
    }

    /* .form-link a {
      color: #004168;
      text-decoration: none;
      font-weight: 500;
    }

    .form-link a:hover {
      text-decoration: underline;
      color: #019BA4;
    } */

    .link-collor {
      text-decoration: none;
      color: #004168;
;
    }

    .form-container {
      height: calc(100vh - 80px);
      display: flex;
      justify-content: flex-end;
      align-items: center;
      padding-right: 40px;
      position: relative;
      z-index: 3;
    }



    /* Responsive Design */
    @media (max-width: 992px) {
      .brand-ambassador {
        height: 450px;
        left: 10px;
      }

      .login-card {
        max-width: 450px;
        padding: 35px;
      }

      .circle-bottom-left {
        width: 600px;
        height: 600px;
        bottom: -250px;
        left: -250px;
      }
    }

    @media (max-width: 768px) {
      .form-container {
        justify-content: center;
        padding: 20px;
      }

      .login-card {
        margin-right: 0;
        max-width: 100%;
        padding: 25px 20px;
      }

      .login-card h3 {
        font-size: 24px;
        margin-bottom: 25px;
      }

      .circle-bottom-left {
        width: 400px;
        height: 400px;
        bottom: -150px;
        left: -150px;
      }

      .circle-top-right {
        width: 200px;
        height: 200px;
        top: -75px;
        right: -75px;
      }

      .brand-ambassador {
        height: 350px;
        left: 10px;
      }

      .header h1 {
        font-size: 1.5rem;
      }

      .header p {
        font-size: 1rem;
      }


    }

    @media (max-width: 576px) {
      .circle-bottom-left {
        width: 300px;
        height: 300px;
        bottom: -100px;
        left: -100px;
      }

      .circle-top-right {
        width: 150px;
        height: 150px;
        top: -50px;
        right: -50px;
      }

      .brand-ambassador {
        height: 280px;
        left: 5px;
      }

      .login-card {
        padding: 20px 15px;
        margin-bottom: 100px;
        border-radius: 10px;
      }

      .login-card h3 {
        font-size: 20px;
        margin-bottom: 20px;
      }

      .header {
        padding: 10px;
      }

      .form-control {
        font-size: 16px;
        height: 44px;
        padding: 10px 14px;
      }

      .btn-primary {
        font-size: 14px;
        padding: 12px 25px;
      }

      .form-label {
        font-size: 13px;
      }

    }
  </style>
</head>
<body>

  <!-- Dekorasi Lingkaran -->
  <div class="circle-bottom-left"></div>
  <div class="circle-top-right"></div>

  <!-- Gambar Brand Ambassador -->
  <!-- <img src="2.png" alt="Brand Ambassador" class="brand-ambassador img-fluid"> -->

  <!-- Header -->
<div class="header d-flex align-items-center">
  <img src="{{ asset('storage/foto/PoliteknikLP3I.png') }}" alt="Logo" class="img-fluid me-3" style="width: 50px; height: auto;">
  <div>
    <h1>Selamat Datang</h1>
    <p>Calon Mahasiswa!</p>
  </div>
</div>

  <!-- Form Login -->
  <div class="form-container">
    <div class="login-card">
      <h3 class="text-center fw-bold mb-4">Log In</h3>

<form id="loginForm" method="POST" action="{{ route('login.proses') }}" novalidate>
  @csrf

  <div class="mb-3">
    <label for="username" class="form-label">Username</label>
    <input type="text" class="form-control @error('username') is-invalid @enderror" name="username" id="username" placeholder="Masukkan username" required>
    <div class="invalid-feedback">Username tidak boleh kosong.</div>
    @error('username')
      <div class="text-danger">{{ $message }}</div>
    @enderror
  </div>

  <div class="mb-3">
    <label for="password" class="form-label">Password</label>
    <div class="input-group">
      <input type="password" class="form-control @error('password') is-invalid @enderror" name="password" id="password" placeholder="Masukkan password" required>
      <button type="button" class="btn-eye" onclick="togglePassword()" tabindex="-1">
        <i class="fas fa-eye-slash" id="toggleIcon"></i>
      </button>
    </div>
    <div class="invalid-feedback">Password tidak boleh kosong.</div>
    @error('password')
      <div class="text-danger">{{ $message }}</div>
    @enderror
  </div>

  @if ($errors->has('loginError'))
    <div class="text-danger mb-3">{{ $errors->first('loginError') }}</div>
  @endif

  <div class="mb-3 text-end">
    <a href="{{ route('lupa.password') }}" class="link-collor">Forgot Password?</a>
  </div>

  <div class="d-grid">
    <button type="submit" class="btn btn-primary">
      <i class="fas fa-sign-in-alt me-2"></i> Log In
    </button>
  </div>
</form>


<div class="mt-3 text-center">
  <small>
    Belum Punya Akun?
    <a href="{{ route('form.akun') }}" class="link-collor">Daftar Akun disini!</a>
  </small>
</div>
</form>

</div>
</div>

<script>
  function togglePassword() {
    const passwordInput = document.getElementById("password");
    const toggleIcon = document.getElementById("toggleIcon");

    if (passwordInput.type === "password") {
      passwordInput.type = "text";
      toggleIcon.classList.remove("fa-eye-slash");
      toggleIcon.classList.add("fa-eye");
    } else {
      passwordInput.type = "password";
      toggleIcon.classList.remove("fa-eye");
      toggleIcon.classList.add("fa-eye-slash");
    }
  }
</script>


</body>
</html>
