<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Form Asal Sekolah</title>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
      rel="stylesheet"
    />
    <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      body {
        background: linear-gradient(to right, #019ba4, #004168) top,
          #ffffff bottom;
        background-repeat: no-repeat;
        background-size: 100% 33.33%, 100% 66.67%;
        background-position: top, bottom;
        min-height: 100vh;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
          sans-serif;
      }

      .container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 40px 20px;
      }

      .form-container {
        background-color: #ffffff;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        margin-top: 60px;
      }

      .form-title {
        text-align: center;
        font-weight: bold;
        margin-bottom: 40px;
        font-size: 28px;
        color: #004168;
      }

      .section-title {
        font-size: 18px;
        font-weight: 600;
        color: #019ba4;
        margin-bottom: 20px;
        padding-bottom: 8px;
        border-bottom: 2px solid #e9ecef;
      }

      .form-label {
        font-weight: 600;
        color: #333;
        margin-bottom: 8px;
        font-size: 14px;
      }

      .form-control,
      .form-select {
        border: 2px solid #e9ecef;
        border-radius: 10px;
        padding: 12px 16px;
        font-size: 14px;
        transition: all 0.3s ease;
        height: 48px;
      }

      .form-control:focus,
      .form-select:focus {
        border-color: #019ba4;
        box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.15);
        outline: none;
      }

      textarea.form-control {
        height: 100px;
        resize: vertical;
      }

      /* School Search Dropdown Styles */
      .school-search-container {
        position: relative;
      }

      .school-search-input {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m1 1 6 6-6 6'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 12px center;
        background-size: 16px;
        padding-right: 40px;
      }

      .school-dropdown {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        border: 2px solid #019ba4;
        border-top: none;
        border-radius: 0 0 10px 10px;
        max-height: 300px;
        overflow-y: auto;
        z-index: 1000;
        display: none;
      }

      .school-dropdown.show {
        display: block;
      }

      .school-option {
        padding: 12px 16px;
        cursor: pointer;
        border-bottom: 1px solid #f1f3f4;
        transition: background-color 0.2s;
      }

      .school-option:hover,
      .school-option.highlighted {
        background-color: #f8fdff;
      }

      .school-option:last-child {
        border-bottom: none;
      }

      .school-name {
        font-weight: 600;
        color: #333;
        margin-bottom: 4px;
      }

      .school-address {
        font-size: 12px;
        color: #6c757d;
      }

      .school-type {
        font-size: 11px;
        color: #019ba4;
        font-weight: 500;
        text-transform: uppercase;
      }

      .loading-spinner {
        display: none;
        position: absolute;
        right: 45px;
        top: 50%;
        transform: translateY(-50%);
        color: #019ba4;
      }

      .no-results {
        padding: 20px;
        text-align: center;
        color: #6c757d;
        font-style: italic;
      }

      .btn-submit {
        background: linear-gradient(135deg, #004168 0%, #019ba4 100%);
        color: white;
        border: none;
        padding: 15px 40px;
        border-radius: 12px;
        font-weight: 700;
        font-size: 16px;
        margin-top: 30px;
        transition: all 0.3s ease;
        width: 100%;
      }

      .btn-submit:hover {
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
      }

      .upload-area {
        border: 2px dashed #019ba4;
        border-radius: 10px;
        padding: 40px;
        text-align: center;
        background: #f8fdff;
        transition: all 0.3s ease;
        cursor: pointer;
        margin-top: 10px;
      }

      .upload-area:hover {
        background: #e3f8ff;
        border-color: #004168;
      }

      .upload-area.drag-over {
        background: #e3f8ff;
        border-color: #004168;
        transform: scale(1.02);
      }

      .upload-icon {
        font-size: 48px;
        color: #019ba4;
        margin-bottom: 15px;
      }

      .upload-text {
        color: #019ba4;
        font-weight: 600;
        font-size: 16px;
        margin-bottom: 5px;
      }

      .upload-subtext {
        color: #6c757d;
        font-size: 14px;
      }

      .file-input {
        display: none;
      }

      .uploaded-file {
        background: #e8f5e8;
        border: 1px solid #4caf50;
        border-radius: 8px;
        padding: 15px;
        margin-top: 10px;
        display: none;
      }

      .uploaded-file.show {
        display: block;
      }

      .file-info {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }

      .file-details {
        display: flex;
        align-items: center;
      }

      .file-icon {
        color: #4caf50;
        font-size: 20px;
        margin-right: 10px;
      }

      .file-name {
        font-weight: 600;
        color: #2e7d32;
      }

      .file-size {
        color: #6c757d;
        font-size: 12px;
        margin-left: 10px;
      }

      .remove-file {
        background: none;
        border: none;
        color: #dc3545;
        cursor: pointer;
        font-size: 16px;
      }

      .alert {
        border: none;
        border-radius: 10px;
        padding: 15px 20px;
      }

      .alert-success {
        background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
        color: #155724;
      }

      .alert-warning {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
        color: #856404;
      }

              .info-card {
            background: linear-gradient(135deg, #f8fdff 0%, #e8f8f9 100%);
            border: 1px solid #019BA4;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .info-card .info-title {
            color: #004168;
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 10px;
        }

        .info-card .info-text {
            color: #019BA4;
            font-size: 14px;
            line-height: 1.5;
        }

      /* Responsive Design */
      @media (max-width: 768px) {
        .container {
          padding: 20px 15px;
        }

        .form-container {
          padding: 25px 20px;
          margin-top: 30px;
          border-radius: 12px;
        }

        .form-title {
          font-size: 24px;
          margin-bottom: 30px;
        }

        .school-dropdown {
          max-height: 250px;
        }

        .school-option {
          padding: 10px 12px;
        }
      }

      @media (max-width: 576px) {
        .form-container {
          padding: 20px 15px;
          margin-top: 20px;
        }

        .form-title {
          font-size: 22px;
        }

        .school-dropdown {
          max-height: 200px;
        }
      }
    </style>
  </head>
  <body>
    <div class="container">
       <!-- Alert container for warnings -->
      <div id="alertContainer" style="display: none;">
        <div class="alert alert-danger" role="alert">
          <strong><i class="fas fa-exclamation-triangle me-2"></i>Peringatan!</strong>
          <span id="alertMessage">Mohon lengkapi semua field yang wajib diisi sebelum melanjutkan ke halaman berikutnya.</span>
        </div>
      </div>

      <div class="form-container">
        <h2 class="form-title">Asal Sekolah</h2>
                    <div class="info-card">
                <div class="info-title">
                    <i class="fas fa-info-circle me-2"></i>Informasi Pengisian Data
                </div>
                <div class="info-text">
                    Lengkapi semua data dengan benar sesuai dokumen resmi. Pastikan foto yang diupload jelas dan data yang dimasukkan valid.
                </div>
            </div>

<form id="schoolForm" method="POST" action="{{ route('form.asal_sekolah.store') }}" enctype="multipart/form-data">
    @csrf
    <div class="row g-4">
        <div class="col-12">
            {{-- NISN --}}
            <div class="mb-3">
                <label class="form-label">NISN</label>
                <input type="text" class="form-control" name="nisn" placeholder="Masukkan NISN" maxlength="10" required />
            </div>

            {{-- Asal Sekolah --}}
            <div class="mb-3">
                <label class="form-label">Asal Sekolah</label>
                <select name="schoolId" id="schoolId" class="form-select" required>
                    <option value="" disabled selected>Pilih sekolah</option>
                    @foreach ($sekolahList as $sekolah)
                        <option value="{{ $sekolah->id }}" data-alamat="{{ $sekolah->alamat }}">
                            {{ $sekolah->namaSekolah }}
                        </option>
                    @endforeach
                </select>
            </div>

            {{-- Alamat Sekolah (readonly, auto fill) --}}
            <div class="mb-3">
                <label class="form-label">Alamat Sekolah</label>
                <textarea class="form-control" id="alamatSekolah" placeholder="Alamat akan muncul otomatis" readonly></textarea>
            </div>

            {{-- Jurusan --}}
            <div class="mb-3">
                <label class="form-label">Jurusan</label>
                <input type="text" class="form-control" name="jurusan" placeholder="Masukkan jurusan" />
            </div>

            {{-- Tahun Kelulusan --}}
            <div class="mb-3">
                <label class="form-label">Tahun Kelulusan</label>
                <input type="number" class="form-control" name="tahunKelulusan" placeholder="Contoh: 2024" min="2015" max="2025" required />
            </div>

            {{-- Upload Ijazah --}}
            <div class="mb-4">
  <label class="form-label">Upload Ijazah</label>
  <div class="upload-area" id="uploadArea">
    <div class="upload-icon">
      <i class="fas fa-cloud-upload-alt"></i>
    </div>
    <div class="upload-text">
      <strong id="fileNameDisplay">Klik untuk upload file</strong>
    </div>
    <div class="upload-subtext">
      Format: JPG, PNG, PDF (Max 5MB)
    </div>
  </div>
  <input type="file" class="file-input" id="fileInput" name="ijazah" accept=".jpg,.jpeg,.png,.pdf" required hidden />
</div>
            <button type="button" id="btnShowPopup" class="btn btn-submit">
  <i class="fas fa-paper-plane me-2"></i> Submit
</button>

        </div>
    </div>
</form>
      </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const schoolSelect = document.getElementById('schoolId');
    const alamatTextarea = document.getElementById('alamatSekolah');
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('fileInput');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    const btnShowPopup = document.getElementById('btnShowPopup');
    const schoolForm = document.getElementById('schoolForm');
    // const alertContainer = document.getElementById('alertContainer'); // Ini tidak lagi diperlukan jika Anda tidak ingin alert di atas
    // const alertMessage = document.getElementById('alertMessage');     // Ini tidak lagi diperlukan

    // Isi alamat otomatis
    schoolSelect.addEventListener('change', function () {
        const alamat = this.options[this.selectedIndex].getAttribute('data-alamat');
        alamatTextarea.value = alamat || '';
    });

    // Tampilkan nama file
    uploadArea.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', function () {
        const file = this.files[0];
        fileNameDisplay.textContent = file ? file.name : 'Klik untuk upload file';
    });

    // Saat tombol submit ditekan
    btnShowPopup.addEventListener('click', function () {
        // PENTING: Periksa validitas form sebelum menampilkan popup
        if (schoolForm.checkValidity()) {
            // Jika form valid, tampilkan popup sukses
            // alertContainer.style.display = 'none'; // Tidak perlu menyembunyikan jika tidak pernah menampilkan
            showSuccessPopup();
        } else {
            // Jika form tidak valid, cukup panggil reportValidity()
            // alertMessage.textContent = 'Mohon lengkapi semua field yang wajib diisi sebelum melanjutkan.'; // Tidak diperlukan
            // alertContainer.style.display = 'block'; // Tidak diperlukan
            schoolForm.reportValidity(); // Ini akan memicu pesan validasi bawaan browser
        }
    });

    function showSuccessPopup() {
        const popup = document.createElement('div');
        popup.className = 'success-popup-overlay';
        popup.style.cssText = `
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            background: rgba(0,0,0,0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        `;
        popup.innerHTML = `
            <div class="success-popup" style="background: white; padding: 30px; border-radius: 15px; text-align: center; max-width: 400px;">
                <div class="success-popup-icon" style="font-size: 40px; color: green; margin-bottom: 20px;">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h3>Data Berhasil Disimpan!</h3>
                <p>Data asal sekolah akan dikirim. Silakan klik lanjutkan untuk menyelesaikan.</p>
                <button class="btn btn-success mt-3" id="btnLanjutkanPopup">Lanjutkan</button>
            </div>
        `;
        document.body.appendChild(popup);

        document.getElementById('btnLanjutkanPopup').addEventListener('click', function () {
            schoolForm.submit(); // Submit form di sini setelah klik lanjutkan
        });
    }
});
</script>

  </body>
</html>
