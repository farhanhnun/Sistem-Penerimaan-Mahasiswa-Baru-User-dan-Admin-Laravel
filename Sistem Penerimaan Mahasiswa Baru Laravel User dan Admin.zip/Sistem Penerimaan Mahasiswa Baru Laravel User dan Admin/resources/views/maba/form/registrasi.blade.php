<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pembayaran Registrasi</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/pembayaran.css') }}" />
</head>

<body>
    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Form Pembayaran Registrasi</h2>

            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form id="paymentForm" method="POST" action="{{ route('form.registrasi.store') }}" enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="totalBayar" id="inputTotalBayar" value="3000000">
                <input type="hidden" name="promo_nama" id="promo_nama" value="">
                <input type="hidden" name="registrasi" value="1" id="registrasiHidden">

                <h4 class="section-title"><i class="fas fa-user me-2"></i>Data Mahasiswa</h4>
                <div class="form-section">
                    <div class="mb-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" value="{{ $calon->namaLengkap ?? '' }}" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nomor WhatsApp</label>
                        <input type="tel" class="form-control" value="{{ $calon->telepon ?? '' }}" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" value="{{ $calon->email ?? '' }}" readonly>
                    </div>
                   <div class="mb-3">
                        <label class="form-label">Kelas</label>
                        <input type="text" class="form-control" value="{{ $calon->kelas->namaKelas ?? '-' }}" disabled>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Program Studi</label>
                        <input type="text" class="form-control" value="{{ $calon->prodi->namaProdi ?? '-' }}" disabled>
                    </div>

                </div>

                <div class="row">
                    <div class="col-lg-6">
                        <h4 class="section-title"><i class="fas fa-money-bill-wave me-2"></i>Detail Pembayaran</h4>

                        <div class="mt-4">
                            <label class="form-label">Kode Promo (Opsional)</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="promoCode" placeholder="Masukkan kode promo" autocomplete="off">
                                <button type="button" class="btn btn-outline-secondary" id="applyPromo">
                                    <i class="fas fa-tag me-1"></i> Terapkan
                                </button>
                            </div>
                            <small id="promoFeedback" class="text-muted">Masukkan kode promo jika ada.</small>
                        </div>

                        <div id="paymentDetails" class="mt-4">
                            <div class="payment-detail-row">
                                <span class="payment-detail-label">Biaya Registrasi</span>
                                <span class="payment-detail-value">Rp 3.000.000</span>
                            </div>
                            <div class="payment-detail-row" id="promoRow" style="display: none;">
                                <span class="payment-detail-label">Diskon Promo</span>
                                <span class="payment-detail-value" id="promoAmount">Akan dihitung otomatis</span>
                            </div>
                        </div>

                        <div class="total-amount-card mt-3">
                            <div class="total-amount-label">Total Tagihan</div>
                            <div class="total-amount-value" id="totalAmount">Rp 3.000.000</div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <h4 class="section-title"><i class="fas fa-credit-card me-2"></i>Informasi Pembayaran</h4>
                        <div class="payment-info-card">
                            <div class="payment-info-row">
                                <span class="payment-info-label"><i class="fas fa-university me-2"></i>Nama Bank</span>
                                <span class="payment-info-value">Bank Mandiri</span>
                            </div>
                            <div class="payment-info-row">
                                <span class="payment-info-label"><i class="fas fa-credit-card me-2"></i>No Virtual Account</span>
                                <span class="payment-info-value">1234 5678 9101 1112</span>
                            </div>
                            <div class="payment-info-row">
                                <span class="payment-info-label"><i class="fas fa-user me-2"></i>Atas Nama</span>
                                <span class="payment-info-value">Politeknik LP3I</span>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Upload Bukti Pembayaran</label>
                            <div class="file-upload" onclick="document.getElementById('fileInput').click()">
                                <input type="file" id="fileInput" name="buktiBayar" accept="image/*,.pdf" onchange="showFileName(this)">
                                <i class="fas fa-cloud-upload-alt fa-2x mb-2"></i>
                                <div class="file-upload-text">
                                    <strong id="fileNameDisplay">Klik untuk upload file</strong><br>
                                    <small>Format: JPG, PNG, PDF (Max 5MB)</small>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-confirm mt-3">
                            <i class="fas fa-check-circle me-2"></i> Konfirmasi Pembayaran
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showFileName(input) {
            if (input.files && input.files[0]) {
                document.getElementById('fileNameDisplay').innerText = input.files[0].name;
            }
        }

        function formatRupiah(amount) {
            return 'Rp ' + amount.toLocaleString('id-ID');
        }

        function calculateTotal(diskon = 0) {
            diskon = parseInt(diskon) || 0;
            let total = 3000000;
            total -= diskon;
            if (total < 0) total = 0;

            document.getElementById('totalAmount').textContent = formatRupiah(total);
            document.getElementById('inputTotalBayar').value = total;
        }

        function applyPromo() {
            const kode = document.getElementById('promoCode').value.trim().toUpperCase();
            const promoRow = document.getElementById('promoRow');
            const promoAmount = document.getElementById('promoAmount');
            const promoNamaInput = document.getElementById('promo_nama');
            const feedback = document.getElementById('promoFeedback');

            if (!kode) {
                promoRow.style.display = 'none';
                promoAmount.textContent = 'Akan dihitung otomatis';
                promoNamaInput.value = '';
                feedback.textContent = 'Masukkan kode promo jika ada.';
                feedback.className = 'text-muted';
                calculateTotal(0);
                return;
            }

            fetch(`/promo/cek/${kode}`)
                .then(response => response.json())
                .then(data => {
                    if (data.valid) {
                        const nominalDiskon = parseInt(data.diskon) || 0;
                        promoRow.style.display = 'flex';
                        promoAmount.textContent = '- Rp ' + data.diskon.toLocaleString('id-ID');
                        promoNamaInput.value = data.namaPromo;
                        feedback.textContent = 'Kode promo berhasil diterapkan.';
                        feedback.className = 'text-success';
                        calculateTotal(nominalDiskon);
                    } else {
                        promoRow.style.display = 'none';
                        promoAmount.textContent = 'Akan dihitung otomatis';
                        promoNamaInput.value = '';
                        feedback.textContent = 'Kode tidak valid.';
                        feedback.className = 'text-danger';
                        calculateTotal(0);
                    }
                })
                .catch(() => {
                    promoRow.style.display = 'none';
                    promoAmount.textContent = 'Akan dihitung otomatis';
                    feedback.textContent = 'Terjadi kesalahan saat memverifikasi.';
                    feedback.className = 'text-danger';
                    calculateTotal(0);
                });
        }

        document.addEventListener('DOMContentLoaded', () => {
            calculateTotal();
            const kode = document.getElementById('promoCode');
            if (kode && kode.value.trim() !== '') {
                applyPromo();
            }
            document.getElementById('applyPromo')?.addEventListener('click', applyPromo);
            kode?.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    applyPromo();
                }
            });
        });
    </script>
</body>

</html>
