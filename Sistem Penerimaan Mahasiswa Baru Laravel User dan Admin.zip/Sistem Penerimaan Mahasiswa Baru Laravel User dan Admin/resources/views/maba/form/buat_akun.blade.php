<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Akun PMB</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    {{-- Aktifkan kembali meta tag ini untuk mendeteksi flash message --}}
    @if(session('registration_success'))
        <meta name="registration-success" content="true">
        <meta name="registration-username" content="{{ session('username') }}">
        <meta name="registered-password" content="{{ session('registered_password') }}">
    @endif

    <style>
        /* Tetap gunakan CSS yang sudah ada */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(to right, #019BA4, #004168) top,
                        #ffffff bottom;
            background-repeat: no-repeat;
            background-size: 100% 33.33%, 100% 66.67%;
            background-position: top, bottom;
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        /* Navbar Styles */
        .navbar-gradient {
            background: #005f73;
            border-radius: 50px;
            margin: 20px auto 10px auto; /* Reduced bottom margin */
            padding: 10px 30px;
            max-width: 1100px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .sticky-navbar {
            position: sticky;
            top: 0;
            z-index: 1030;
            animation: slideFade 0.8s ease;
        }

        @keyframes slideFade {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .navbar-brand img {
            border-radius: 4px;
            max-height: 40px;
            width: auto;
        }

        .nav-link {
            color: white !important;
            transition: rgba(0, 135, 113, 0.1);
            border-radius: 20px;
            padding: 6px 12px;
        }

        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .btn-login {
            border-radius: 25px;
            padding: 6px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
            background-color: #00bcd4;
            color: #fff;
            border: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-login:hover {
            background-color: #0097a7;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            color: #fff;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .form-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            margin-top: 60px;
        }

        .form-title {
            text-align: center;
            font-weight: bold;
            margin-bottom: 40px;
            font-size: 28px;
            color: #004168;
        }

        .personal-data-layout {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin: 15px 0;
            border: 1px solid #e9ecef;
        }

        .password-section {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin: 15px 0;
            border: 1px solid #e9ecef;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #019BA4;
            margin-bottom: 20px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e9ecef;
        }

        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 14px;
            transition: all 0.3s ease;
            height: 48px;
        }

        .form-control:focus, .form-select:focus {
            border-color: #019BA4;
            box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.15);
            outline: none;
        }

        .input-group {
            display: flex;
            align-items: stretch;
        }

        .input-group .form-control {
            border-right: none;
            border-top-right-radius: 0;
            border-bottom-right-radius: 0;
        }

        .btn-eye {
            background: none;
            border: 2px solid #e9ecef;
            border-left: none;
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
            padding: 0 12px;
            cursor: pointer;
            color: #6c757d;
            transition: all 0.3s ease;
        }

        .btn-eye:hover {
            color: #019BA4;
            border-color: #019BA4;
        }

        .input-group:focus-within .btn-eye {
            border-color: #019BA4;
        }

        .btn-daftar {
            background: linear-gradient(135deg, #004168 0%, #019BA4 100%);
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 16px;
            width: 100%;
            margin-top: 20px;
            transition: all 0.3s ease;
        }

        .btn-daftar:hover {
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        .btn-daftar:disabled {
            opacity: 0.7;
            transform: none;
        }

        .password-strength {
            height: 4px;
            border-radius: 2px;
            margin-top: 8px;
            transition: all 0.3s ease;
            background-color: transparent;
        }

        .strength-weak {
            background: linear-gradient(90deg, #dc3545 0%, #dc3545 33%, transparent 33%);
        }
        .strength-medium {
            background: linear-gradient(90deg, #ffc107 0%, #ffc107 66%, transparent 66%);
        }
        .strength-strong {
            background: linear-gradient(90deg, #198754 0%, #198754 100%);
        }

        .error-message {
            color: #dc3545;
            font-size: 0.875em;
            margin-top: 0.5rem;
            font-weight: 500;
        }

        .success-message {
            color: #198754;
            font-size: 0.875em;
            margin-top: 0.5rem;
            font-weight: 500;
        }

        .is-invalid {
            border-color: #dc3545 !important;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.15);
        }

        .is-valid {
            border-color: #198754 !important;
            box-shadow: 0 0 0 0.2rem rgba(25, 135, 84, 0.15);
        }

        .info-card {
            background: linear-gradient(135deg, #f8fdff 0%, #e8f8f9 100%);
            border: 1px solid #019BA4;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .info-card .info-title {
            color: #004168;
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 10px;
        }

        .info-card .info-text {
            color: #019BA4;
            font-size: 14px;
            line-height: 1.5;
        }

        .alert {
            border: none;
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
        }

        .alert-danger {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            color: #721c24;
        }

        /* Mobile Responsive Improvements */
        @media (max-width: 991.98px) {
            .section-title {
                margin-top: 30px;
            }

            .section-title:first-child {
                margin-top: 0;
            }
        }

        @media (max-width: 768px) {
            .container {
                padding: 20px 15px;
            }

            .form-container {
                padding: 25px 20px;
                margin-top: 30px;
            }

            .form-title {
                font-size: 24px;
                margin-bottom: 30px;
            }

            .section-title {
                font-size: 16px;
                margin-bottom: 15px;
                margin-top: 25px;
            }

            .section-title:first-child {
                margin-top: 0;
            }

            .btn-daftar {
                font-size: 14px;
                padding: 12px 30px;
            }

            /* Stack form fields vertically on mobile */
            .row .col-lg-6:nth-child(2) {
                margin-top: 0;
            }
        }

        @media (max-width: 576px) {
            body {
                background-size: 100% 25%, 100% 75%;
            }

            .container {
                padding: 15px 10px;
            }

            .form-container {
                padding: 20px 15px;
                margin-top: 20px;
                border-radius: 10px;
            }

            .form-title {
                font-size: 20px;
                margin-bottom: 25px;
            }

            .section-title {
                font-size: 15px;
                margin-bottom: 12px;
                margin-top: 20px;
            }

            .section-title:first-child {
                margin-top: 0;
            }

            .form-control, .form-select {
                font-size: 16px; /* Prevent zoom on iOS */
                height: 44px;
                padding: 10px 14px;
            }

            .info-card {
                padding: 15px;
                margin-bottom: 20px;
            }

            .info-card .info-title {
                font-size: 14px;
            }

            .info-card .info-text {
                font-size: 13px;
            }

            .btn-daftar {
                font-size: 14px;
                padding: 12px 25px;
                margin-top: 15px;
            }

            .form-label {
                font-size: 13px;
            }

            .personal-data-layout {
                background: #f8f9fa;
                border-radius: 12px;
                padding: 20px;
                margin: 15px 0;
                border: 1px solid #e9ecef;
            }
        }

        /* Ensure proper spacing between sections on mobile */
        @media (max-width: 991.98px) {
            .form-section-personal,
            .form-section-security {
                margin-bottom: 20px;
            }
        }
    </style>


</head>
<body>

    @include('partials.navbar')

    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Pendaftaran Akun PMB</h2>

            <div class="info-card">
                <div class="info-title">
                    <i class="fas fa-info-circle me-2"></i>Informasi Pendaftaran
                </div>
                <div class="info-text">
                    Lengkapi semua data dengan benar. Pastikan email dan nomor HP yang didaftarkan aktif untuk menerima pesan penting.
                </div>
            </div>

            <form id="registrationForm" method="POST" action="{{ route('form.akun.post') }}">
                @csrf

                <!-- Personal Data Section -->
                <div class="form-section-personal">
                    <h4 class="section-title">
                        <i class="fas fa-user me-2"></i>Data Pribadi
                    </h4>

                <div class="personal-data-layout">
                    <div class="mb-3">
                        <label for="namaLengkap" class="form-label">Nama Lengkap</label>
                        <input type="text" class="form-control" id="namaLengkap" name="namaLengkap" placeholder="Masukkan nama lengkap" required>
                        <div class="error-message" id="namaLengkap-error"></div>
                    </div>

                    <div class="mb-3">
                        <label for="noHP" class="form-label">Nomor WhatsApp</label>
                        <input type="text" class="form-control" id="noHP" name="noHP" placeholder="08123456789" maxlength="15" required>
                        <div class="error-message" id="noHP-error"></div>
                    </div>

                    <div class="mb-4">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="contoh@email.com" required>
                        <div class="error-message" id="email-error"></div>
                    </div>
                </div>
            </div>

                <!-- Security Section -->
                <div class="form-section-security">
                    <h4 class="section-title">
                        <i class="fas fa-lock me-2"></i>Pembuatan Akun
                    </h4>

                <div class="password-section">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Masukkan username" autocomplete="username" required>
                        <div class="error-message" id="username-error"></div>
                    </div>

<div class="mb-3">
    <label for="password" class="form-label">Password</label>
    <input type="password" class="form-control" id="password" name="password" placeholder="Masukkan password" autocomplete="new-password" required>
    <div class="password-strength" id="password-strength"></div>
    <div class="error-message" id="password-error"></div>
</div>

<div class="mb-3">
    <label for="konfirmasiPassword" class="form-label">Konfirmasi Password</label>
    <input type="password" class="form-control" id="konfirmasiPassword" name="password_confirmation" placeholder="Ulangi password" autocomplete="new-password" required>
    <div class="error-message" id="konfirmasiPassword-error"></div>
</div>

                </div>
            </div>

                <div class="row justify-content-center">
                    <div class="col-12 col-md-8 col-lg-6">
                        <button type="submit" class="btn btn-daftar">
                            <i class="fas fa-user-plus me-2"></i>
                            Daftar Sekarang
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    </body>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script>
// Format and validate phone number input
function formatPhoneNumber(input) {
    // Remove all non-numeric characters
    let value = input.value.replace(/\D/g, '');

    // Ensure it starts with 08
    if (value.length > 0 && !value.startsWith('08')) {
        if (value.startsWith('8')) {
            value = '0' + value;
        } else if (value.startsWith('0') && value.length > 1 && value[1] !== '8') {
            value = '08';
        } else if (!value.startsWith('0')) {
            value = '08' + value;
        }
    }

    // Limit length to 15 characters
    if (value.length > 15) {
        value = value.substring(0, 15);
    }

    input.value = value;
}

function togglePassword(fieldId, iconElement) {
    const input = document.getElementById(fieldId);
    const icon = iconElement.querySelector("i");

    if (input.type === "password") {
        input.type = "text";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
    } else {
        input.type = "password";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
    }
}

function checkPasswordStrength(password) {
    const strengthBar = document.getElementById('password-strength');
    if (!strengthBar) return; // Guard clause if element doesn't exist

    let strength = 0;

    if (password.length >= 8) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;

    // Reset classes
    strengthBar.className = 'password-strength';

    if (strength >= 4) {
        strengthBar.classList.add('strength-strong');
    } else if (strength >= 2) {
        strengthBar.classList.add('strength-medium');
    } else if (strength >= 1) {
        strengthBar.classList.add('strength-weak');
    }
}

function showError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const errorDiv = document.getElementById(fieldId + '-error');

    console.log('Showing error for:', fieldId, 'Message:', message); // Debug log

    if (field) {
        field.classList.remove('is-valid');
        field.classList.add('is-invalid');
    }

    if (errorDiv) {
        errorDiv.textContent = message;
        errorDiv.style.display = 'block';
        errorDiv.classList.add('invalid-feedback');
    } else {
        console.warn('Error div not found for field:', fieldId); // Debug warning

        // Create error div if it doesn't exist
        const newErrorDiv = document.createElement('div');
        newErrorDiv.id = fieldId + '-error';
        newErrorDiv.className = 'invalid-feedback';
        newErrorDiv.style.display = 'block';
        newErrorDiv.textContent = message;

        if (field && field.parentNode) {
            field.parentNode.appendChild(newErrorDiv);
        }
    }
}

function showSuccess(fieldId) {
    const field = document.getElementById(fieldId);
    const errorDiv = document.getElementById(fieldId + '-error');

    if (field) {
        field.classList.remove('is-invalid');
        field.classList.add('is-valid');
    }

    if (errorDiv) {
        errorDiv.textContent = '';
        errorDiv.style.display = 'none';
    }
}

function clearError(fieldId) {
    const field = document.getElementById(fieldId);
    const errorDiv = document.getElementById(fieldId + '-error');

    if (field) {
        field.classList.remove('is-invalid', 'is-valid');
    }

    if (errorDiv) {
        errorDiv.textContent = '';
        errorDiv.style.display = 'none';
    }
}

function showAlert(message, type = 'danger') {
    console.log('Showing alert:', message, 'Type:', type); // Debug log

    // Remove existing alerts
    const existingAlert = document.querySelector('.alert');
    if (existingAlert) {
        existingAlert.remove();
    }

    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    // Try different insertion points
    let insertTarget = document.querySelector('.form-container');
    if (!insertTarget) {
        insertTarget = document.querySelector('.container');
    }
    if (!insertTarget) {
        insertTarget = document.querySelector('form');
    }
    if (!insertTarget) {
        insertTarget = document.body;
    }

    if (insertTarget) {
        if (insertTarget.tagName === 'FORM') {
            insertTarget.parentNode.insertBefore(alertDiv, insertTarget);
        } else {
            insertTarget.insertBefore(alertDiv, insertTarget.firstChild);
        }
    }

    // Auto dismiss after 5 seconds
    setTimeout(() => {
        if (alertDiv && alertDiv.parentNode) {
            alertDiv.classList.remove('show');
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, 150);
        }
    }, 5000);
}

// Fungsi untuk menampilkan modal verifikasi
function showVerificationModal(username = '', password = '') {
    console.log('Showing verification modal for username:', username); // Debug log

    // Hapus modal yang sudah ada jika ada
    const existingModal = document.getElementById('verificationModal');
    if (existingModal) {
        existingModal.remove();
    }

    // Buat modal element baru
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.id = 'verificationModal';
    modal.setAttribute('tabindex', '-1');
    modal.setAttribute('aria-labelledby', 'verificationModalLabel');
    modal.setAttribute('aria-hidden', 'true');
    modal.setAttribute('data-bs-backdrop', 'static');
    modal.setAttribute('data-bs-keyboard', 'false');

    const usernameText = username ? `Username: <strong>${username}</strong><br>` : '';
    const passwordText = password ? `Password: <strong>${password}</strong><br>` : '';

    modal.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content" style="border-radius: 15px; border: none; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
                <div class="modal-body text-center p-5">
                    <div class="mb-4">
                        <div style="background: linear-gradient(135deg, #28a745, #20c997); border-radius: 50%; width: 80px; height: 80px; margin: 0 auto; display: flex; align-items: center; justify-content: center;">
                            <i class="fas fa-check text-white" style="font-size: 2.5rem;"></i>
                        </div>
                    </div>
                    <h4 class="modal-title mb-3" style="color: #004168; font-weight: bold;">Registrasi Berhasil!</h4>
                    <p class="text-muted mb-4" style="font-size: 16px; line-height: 1.5;">
                        Akun PMB Anda telah berhasil dibuat.<br><br>
                        ${usernameText}
                        ${passwordText}
                        <br>Silahkan gunakan <strong>username</strong> dan <strong>password</strong> di atas untuk login.
                    </p>
                    <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                        <button type="button" class="btn btn-primary me-md-2" onclick="redirectToLogin()" style="background: linear-gradient(135deg, #004168, #019BA4); border: none; border-radius: 10px; padding: 12px 30px; font-weight: 600;">
                            <i class="fas fa-sign-in-alt me-2"></i>Login Sekarang
                        </button>
                        <button type="button" class="btn btn-outline-secondary" onclick="closeModalAndResetForm()" style="border-radius: 10px; padding: 12px 30px; font-weight: 600;">
                            <i class="fas fa-times me-2"></i>Tutup
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    // Tampilkan modal dengan Bootstrap atau fallback
    if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
        const bootstrapModal = new bootstrap.Modal(modal, {
            backdrop: 'static',
            keyboard: false
        });
        bootstrapModal.show();
    } else {
        // Fallback jika Bootstrap tidak tersedia
        modal.style.display = 'block';
        modal.classList.add('show');
        document.body.classList.add('modal-open');

        // Add backdrop
        const backdrop = document.createElement('div');
        backdrop.className = 'modal-backdrop fade show';
        document.body.appendChild(backdrop);
    }
}

// Fungsi untuk redirect ke halaman login
function redirectToLogin() {
    console.log('Redirecting to login'); // Debug log

    // Tutup modal jika masih terbuka
    const modal = document.getElementById('verificationModal');
    if (modal) {
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            const bootstrapModal = bootstrap.Modal.getInstance(modal);
            if (bootstrapModal) {
                bootstrapModal.hide();
            }
        } else {
            // Fallback close
            modal.style.display = 'none';
            modal.classList.remove('show');
            document.body.classList.remove('modal-open');
            const backdrop = document.querySelector('.modal-backdrop');
            if (backdrop) {
                backdrop.remove();
            }
        }
    }

    // Tampilkan loading sebentar sebelum redirect
    setTimeout(() => {
        window.location.href = '{{ route('login') }}'; // <-- PASTIKAN INI MENGGUNAKAN ROUTE LOGIN YANG BENAR
    }, 300);
}

// Fungsi untuk menutup modal dan reset form
function closeModalAndResetForm() {
    console.log('Closing modal and resetting form'); // Debug log

    // Tutup modal
    const modal = document.getElementById('verificationModal');
    if (modal) {
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            const bootstrapModal = bootstrap.Modal.getInstance(modal);
            if (bootstrapModal) {
                bootstrapModal.hide();
            }
        } else {
            // Fallback close
            modal.style.display = 'none';
            modal.classList.remove('show');
            document.body.classList.remove('modal-open');
            const backdrop = document.querySelector('.modal-backdrop');
            if (backdrop) {
                backdrop.remove();
            }
        }
    }

    // Reset form
    const form = document.getElementById('registrationForm');
    if (form) {
        form.reset();

        // Clear all validation states
        const fields = ['namaLengkap', 'noHP', 'email', 'username', 'password', 'konfirmasiPassword'];
        fields.forEach(fieldId => {
            clearError(fieldId);
        });

        // Reset password strength indicator
        const strengthBar = document.getElementById('password-strength');
        if (strengthBar) {
            strengthBar.className = 'password-strength';
        }
    }
}

function validateForm() {
    console.log('Validating form...'); // Debug log
    let isValid = true;

    const namaLengkap = document.getElementById('namaLengkap')?.value.trim() || '';
    const noHP = document.getElementById('noHP')?.value.trim() || '';
    const email = document.getElementById('email')?.value.trim() || '';
    const username = document.getElementById('username')?.value.trim() || '';
    const password = document.getElementById('password')?.value || '';
    const konfirmasiPassword = document.getElementById('konfirmasiPassword')?.value || '';

    // Reset semua validasi
    ['namaLengkap', 'noHP', 'email', 'username', 'password', 'konfirmasiPassword'].forEach(field => {
        clearError(field);
    });

    // Validasi Nama Lengkap
    const nameRegex = /^[a-zA-ZÀ-ÿ\s'.-]{2,50}$/;
    if (!namaLengkap) {
        showError('namaLengkap', 'Nama Lengkap harus diisi.');
        isValid = false;
    } else if (!nameRegex.test(namaLengkap)) {
        showError('namaLengkap', 'Nama Lengkap hanya boleh berisi huruf, spasi, dan tanda baca dasar (2-50 karakter).');
        isValid = false;
    } else {
        showSuccess('namaLengkap');
    }

    // Validasi Nomor HP
    if (!noHP) {
        showError('noHP', 'Nomor HP harus diisi.');
        isValid = false;
    } else if (!/^08[0-9]{8,13}$/.test(noHP)) {
        showError('noHP', 'Nomor HP harus dimulai dengan 08 dan terdiri dari 10-15 digit.');
        isValid = false;
    } else {
        showSuccess('noHP');
    }

    // Validasi Email
    const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    if (!email) {
        showError('email', 'Email harus diisi.');
        isValid = false;
    } else if (!emailRegex.test(email)) {
        showError('email', 'Format email tidak valid.');
        isValid = false;
    } else {
        showSuccess('email');
    }

    // Validasi Username
    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    if (!username) {
        showError('username', 'Username harus diisi.');
        isValid = false;
    } else if (!usernameRegex.test(username)) {
        showError('username', 'Username harus 3-20 karakter, hanya boleh huruf, angka, dan underscore.');
        isValid = false;
    } else {
        showSuccess('username');
    }

    // Validasi Password
    if (!password) {
        showError('password', 'Password harus diisi.');
        isValid = false;
    } else if (password.length < 8) {
        showError('password', 'Password minimal 8 karakter.');
        isValid = false;
    } else {
        showSuccess('password');
    }

    // Validasi Konfirmasi Password
    if (!konfirmasiPassword) {
        showError('konfirmasiPassword', 'Konfirmasi password harus diisi.');
        isValid = false;
    } else if (konfirmasiPassword !== password) {
        showError('konfirmasiPassword', 'Konfirmasi password tidak sama dengan password.');
        isValid = false;
    } else {
        showSuccess('konfirmasiPassword');
    }

    console.log('Form validation result:', isValid); // Debug log
    return isValid;
}

// Fungsi validasi individual untuk real-time feedback
function validateSingleField(fieldId) {
    const field = document.getElementById(fieldId);
    if (!field) return;

    const value = field.value.trim();

    switch(fieldId) {
        case 'namaLengkap':
            if (value && !/^[a-zA-ZÀ-ÿ\s'.-]{2,50}$/.test(value)) {
                showError(fieldId, 'Nama hanya boleh berisi huruf dan spasi (2-50 karakter).');
            } else if (value) {
                showSuccess(fieldId);
            } else {
                clearError(fieldId);
            }
            break;

        case 'noHP':
            if (value && !/^08[0-9]{8,13}$/.test(value)) {
                showError(fieldId, 'Nomor HP harus dimulai dengan 08 (10-15 digit).');
            } else if (value) {
                showSuccess(fieldId);
            } else {
                clearError(fieldId);
            }
            break;

        case 'email':
            const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
            if (value && !emailRegex.test(value)) {
                showError(fieldId, 'Format email tidak valid.');
            } else if (value) {
                showSuccess(fieldId);
            } else {
                clearError(fieldId);
            }
            break;

        case 'username':
            const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
            if (value && !usernameRegex.test(value)) {
                showError(fieldId, 'Username harus 3-20 karakter, hanya boleh huruf, angka, dan underscore.');
            } else if (value) {
                showSuccess(fieldId);
            } else {
                clearError(fieldId);
            }
            break;

        case 'password':
            if (value && value.length < 8) {
                showError(fieldId, 'Password minimal 8 karakter.');
            } else if (value) {
                showSuccess(fieldId);
            } else {
                clearError(fieldId);
            }
            break;

        case 'konfirmasiPassword':
            const passwordField = document.getElementById('password');
            const password = passwordField ? passwordField.value : '';
            if (value && value !== password) {
                showError(fieldId, 'Konfirmasi password tidak sama.');
            } else if (value && value === password && password.length > 0) {
                showSuccess(fieldId);
            } else {
                clearError(fieldId);
            }
            break;
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const registrationForm = document.getElementById('registrationForm');
    const passwordField = document.getElementById('password');
    const konfirmasiPasswordField = document.getElementById('konfirmasiPassword');
    const noHPField = document.getElementById('noHP');
    const usernameField = document.getElementById('username');
    const emailField = document.getElementById('email');

    // Attach real-time validation listeners
    ['namaLengkap', 'noHP', 'email', 'username', 'password', 'konfirmasiPassword'].forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('input', () => validateSingleField(fieldId));
            field.addEventListener('blur', () => validateSingleField(fieldId)); // Validate on blur as well
        }
    });

    // Password strength check
    if (passwordField) {
        passwordField.addEventListener('input', function() {
            checkPasswordStrength(this.value);
            validateSingleField('password');
            validateSingleField('konfirmasiPassword'); // Re-validate confirm password
        });
    }

    // Confirm password match check
    if (konfirmasiPasswordField) {
        konfirmasiPasswordField.addEventListener('input', function() {
            validateSingleField('konfirmasiPassword');
        });
    }

    // Phone number formatting
    if (noHPField) {
        noHPField.addEventListener('input', function() {
            formatPhoneNumber(this);
        });
    }

    // Handle form submission
    registrationForm.addEventListener('submit', function(event) {
        // Prevent default HTML form submission
        event.preventDefault();

        // Perform full form validation
        if (validateForm()) {
            // If client-side validation passes, proceed with form submission
            // Since this is a standard form submission (not AJAX),
            // the browser will handle the redirect.
            // The success modal will be shown by DOMContentLoaded after redirect.
            this.submit(); // This will submit the form normally
        } else {
            // If validation fails, scroll to the first error
            const firstInvalidField = document.querySelector('.is-invalid');
            if (firstInvalidField) {
                firstInvalidField.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    });

    // --- PENTING: Aktifkan kembali logika ini untuk memicu modal setelah redirect ---
    const registrationSuccessMeta = document.querySelector('meta[name="registration-success"]');
    if (registrationSuccessMeta && registrationSuccessMeta.content === 'true') {
        const username = document.querySelector('meta[name="registration-username"]').content;
        const password = document.querySelector('meta[name="registered-password"]').content; // Mengambil password dari meta
        showVerificationModal(username, password); // Panggil modal

        // Opsional: Hapus meta tag setelah digunakan agar tidak muncul lagi jika user refresh halaman
        registrationSuccessMeta.remove();
        document.querySelector('meta[name="registration-username"]').remove();
        document.querySelector('meta[name="registered-password"]').remove();
    }
    // --- AKHIR PENTING ---


    // --- Kode untuk menangani pesan success/error dari Laravel Session (jika ada) ---
    // Pastikan ini tidak bentrok dengan modal sukses pendaftaran
    @if(session('success') && !session('show_registration_modal')) // Tampilkan alert success hanya jika bukan modal pendaftaran
        showAlert('{{ session('success') }}', 'success');
    @endif

    @if(session('error'))
        showAlert('{{ session('error') }}', 'danger');
    @endif

    @if($errors->any())
        @foreach ($errors->all() as $error)
            showAlert('{{ $error }}', 'danger');
        @endforeach
    @endif
});

</script>
</html>
