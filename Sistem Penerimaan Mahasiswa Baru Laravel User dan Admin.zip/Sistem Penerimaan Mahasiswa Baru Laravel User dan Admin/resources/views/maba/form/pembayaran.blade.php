<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pembayaran</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/pembayaran.css') }}" />
</head>

<body>
<div class="container">
    <div class="form-container">
        <h2 class="form-title">Form Pembayaran</h2>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form id="paymentForm" method="POST" action="{{ route('form.pembayaran.store') }}" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="totalBayar" id="inputTotalBayar" value="300000">
            <input type="hidden" name="promo_nama" id="promo_nama" value="">
            <input type="hidden" name="registrasi" value="0" id="registrasiHidden">

            {{-- Data Mahasiswa --}}
            <h4 class="section-title"><i class="fas fa-user me-2"></i>Data Mahasiswa</h4>
            <div class="form-section">
                <div class="mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" value="{{ $calon->namaLengkap ?? '' }}" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Nomor WhatsApp</label>
                    <input type="text" class="form-control" value="{{ $calon->telepon ?? '' }}" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="text" class="form-control" value="{{ $calon->email ?? '' }}" readonly>
                </div>
                <div class="mb-3">
                    <label class="form-label">Kelas</label>
                    <select class="form-select" name="kelas_id" required>
                        <option value="" disabled selected>Pilih Kelas</option>
                        @foreach ($kelas as $item)
                            <option value="{{ $item->id }}">{{ $item->namaKelas }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Program Studi</label>
                    <select class="form-select" name="prodi_id" required>
                        <option value="" disabled selected>Pilih Prodi</option>
                        @foreach ($prodi as $item)
                            <option value="{{ $item->id }}">{{ $item->namaProdi }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="row">
                {{-- Kiri: Pilihan Pembayaran --}}
                <div class="col-lg-6">
                    <h4 class="section-title"><i class="fas fa-money-bill-wave me-2"></i>Pilih Jenis Pembayaran</h4>
                    <div class="alert alert-info">
                        <strong>Catatan:</strong> Centang <strong>Biaya Registrasi</strong> hanya jika ingin langsung registrasi.
                    </div>

                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" id="biayaRegistrasi" value="1">
                        <label class="form-check-label" for="biayaRegistrasi">
                            <strong>Biaya Registrasi</strong><br><small class="text-muted">Rp 3.000.000</small>
                        </label>
                    </div>

                    <div class="mt-4">
                        <label class="form-label">Kode Promo (Opsional)</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="promoCode" placeholder="Masukkan kode promo">
                            <button type="button" class="btn btn-outline-secondary" id="applyPromo">
                                <i class="fas fa-tag me-1"></i> Terapkan
                            </button>
                        </div>
                        <small id="promoFeedback" class="text-muted">Masukkan kode promo jika ada.</small>
                    </div>

                    <div id="paymentDetails" class="mt-4">
                        <div class="payment-detail-row">
                            <span class="payment-detail-label">Biaya Pendaftaran</span>
                            <span class="payment-detail-value">Rp 300.000</span>
                        </div>
                        <div class="payment-detail-row" id="registrationRow" style="display: none;">
                            <span class="payment-detail-label">Biaya Registrasi</span>
                            <span class="payment-detail-value">Rp 3.000.000</span>
                        </div>
                        <div class="payment-detail-row" id="promoRow" style="display: none;">
                            <span class="payment-detail-label">Diskon Promo</span>
                            <span class="payment-detail-value" id="promoAmount">Akan dihitung otomatis</span>
                        </div>
                    </div>

                    <div class="total-amount-card mt-3">
                        <div class="total-amount-label">Total Tagihan</div>
                        <div class="total-amount-value" id="totalAmount">Rp 300.000</div>
                    </div>
                </div>

                {{-- Kanan: Upload dan Submit --}}
                <div class="col-lg-6">
                    <h4 class="section-title"><i class="fas fa-credit-card me-2"></i>Informasi Pembayaran</h4>
                    <div class="payment-info-card">
                        <div class="payment-info-row">
                            <span class="payment-info-label"><i class="fas fa-university me-2"></i>Bank</span>
                            <span class="payment-info-value">Bank Mandiri</span>
                        </div>
                        <div class="payment-info-row">
                            <span class="payment-info-label"><i class="fas fa-credit-card me-2"></i>No VA</span>
                            <span class="payment-info-value">1234 5678 9101 1112</span>
                        </div>
                        <div class="payment-info-row">
                            <span class="payment-info-label"><i class="fas fa-user me-2"></i>Atas Nama</span>
                            <span class="payment-info-value">Politeknik LP3I</span>
                        </div>
                    </div>

                    <div class="mb-3 mt-3">
                        <label class="form-label">Upload Bukti Pembayaran</label>
                        <div class="file-upload" onclick="document.getElementById('fileInput').click()">
                            <input type="file" id="fileInput" name="buktiBayar" accept="image/*,.pdf"
                                   onchange="showFileName(this)">
                            <i class="fas fa-cloud-upload-alt fa-2x mb-2"></i>
                            <div class="file-upload-text">
                                <strong id="fileNameDisplay">Klik untuk upload file</strong><br>
                                <small>Format: JPG, PNG, PDF (Max 5MB)</small>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-confirm mt-3">
                        <i class="fas fa-check-circle me-2"></i>Konfirmasi Pembayaran
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    function showFileName(input) {
        if (input.files && input.files[0]) {
            document.getElementById('fileNameDisplay').innerText = input.files[0].name;
        }
    }

    function formatRupiah(amount) {
        return 'Rp ' + amount.toLocaleString('id-ID');
    }

    function calculateTotal(diskon = 0) {
        let total = 300000;
        const registrasi = document.getElementById('biayaRegistrasi');
        const regRow = document.getElementById('registrationRow');
        document.getElementById('registrasiHidden').value = registrasi.checked ? '1' : '0';

        if (registrasi.checked) {
            total += 3000000;
            regRow.style.display = 'flex';
        } else {
            regRow.style.display = 'none';
        }

        total -= diskon;
        if (total < 0) total = 0;
        document.getElementById('totalAmount').textContent = formatRupiah(total);
        document.getElementById('inputTotalBayar').value = total;
    }

    function applyPromo() {
        const kode = document.getElementById('promoCode').value.trim().toUpperCase();
        const promoRow = document.getElementById('promoRow');
        const promoAmount = document.getElementById('promoAmount');
        const promoNamaInput = document.getElementById('promo_nama');
        const feedback = document.getElementById('promoFeedback');

        if (!kode) {
            promoRow.style.display = 'none';
            promoAmount.textContent = 'Akan dihitung otomatis';
            promoNamaInput.value = '';
            feedback.textContent = 'Masukkan kode promo jika ada.';
            feedback.className = 'text-muted';
            calculateTotal(0);
            return;
        }

        fetch(`/promo/cek/${kode}`)
            .then(response => response.json())
            .then(data => {
                if (data.valid) {
                    const nominalDiskon = Math.floor(data.diskon) || 0;
                    promoRow.style.display = 'flex';
                    promoAmount.textContent = '- Rp ' + nominalDiskon.toLocaleString('id-ID');
                    promoNamaInput.value = data.namaPromo;
                    feedback.textContent = 'Kode promo berhasil diterapkan.';
                    feedback.className = 'text-success';
                    calculateTotal(nominalDiskon);
                } else {
                    promoRow.style.display = 'none';
                    promoAmount.textContent = 'Akan dihitung otomatis';
                    promoNamaInput.value = '';
                    feedback.textContent = 'Kode tidak valid.';
                    feedback.className = 'text-danger';
                    calculateTotal(0);
                }
            })
            .catch(() => {
                promoRow.style.display = 'none';
                promoAmount.textContent = 'Akan dihitung otomatis';
                feedback.textContent = 'Terjadi kesalahan saat memverifikasi.';
                feedback.className = 'text-danger';
                calculateTotal(0);
            });
    }

    document.addEventListener('DOMContentLoaded', () => {
        calculateTotal();
        document.getElementById('biayaRegistrasi').addEventListener('change', calculateTotal);
        document.getElementById('applyPromo').addEventListener('click', applyPromo);
        document.getElementById('promoCode').addEventListener('keyup', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                applyPromo();
            }
        });
    });

     function hapusPembayaran(id) {
        Swal.fire({
            title: 'Yakin hapus pembayaran ini?',
            text: "Data akan dihapus permanen dan tidak bisa dikembalikan.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Ya, hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                fetch(`/pembayaran/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': token,
                        'Accept': 'application/json'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil!',
                            text: data.message,
                            timer: 2000,
                            showConfirmButton: false
                        }).then(() => {
                            window.location.reload();
                        });
                    } else {
                        Swal.fire('Gagal', data.message, 'error');
                    }
                })
                .catch(err => {
                    console.error(err);
                    Swal.fire('Gagal', 'Terjadi kesalahan saat menghapus.', 'error');
                });
            }
        });
    }
</script>
</body>
</html>
