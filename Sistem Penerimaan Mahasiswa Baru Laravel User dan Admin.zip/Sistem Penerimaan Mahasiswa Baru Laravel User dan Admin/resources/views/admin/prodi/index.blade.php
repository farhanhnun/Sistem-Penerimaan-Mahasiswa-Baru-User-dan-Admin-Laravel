@extends('layout.master')
@section('title', 'Data Prodi')

@section('content')
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Data Prodi</h4>
                                <p class="card-description">Kelola data program studi</p>
                            </div>
                            <a href="{{ url('prodi/create') }}" class="btn btn-primary btn-icon-text">
                                <i class="fa-solid fa-plus"></i>
                                Tambah Prodi
                            </a>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <form method="GET" action="{{ url('prodi/index') }}">
                                    <div class="input-group search-box">
                                        <input type="text" class="form-control"
                                            placeholder="Cari prodi..." name="search"
                                            value="{{ request('search') }}" />
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="submit">
                                                <i class="fa-solid fa-magnifying-glass"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Prodi</th>
                                        <th>Jumlah SKS</th>
                                        <th width="200px">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($prodiList as $index => $prodi)
                                        <tr id="row-{{ $prodi->id }}">
                                            <td>{{ $prodiList->firstItem() + $index }}</td>
                                            <td>{{ $prodi->namaProdi }}</td>
                                            <td>{{ $prodi->jmlSKS }}</td>
                                            <td>
                                                <div class="table-actions">
                                                    <button class="btn btn-inverse-warning btn-sm"
                                                        onclick="editProdi({{ $prodi->id }})" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-danger btn-sm"
                                                        onclick="deleteProdi({{ $prodi->id }})" title="Hapus">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-success btn-sm"
                                                        onclick="showDetailProdi({{ $prodi->id }})" title="Show">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="4" class="text-center">Belum ada data prodi</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        {{-- Pagination --}}
                        @if ($prodiList->hasPages())
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div>
                                    <p class="text-muted">
                                        Menampilkan {{ $prodiList->firstItem() }} sampai
                                        {{ $prodiList->lastItem() }} dari {{ $prodiList->total() }} data
                                    </p>
                                </div>
                                <nav>
                                    {{ $prodiList->links('pagination::bootstrap-4') }}
                                </nav>
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        function deleteProdi(id) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data prodi yang dihapus tidak bisa dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                    fetch(`/prodi/index/${id}`, {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': token,
                            'Accept': 'application/json'
                        }
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            document.getElementById(`row-${id}`).remove();
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: data.message,
                                timer: 2000,
                                showConfirmButton: false
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal',
                                text: data.message
                            });
                        }
                    })
                    .catch(error => {
                        console.error(error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Terjadi kesalahan',
                            text: 'Tidak dapat menghapus data.'
                        });
                    });
                }
            });
        }

        function editProdi(id) {
            window.location.href = `/prodi/edit/${id}`;
        }

        function showDetailProdi(id) {
            window.location.href = `/prodi/show/${id}`;
        }

          // SweetAlert Success setelah redirect dari edit
        $(document).ready(function () {
            @if(session('success'))
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: "{{ session('success') }}",
                    timer: 2500,
                    showConfirmButton: false
                });
            @endif
        });
    </script>
@endpush
