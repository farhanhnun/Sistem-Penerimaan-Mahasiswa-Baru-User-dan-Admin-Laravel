@extends('layout.master')
@section('title', 'Detail Pembayaran Registrasi')

@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Detail Pembayaran Registrasi</h4>
                            <p class="card-description">Informasi lengkap pembayaran registrasi</p>
                        </div>
                    </div>

                    <table class="table table-borderless">
                        <tr>
                            <th style="width: 200px;">Nama Lengkap</th>
                            <td>: {{ $bayar->calonMahasiswa->namaLengkap ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td>: {{ $bayar->calonMahasiswa->email ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>No WhatsApp</th>
                            <td>: {{ $bayar->calonMahasiswa->telepon ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Kelas</th>
                            <td>: {{ $bayar->calonMahasiswa->kelas->namaKelas ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Program Studi</th>
                            <td>: {{ $bayar->calonMahasiswa->prodi->namaProdi ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Promo</th>
                            <td>: {{ $bayar->promo->namaPromo ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Admin Verifikator</th>
                            <td>: {{ $bayar->admin->namaAdmin ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Total Pembayaran</th>
                            <td>: Rp{{ number_format($bayar->totalBayar ?? 0, 0, ',', '.') }}</td>
                        </tr>
                        <tr>
                            <th>Tanggal Pembayaran</th>
                            <td>: {{ $bayar->tglBayar ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Status Pembayaran</th>
                            <td>
                                :
                                @if ($bayar->statusBayar === 'lunas')
                                    <span class="badge badge-success">Lunas</span>
                                @elseif ($bayar->statusBayar === 'pending')
                                    <span class="badge badge-warning">Pending</span>
                                @elseif ($bayar->statusBayar === 'gagal')
                                    <span class="badge badge-danger">Gagal</span>
                                @else
                                    <span class="badge badge-secondary">Belum ada data</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Bukti Pembayaran</th>
                            <td>
                                @if($bayar->buktiBayar_blob)
                                    <a href="{{ route('verifregis.lihatBukti', $bayar->id) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fa fa-file-alt me-1"></i> Lihat Bukti
                                    </a>
                                @else
                                    <span class="badge badge-secondary">Belum Upload</span>
                                @endif
                            </td>
                        </tr>
                    </table>

                    <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-4">
                        <a href="{{ route('verifregis.index') }}" class="btn btn-secondary btn-icon-text">
                            <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
