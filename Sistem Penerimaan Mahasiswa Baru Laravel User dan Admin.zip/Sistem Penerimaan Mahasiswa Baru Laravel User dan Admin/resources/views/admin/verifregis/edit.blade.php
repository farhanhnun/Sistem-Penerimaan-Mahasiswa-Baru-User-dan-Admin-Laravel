@extends('layout.master')
@section('title', 'Edit Verifikasi Registrasi')

@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Edit Verifikasi Registrasi</h4>
                            <p class="card-description">Perbarui data registrasi calon mahasiswa</p>
                        </div>
                    </div>

                    <form id="verifikasiForm" action="{{ route('verifregis.update', $bayar->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        {{-- Data Calon Mahasiswa --}}
                        <div class="form-group">
                            <label for="namaLengkap">Nama Lengkap</label>
                            <input type="text" class="form-control" id="namaLengkap" name="namaLengkap"
                                value="{{ old('namaLengkap', $bayar->calonMahasiswa->namaLengkap ?? '') }}" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email"
                                value="{{ old('email', $bayar->calonMahasiswa->email ?? '') }}" required>
                        </div>

                        <div class="form-group">
                            <label for="telepon">No WhatsApp</label>
                            <input type="text" class="form-control" id="telepon" name="telepon"
                                value="{{ old('telepon', $bayar->calonMahasiswa->telepon ?? '') }}" required>
                        </div>

                        {{-- Bukti Bayar --}}
                        <div class="form-group">
                            <label for="buktiBayar">Bukti Pembayaran</label><br>
                            @if(!empty($bayar->nama_file_bukti_bayar))
                                <a href="{{ route('verifregis.lihatBukti', $bayar->id) }}" target="_blank">
                                    <span class="badge bg-info text-white">
                                        {{ $bayar->nama_file_bukti_bayar }}
                                    </span>
                                </a>
                            @else
                                <span class="badge bg-secondary">Belum Upload</span>
                            @endif
                            <input type="file" class="form-control mt-2" name="buktiBayar">
                        </div>

                        {{-- Status Bayar --}}
                        <div class="form-group">
                            <label for="statusBayar">Status Pembayaran</label>
                            <select name="statusBayar" id="statusBayar" class="form-control" required>
                                <option value="">-- Pilih Status --</option>
                                <option value="pending" {{ $bayar->statusBayar == 'pending' ? 'selected' : '' }}>Pending</option>
                                <option value="lunas" {{ $bayar->statusBayar == 'lunas' ? 'selected' : '' }}>Lunas</option>
                                <option value="gagal" {{ $bayar->statusBayar == 'gagal' ? 'selected' : '' }}>Gagal</option>
                            </select>
                        </div>

                        {{-- Tombol --}}
                        <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-4">
                            <a href="{{ route('verifregis.index') }}" class="btn btn-secondary btn-icon-text">
                                <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                            </a>
                            <div>
                                <button type="reset" class="btn btn-light me-2" id="resetBtn">
                                    <i class="fa-solid fa-rotate-left me-1"></i> Reset
                                </button>
                                <button type="submit" class="btn btn-primary" id="submitBtn">
                                    <i class="fa-solid fa-save me-1"></i> Simpan Perubahan
                                </button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    $(document).ready(function () {
        $('#verifikasiForm').on('submit', function () {
            $('#submitBtn').prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm" role="status"></span> Menyimpan...'
            );
        });

        $('#resetBtn').on('click', function (e) {
            e.preventDefault();
            $('#verifikasiForm')[0].reset();
        });

        @if(session('success'))
            Swal.fire('Berhasil', '{{ session('success') }}', 'success');
        @endif

        @if($errors->any())
            Swal.fire({
                icon: 'error',
                title: 'Validasi Gagal',
                html: `{!! implode('<br>', $errors->all()) !!}`
            });
        @endif
    });
</script>
@endpush
