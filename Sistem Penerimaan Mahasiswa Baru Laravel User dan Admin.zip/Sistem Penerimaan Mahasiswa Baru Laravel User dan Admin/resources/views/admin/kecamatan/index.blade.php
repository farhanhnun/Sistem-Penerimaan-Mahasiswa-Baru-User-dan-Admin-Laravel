@extends('layout.master')
@section('title', 'Data Kecamatan')

@section('content')
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Data Kecamatan</h4>
                                <p class="card-description">Kelola data Kecamatan</p>
                            </div>
                            <a href="{{ url('kecamatan/create') }}" class="btn btn-primary btn-icon-text">
                                <i class="fa-solid fa-plus"></i>
                                Tambah Kecamatan
                            </a>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <form method="GET" action="{{ url('kecamatan/index') }}">
                                    <div class="form-group">
                                        <div class="input-group search-box">
                                            <input type="text" class="form-control" placeholder="Cari kabupaten..."
                                                name="search" value="{{ request('search') }}" />
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="submit">
                                                    <i class="fa-solid fa-magnifying-glass"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Kabupaten</th>
                                        <th>Nama Kecamatan</th>
                                        <th width="200px">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($kecamatans as $index => $kecamatan)
                                        <tr id="row-{{ $kecamatan->id }}">
                                            <td>{{ $kecamatans->firstItem() + $index }}</td>
                                            <td>{{ $kecamatan->kabupaten->namaKabupaten ?? '-' }}</td>
                                            <td>{{ $kecamatan->namaKecamatan }}</td>
                                            <td>
                                                <div class="table-actions">
                                                    <button class="btn btn-inverse-warning btn-sm"
                                                        onclick="editKecamatan({{ $kecamatan->id }})" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-danger btn-sm"
                                                        onclick="deleteKecamatan({{ $kecamatan->id }})" title="Hapus">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                     <button class="btn btn-inverse-success btn-sm"
                                                        onclick="showDetailKecamatan({{ $kecamatan->id }})"
                                                        title="Show">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="4" class="text-center">Belum ada data Kabupaten</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        {{-- Pagination --}}
                        @if ($kecamatans->hasPages())
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div>
                                    <p class="text-muted">
                                        Menampilkan {{ $kecamatans->firstItem() }} sampai
                                        {{ $kecamatans->lastItem() }} dari {{ $kecamatans->total() }} data
                                    </p>
                                </div>
                                <nav>
                                    {{ $kecamatans->links('pagination::bootstrap-4') }}
                                </nav>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        function deleteKecamatan(id) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data kecamatan yang dihapus tidak bisa dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                    fetch(`/kecamatan/index/${id}`, {
                            method: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': token,
                                'Accept': 'application/json'
                            }
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                document.getElementById(`row-${id}`).remove();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: data.message,
                                    timer: 2000,
                                    showConfirmButton: false
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal',
                                    text: data.message
                                });
                            }
                        })
                        .catch(error => {
                            console.error(error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Terjadi kesalahan',
                                text: 'Tidak dapat menghapus data.'
                            });
                        });
                }
            });
        }

        function editKecamatan(id) {
            window.location.href = `/kecamatan/edit/${id}`;
        }

        function showDetailKecamatan(id) {
            window.location.href = `/kecamatan/show/${id}`;
        }
        // SweetAlert Success setelah redirect dari edit
        $(document).ready(function () {
            @if(session('success'))
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: "{{ session('success') }}",
                    timer: 2500,
                    showConfirmButton: false
                });
            @endif
        });
    </script>
@endpush
