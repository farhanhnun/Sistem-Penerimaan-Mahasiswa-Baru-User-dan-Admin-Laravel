@extends('layout.master')
@section('title', 'Data Promo')

@section('content')
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        {{-- Header dan Tombol Tambah --}}
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Data Promo</h4>
                                <p class="card-description">Kelola data promo</p>
                            </div>
                            <a href="{{ url('promo/create') }}" class="btn btn-primary btn-icon-text">
                                <i class="fa-solid fa-plus"></i>
                                Tambah Promo
                            </a>
                        </div>

                        {{-- Search --}}
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <form method="GET" action="{{ url('promo/index') }}">
                                    <div class="form-group">
                                        <div class="input-group search-box">
                                            <input type="text" class="form-control" placeholder="Cari promo..."
                                                name="search" value="{{ request('search') }}" />
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="submit">
                                                    <i class="fa-solid fa-magnifying-glass"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        {{-- Table --}}
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Promo</th>
                                        <th>Jenis</th>
                                        <th>Jumlah</th>
                                        <th>Mulai</th>
                                        <th>Berakhir</th>
                                        <th width="200px">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($promoList as $index => $promo)
                                        <tr id="row-{{ $promo->id }}">
                                            <td>{{ $promoList->firstItem() + $index }}</td>
                                            <td>{{ $promo->namaPromo }}</td>
                                            <td>{{ $promo->jnsPromo }}</td>
                                            <td>{{ $promo->jmlPromo }}</td>
                                            <td>{{ $promo->tglMulai }}</td>
                                            <td>{{ $promo->tglBerakhir }}</td>
                                            <td>
                                                <div class="table-actions">
                                                    <button class="btn btn-inverse-warning btn-sm"
                                                        onclick="editPromo({{ $promo->id }})" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-danger btn-sm"
                                                        onclick="deletePromo({{ $promo->id }})" title="Hapus">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-success btn-sm"
                                                        onclick="showDetailPromo({{ $promo->id }})" title="Show">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="7" class="text-center">Belum ada data promo</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        {{-- Pagination --}}
                        @if ($promoList->hasPages())
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div>
                                    <p class="text-muted">
                                        Menampilkan {{ $promoList->firstItem() }} sampai
                                        {{ $promoList->lastItem() }} dari {{ $promoList->total() }} data
                                    </p>
                                </div>
                                <nav>
                                    {{ $promoList->links('pagination::bootstrap-4') }}
                                </nav>
                            </div>
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
<script>
    function deletePromo(id) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Data promo yang dihapus tidak bisa dikembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                fetch(`/promo/index/${id}`, {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': token,
                            'Accept': 'application/json'
                        }
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            document.getElementById(`row-${id}`).remove();
                            Swal.fire({
                                icon: 'success',
                                title: 'Berhasil!',
                                text: data.message,
                                timer: 2000,
                                showConfirmButton: false
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Gagal',
                                text: data.message
                            });
                        }
                    })
                    .catch(error => {
                        console.error(error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Terjadi kesalahan',
                            text: 'Tidak dapat menghapus data.'
                        });
                    });
            }
        });
    }

    function editPromo(id) {
    window.location.href = `/promo/edit/${id}`;
    }


    function showDetailPromo(id) {
         window.location.href = `/promo/show/${id}`;
    }

  // SweetAlert Success setelah redirect dari edit
        $(document).ready(function () {
            @if(session('success'))
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: "{{ session('success') }}",
                    timer: 2500,
                    showConfirmButton: false
                });
            @endif
        });
</script>
@endpush
