@extends('layout.master')
@section('title', 'Detail Promo')

@section('content')
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 mx-auto grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Detail Promo</h4>
                                <p class="card-description">Informasi lengkap data promo</p>
                            </div>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Nama Promo:</h6>
                            <p class="p-2 rounded ">{{ $promo->namaPromo }}</p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Jenis Promo:</h6>
                            <p class="p-2 rounded ">{{ $promo->jnsPromo }}</p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Jumlah Promo:</h6>
                            <p class="p-2 rounded ">{{ $promo->jmlPromo }}</p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Tanggal Mulai:</h6>
                            <p class="p-2 rounded ">{{ \Carbon\Carbon::parse($promo->tglMulai)->format('d M Y') }}</p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Tanggal Berakhir:</h6>
                            <p class="p-2 rounded ">{{ \Carbon\Carbon::parse($promo->tglBerakhir)->format('d M Y') }}</p>
                        </div>

                        <div class="d-flex justify-content-between align-items-center pt-3 mt-4">
                            <a href="{{ url('promo/index') }}" class="btn btn-secondary">
                                <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                            </a>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('styles')
    <style>
        .btn + .btn {
            margin-left: 0.75rem;
        }

        .p-2.bg-light {
            border: 1px solid #e0e0e0;
        }
    </style>
@endpush


