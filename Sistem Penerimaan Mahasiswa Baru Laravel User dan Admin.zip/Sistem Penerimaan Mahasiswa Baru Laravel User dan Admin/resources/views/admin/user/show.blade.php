@extends('layout.master')
@section('title', 'Detail User')

@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 mx-auto grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Detail User</h4>
                            <p class="card-description">Informasi lengkap data user</p>
                        </div>
                    </div>

                    <div class="mb-3">
                        <h6 class="font-weight-bold mb-1">Role:</h6>
                        <p class="p-2 ">{{ $user->role }}</p>
                    </div>

                    <div class="mb-3">
                        <h6 class="font-weight-bold mb-1">Username:</h6>
                        <p class="p-2 ">{{ $user->username }}</p>
                    </div>

                    @if($user->role === 'admin' && $user->admin)
                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Nama Admin:</h6>
                            <p class="p-2 ">{{ $user->admin->namaAdmin }}</p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Telepon:</h6>
                            <p class="p-2 ">{{ $user->admin->telepon }}</p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Email:</h6>
                            <p class="p-2 ">{{ $user->admin->email }}</p>
                        </div>
                    @elseif($user->role === 'calon_mahasiswa' && $user->calonMahasiswa)
                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Nama Lengkap:</h6>
                            <p class="p-2 ">{{ $user->calonMahasiswa->namaLengkap }}</p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Telepon:</h6>
                            <p class="p-2 ">{{ $user->calonMahasiswa->telepon }}</p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Email:</h6>
                            <p class="p-2 ">{{ $user->calonMahasiswa->email }}</p>
                        </div>
                    @endif

                    <div class="d-flex justify-content-between align-items-center pt-3 mt-4">
                        <a href="{{ route('user.index') }}" class="btn btn-secondary">
                            <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection

