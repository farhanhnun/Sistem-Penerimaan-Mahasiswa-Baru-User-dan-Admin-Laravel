@extends('layout.master')
@section('title', 'Data User')

@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Data User</h4>
                            <p class="card-description">Kelola data user admin dan calon mahasiswa</p>
                        </div>
                        <a href="{{ url('user/create') }}" class="btn btn-primary btn-icon-text">
                            <i class="fa-solid fa-plus"></i> Tambah User
                        </a>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <form method="GET" action="{{ url('user/index') }}">
                                <div class="form-group">
                                    <div class="input-group search-box">
                                        <input type="text" class="form-control" name="search" placeholder="Cari user..."
                                            value="{{ request('search') }}" />
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="submit">
                                                <i class="fa-solid fa-magnifying-glass"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Role</th>
                                    <th>Username</th>
                                    <th>Nama</th>
                                    <th>Telepon</th>
                                    <th>Email</th>
                                    <th width="200px">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($users as $index => $user)
                                    <tr id="row-{{ $user->id }}">
                                        <td>{{ $users->firstItem() + $index }}</td>
                                        <td>{{ ucfirst($user->role) }}</td>
                                        <td>{{ $user->username }}</td>
                                        <td>{{ $user->nama }}</td>
                                        <td>{{ $user->isAdmin() ? $user->admin->telepon ?? '-' : ($user->calonMahasiswa->telepon ?? '-') }}</td>
                                        <td>{{ $user->isAdmin() ? $user->admin->email ?? '-' : ($user->calonMahasiswa->email ?? '-') }}</td>
                                        <td>
                                            <button class="btn btn-inverse-warning btn-sm"
                                                onclick="editUser({{ $user->id }})" title="Edit">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </button>
                                            <button class="btn btn-inverse-danger btn-sm"
                                                onclick="deleteUser({{ $user->id }})" title="Hapus">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                            <button class="btn btn-inverse-success btn-sm"
                                                onclick="showUser({{ $user->id }})" title="Lihat">
                                                <i class="fa-solid fa-eye"></i>
                                            </button>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center">Belum ada data user</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    @if ($users->hasPages())
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <div>
                                <p class="text-muted">
                                    Menampilkan {{ $users->firstItem() }} sampai {{ $users->lastItem() }} dari {{ $users->total() }} data
                                </p>
                            </div>
                            <nav>
                                {{ $users->links('pagination::bootstrap-4') }}
                            </nav>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function deleteUser(id) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data user yang dihapus tidak bisa dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                    fetch(`/user/index/${id}`, {
                            method: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': token,
                                'Accept': 'application/json'
                            }
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                document.getElementById(`row-${id}`).remove();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: data.message,
                                    timer: 2000,
                                    showConfirmButton: false
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal',
                                    text: data.message
                                });
                            }
                        })
                        .catch(error => {
                            console.error(error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Terjadi kesalahan',
                                text: 'Tidak dapat menghapus data.'
                            });
                        });
                }
            });
        }


    function editUser(id) {
        window.location.href = `/user/edit/${id}`;
    }

    function showUser(id) {
        window.location.href = `/user/show/${id}`;
    }


  // SweetAlert Success setelah redirect dari edit
        $(document).ready(function () {
            @if(session('success'))
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: "{{ session('success') }}",
                    timer: 2500,
                    showConfirmButton: false
                });
            @endif
        });
</script>
@endpush
