@extends('layout.master')
@section('title', 'Detail Provinsi')

@section('content')
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 mx-auto grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        {{-- Header --}}
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Detail Provinsi</h4>
                                <p class="card-description">Informasi lengkap data provinsi</p>
                            </div>
                        </div>

                        {{-- Detail Data --}}
                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Nama Provinsi:</h6>
                            <p class="p-2 ">{{ $provinsi->namaProvinsi }}</p>
                        </div>

                        {{-- Tombol Kembali --}}
                        <div class="d-flex justify-content-between align-items-center pt-3 mt-4">
                            <a href="{{ url('provinsi/index') }}" class="btn btn-secondary">
                                <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

