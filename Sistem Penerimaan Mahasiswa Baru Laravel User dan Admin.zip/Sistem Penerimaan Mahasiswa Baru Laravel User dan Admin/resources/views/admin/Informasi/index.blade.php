@extends('layout.master')
@section('title', 'Data Informasi')

@section('content')
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        {{-- Judul dan Tombol Tambah --}}
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Data Informasi</h4>
                                <p class="card-description">Kelola data informasi</p>
                            </div>
                            <a href="{{ url('informasi/create') }}" class="btn btn-primary btn-icon-text">
                                <i class="fa-solid fa-plus"></i>
                                Tambah Informasi
                            </a>
                        </div>

                        {{-- Form Pencarian --}}
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <form method="GET" action="{{ url('informasi/index') }}">
                                    <div class="form-group">
                                        <div class="input-group search-box">
                                            <input type="text" class="form-control" placeholder="Cari informasi..."
                                                name="search" value="{{ request('search') }}" />
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="submit">
                                                    <i class="fa-solid fa-magnifying-glass"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        {{-- Tabel Data --}}
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Jenis Pengumuman</th>
                                        <th>Isi Pengumuman</th>
                                        <th width="200px">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($informasis as $index => $informasi)
                                        <tr id="row-{{ $informasi->id }}">
                                            <td>{{ $informasis->firstItem() + $index }}</td>
                                            <td>{{ $informasi->jnsInformasi }}</td>
                                            <td>{{ Str::limit($informasi->isi, 100) }}</td>
                                            <td>
                                                <div class="table-actions">
                                                    <button class="btn btn-inverse-warning btn-sm"
                                                        onclick="editInformasi({{ $informasi->id }})" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-danger btn-sm"
                                                        onclick="deleteInformasi({{ $informasi->id }})" title="Hapus">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-success btn-sm"
                                                        onclick="showDetailInformasi({{ $informasi->id }})" title="Show">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="4" class="text-center">Belum ada data informasi</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>

                        {{-- Pagination --}}
                        @if ($informasis->hasPages())
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div>
                                    <p class="text-muted">
                                        Menampilkan {{ $informasis->firstItem() }} sampai
                                        {{ $informasis->lastItem() }} dari {{ $informasis->total() }} data
                                    </p>
                                </div>
                                <nav>
                                    {{ $informasis->links('pagination::bootstrap-4') }}
                                </nav>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        function deleteInformasi(id) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data informasi yang dihapus tidak bisa dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                    fetch(`/informasi/index/${id}`, {
                            method: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': token,
                                'Accept': 'application/json'
                            }
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                document.getElementById(`row-${id}`).remove();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: data.message,
                                    timer: 2000,
                                    showConfirmButton: false
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal',
                                    text: data.message
                                });
                            }
                        })
                        .catch(error => {
                            console.error(error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Terjadi kesalahan',
                                text: 'Tidak dapat menghapus data.'
                            });
                        });
                }
            });
        }

        function editInformasi(id) {
            window.location.href = `/informasi/edit/${id}`;
        }

        function showDetailInformasi(id) {
            window.location.href = `/informasi/show/${id}`;
        }

         // SweetAlert Success setelah redirect dari edit
        $(document).ready(function () {
            @if(session('success'))
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: "{{ session('success') }}",
                    timer: 2500,
                    showConfirmButton: false
                });
            @endif
        });

    </script>
@endpush
