@extends('layout.master')
@section('title', 'Edit Verifikasi')

@section('content')
<div class="content-wrapper">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Edit Verifikasi Pendaftaran</h4>
            <form action="{{ route('verifdaftar.update', $pendaftaran->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                {{-- Nama --}}
                <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input type="text" name="namaLengkap" class="form-control" value="{{ old('namaLengkap', $pendaftaran->namaLengkap) }}" required>
                </div>

                {{-- Email --}}
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" value="{{ old('email', $pendaftaran->email) }}" required>
                </div>

                {{-- Telepon --}}
                <div class="form-group">
                    <label>No WhatsApp</label>
                    <input type="text" name="telepon" class="form-control" value="{{ old('telepon', $pendaftaran->telepon) }}" required>
                </div>

                {{-- Kelas --}}
                <div class="form-group">
                    <label>Kelas</label>
                    <select name="kelas_id" class="form-control">
                        @foreach ($kelas as $item)
                            <option value="{{ $item->id }}" {{ $item->id == $pendaftaran->kelas_id ? 'selected' : '' }}>
                                {{ $item->namaKelas }}
                            </option>
                        @endforeach
                    </select>
                </div>

                {{-- Prodi --}}
                <div class="form-group">
                    <label>Program Studi</label>
                    <select name="prodi_id" class="form-control">
                        @foreach ($prodi as $item)
                            <option value="{{ $item->id }}" {{ $item->id == $pendaftaran->prodi_id ? 'selected' : '' }}>
                                {{ $item->namaProdi }}
                            </option>
                        @endforeach
                    </select>
                </div>

                {{-- Bukti Bayar --}}
                <div class="form-group">
                    <label>Bukti Pembayaran</label><br>
                    @if($bayar->nama_file_bukti_bayar)
                        <img src="{{ route('verifdaftar.lihatBukti', $bayar->id) }}" width="100" class="mb-2"><br>
                        <small>{{ $bayar->nama_file_bukti_bayar }}</small><br>
                    @endif
                    <input type="file" name="buktiBayar" class="form-control-file">
                </div>

                {{-- Status --}}
                <div class="form-group">
                    <label>Status Pembayaran</label>
                    <select name="statusBayar" class="form-control" required>
                        <option value="pending" {{ $bayar->statusBayar == 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="lunas" {{ $bayar->statusBayar == 'lunas' ? 'selected' : '' }}>Lunas</option>
                        <option value="gagal" {{ $bayar->statusBayar == 'gagal' ? 'selected' : '' }}>Gagal</option>
                    </select>
                </div>

                <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-4">
                            <a href="{{ route('verifdaftar.index') }}" class="btn btn-secondary btn-icon-text">
                                <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                            </a>
                            <div>
                                <button type="reset" class="btn btn-light me-2" id="resetBtn">
                                    <i class="fa-solid fa-rotate-left me-1"></i> Reset
                                </button>
                                <button type="submit" class="btn btn-primary" id="submitBtn">
                                    <i class="fa-solid fa-save me-1"></i> Simpan Perubahan
                                </button>
                            </div>
                        </div>
            </form>
        </div>
    </div>
</div>
@endsection
