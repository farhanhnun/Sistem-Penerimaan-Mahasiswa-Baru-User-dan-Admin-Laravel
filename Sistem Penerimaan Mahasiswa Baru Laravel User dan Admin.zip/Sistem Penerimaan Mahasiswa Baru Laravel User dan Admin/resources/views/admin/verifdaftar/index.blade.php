@extends('layout.master')
@section('title', 'Data Pendaftar')

@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Data Pendaftar</h4>
                            <p class="card-description">Kelola data pendaftar</p>
                        </div>
                    </div>

                    {{-- Form Pencarian --}}
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <form method="GET" action="{{ url('verifdaftar/index') }}">
                                <div class="form-group">
                                    <div class="input-group search-box">
                                        <input type="text" class="form-control" placeholder="Cari nama/email..."
                                            name="search" value="{{ request('search') }}" />
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-secondary" type="submit">
                                                <i class="fa-solid fa-magnifying-glass"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    {{-- Tabel --}}
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Lengkap</th>
                                    <th>Email</th>
                                    <th>No WA</th>
                                    <th>Promo</th>
                                    <th>Jumlah Bayar</th>
                                    <th>Bukti Bayar</th>
                                    <th>Status Bayar</th>
                                    <th width="220px">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($pendaftarans as $index => $data)
                                    <tr id="row-{{ $data->id }}">
                                        <td>{{ $pendaftarans->firstItem() + $index }}</td>
                                        <td>{{ $data->calonMahasiswa->namaLengkap }}</td>
                                        <td>{{ $data->calonMahasiswa->email }}</td>
                                        <td>{{ $data->calonMahasiswa->telepon }}</td>
                                        <td>{{ $data->promo->namaPromo ?? '-' }}</td>
                                        <td>Rp {{ number_format($data->totalBayar, 0, ',', '.') }}</td>
                                        <td>
                                            @if ($data->nama_file_bukti_bayar)
                                                <a href="{{ route('bukti.bayar.lihat', $data->id) }}"
                                                    target="_blank">{{ $data->nama_file_bukti_bayar }}</a>
                                            @else
                                                <span class="badge badge-secondary">Belum Upload</span>
                                            @endif
                                        </td>
                                        <td>
                                            @if ($data->statusBayar === 'lunas')
                                                <span class="badge badge-success">Lunas</span>
                                            @elseif ($data->statusBayar === 'pending')
                                                <span class="badge badge-warning">Pending</span>
                                            @elseif ($data->statusBayar === 'gagal')
                                                <span class="badge badge-danger">Gagal</span>
                                            @endif
                                        </td>
                                        <td class="text-nowrap">
                                            <div class="d-flex align-items-center">
                                                <a href="{{ url('verifdaftar/edit/' . $data->calonMahasiswa->id) }}"
                                                    class="btn btn-inverse-warning btn-sm m-1" title="Edit">
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </a>

                                                <button class="btn btn-inverse-danger btn-sm m-1"
                                                    onclick="hapusPendaftaran({{ $data->id }})" title="Hapus">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </button>

                                                <a href="{{ url('verifdaftar/show/' . $data->calonMahasiswa->id) }}"
                                                    class="btn btn-inverse-success btn-sm m-1" title="Lihat Detail">
                                                    <i class="fa-solid fa-eye"></i>
                                                </a>

                                               <button class="btn btn-inverse-info btn-sm"
                                                    onclick="verifikasi({{ $data->id }}, '{{ $data->calonMahasiswa->namaLengkap }}', '{{ $data->calonMahasiswa->telepon }}')" title="Verifikasi">
                                                    <i class="fa-solid fa-check"></i>
                                                </button>


                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="9" class="text-center">Belum ada data pendaftar</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    {{-- Pagination --}}
                    @if ($pendaftarans->hasPages())
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <div>
                                <p class="text-muted">
                                    Menampilkan {{ $pendaftarans->firstItem() }} sampai
                                    {{ $pendaftarans->lastItem() }} dari {{ $pendaftarans->total() }} data
                                </p>
                            </div>
                            <nav>
                                {{ $pendaftarans->links('pagination::bootstrap-4') }}
                            </nav>
                        </div>
                    @endif

                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function hapusPendaftaran(id) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data Pendaftaran yang dihapus tidak bisa dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                    fetch(`/verifdaftar/${id}`, {
                            method: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': token,
                                'Accept': 'application/json'
                            }
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                document.getElementById(`row-${id}`).remove();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: data.message,
                                    timer: 2000,
                                    showConfirmButton: false
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal',
                                    text: data.message
                                });
                            }
                        })
                        .catch(error => {
                            console.error(error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Terjadi kesalahan',
                                text: 'Tidak dapat menghapus data.'
                            });
                        });
                }
            });
        }


  function verifikasi(id, nama, no_wa) {
    Swal.fire({
        title: 'Verifikasi pembayaran?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Verifikasi',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/verifdaftar/verifikasi/${id}`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': token
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil',
                        text: data.message,
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        // Format nomor WA
                        const formattedWa = no_wa.replace(/^0/, '62');
                        const pesan = `Halo ${nama}, pembayaran Anda telah diverifikasi. Terima kasih telah mendaftar.`;
                        const url = `https://wa.me/${formattedWa}?text=${encodeURIComponent(pesan)}`;

                        // Buka WhatsApp dan reload halaman
                        window.open(url, '_blank');
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: data.message
                    });
                }
            });
        }
    });
}


</script>
@endpush
