@extends('layout.master')
@section('title', 'Detail Pendaftar')

@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Detail Pendaftar</h4>
                            <p class="card-description">Informasi lengkap pendaftar</p>
                        </div>
                    </div>

                    <table class="table table-borderless">
                        <tr>
                            <th style="width: 200px;">Nama Lengkap</th>
                            <td>: {{ $pendaftaran->namaLengkap }}</td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td>: {{ $pendaftaran->email }}</td>
                        </tr>
                        <tr>
                            <th>No WhatsApp</th>
                            <td>: {{ $pendaftaran->telepon }}</td>
                        </tr>
                        <tr>
                            <th>Kelas</th>
                            <td>: {{ $pendaftaran->kelas->namaKelas ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Program Studi</th>
                            <td>: {{ $pendaftaran->prodi->namaProdi ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Promo</th>
                            <td>: {{ optional($pendaftaran->bayar->promo)->namaPromo ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Admin</th>
                            <td>: {{ optional($pendaftaran->bayar->admin)->namaAdmin ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Total Bayar</th>
                            <td>: Rp{{ number_format($pendaftaran->bayar->totalBayar ?? 0, 0, ',', '.') }}</td>
                        </tr>
                        <tr>
                            <th>Tanggal Bayar</th>
                            <td>: {{ optional($pendaftaran->bayar)->tglBayar ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Status Pembayaran</th>
                            <td>
                                :
                                @php
                                    $status = optional($pendaftaran->bayar)->statusBayar;
                                @endphp
                                @if ($status === 'lunas')
                                    <span class="badge badge-success">Lunas</span>
                                @elseif ($status === 'pending')
                                    <span class="badge badge-warning">Pending</span>
                                @elseif ($status === 'gagal')
                                    <span class="badge badge-danger">Gagal</span>
                                @else
                                    <span class="badge badge-secondary">Belum Ada</span>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Nama File Bukti</th>
                            <td>: {{ $pendaftaran->bayar->nama_file_bukti_bayar ?? '-' }}</td>
                        </tr>
                        <tr>
                            <th>Bukti Pembayaran</th>
                            <td>
                                @if($pendaftaran->bayar && $pendaftaran->bayar->buktiBayar_blob)
                                    <a href="{{ route('bukti.bayar.lihat', $pendaftaran->bayar->id) }}"
                                       target="_blank" class="btn btn-outline-primary btn-sm">
                                        <i class="fa fa-eye me-1"></i> Lihat Bukti Pembayaran
                                    </a>
                                @else
                                    <span class="badge badge-secondary">Belum Upload</span>
                                @endif
                            </td>
                        </tr>
                    </table>

                    <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-4">
                        <a href="{{ route('verifdaftar.index') }}" class="btn btn-secondary btn-icon-text">
                            <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
