@extends('layout.master')
@section('title', 'Tambah Data Kelas')

@section('content')
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Tambah Data Kelas</h4>
                                <p class="card-description">Isi form untuk menambahkan data kelas baru</p>
                            </div>
                        </div>

                        <form id="kelasForm" action="{{ url('/kelas/create') }}" method="POST" class="forms-sample">
                            @csrf

                            <div class="form-group">
                                <label for="namaKelas">Nama Kelas <span class="text-danger">*</span></label>
                                <input type="text" class="form-control @error('namaKelas') is-invalid @enderror"
                                    id="namaKelas" name="namaKelas" placeholder="Masukkan nama kelas"
                                    value="{{ old('namaKelas') }}" required>
                                @error('namaKelas')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="jnsKelas">Jenis Kelas <span class="text-danger">*</span></label>
                                <input type="text" class="form-control @error('jnsKelas') is-invalid @enderror"
                                    id="jnsKelas" name="jnsKelas" placeholder="Masukkan jenis kelas"
                                    value="{{ old('jnsKelas') }}" required>
                                @error('jnsKelas')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-4">
                                <a href="{{ url('kelas/index') }}" class="btn btn-secondary">
                                    <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                                </a>
                                <div class="d-flex gap-3">
                                    <button type="reset" class="btn btn-light" id="resetBtn">
                                        <i class="fa-solid fa-undo mr-1"></i> Reset
                                    </button>
                                    <button type="submit" class="btn btn-primary" id="submitBtn">
                                        <i class="fa-solid fa-save mr-1"></i> Simpan
                                    </button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('styles')
    <style>
        .btn+.btn {
            margin-left: 0.75rem;
        }

        .form-control:focus,
        textarea.form-control:focus {
            border-color: #0d6efd;
        }

        .form-control.is-valid {
            border-color: #0d6efd;
        }

        .form-control.is-invalid {
            border-color: #dc3545;
        }
    </style>
@endpush

@push('scripts')
    <script>
        $(document).ready(function() {
            @if (session('success'))
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: "{{ session('success') }}",
                    timer: 2500,
                    showConfirmButton: false
                });
            @endif

            @if (session('error'))
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: "{{ session('error') }}",
                    showConfirmButton: true
                });
            @endif

            @if ($errors->any())
                let errorMessages = '';
                @foreach ($errors->all() as $error)
                    errorMessages += '- {{ $error }}\n';
                @endforeach

                Swal.fire({
                    icon: 'error',
                    title: 'Validasi Gagal',
                    text: errorMessages,
                    customClass: {
                        popup: 'text-left'
                    }
                });
            @endif

            $('#kelasForm').on('submit', function() {
                const submitBtn = $('#submitBtn');
                const originalHtml = submitBtn.html();

                submitBtn.prop('disabled', true).html(
                    '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Menyimpan...'
                    );

                setTimeout(() => {
                    submitBtn.prop('disabled', false).html(originalHtml);
                }, 3000);
            });

            $('.form-control[required]').on('input change', function() {
                const $input = $(this);
                if ($input.val().trim() !== '') {
                    $input.removeClass('is-invalid').addClass('is-valid');
                } else {
                    $input.removeClass('is-valid is-invalid');
                }
            });

            $('#resetBtn').on('click', function(e) {
                e.preventDefault();
                $('#kelasForm')[0].reset();
                $('.form-control').removeClass('is-valid is-invalid');
                $('.invalid-feedback').hide();
                $(this).prop('disabled', true).html(
                    '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Resetting...'
                    );
                setTimeout(() => {
                    $(this).prop('disabled', false).html(
                        '<i class="fa-solid fa-undo mr-1"></i> Reset');
                    $('#namaKelas').focus();
                }, 500);
            });

            if ($('.is-invalid').length > 0) {
                $('html, body').animate({
                    scrollTop: $('.is-invalid').first().offset().top - 100
                }, 500);
            }
        });
    </script>
@endpush
