<?php $__env->startSection('title', 'Data Provinsi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Data Pronvisi</h4>
                                <p class="card-description">Kelola data Pronvisi</p>
                            </div>
                            <a href="<?php echo e(url('provinsi/create')); ?>" class="btn btn-primary btn-icon-text">
                                <i class="fa-solid fa-plus"></i>
                                Tambah Privinsi
                            </a>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <form method="GET" action="<?php echo e(url('provinsi/index')); ?>">
                                    <div class="form-group">
                                        <div class="input-group search-box">
                                            <input type="text" class="form-control" placeholder="Cari provinsi..."
                                                name="search" value="<?php echo e(request('search')); ?>" />
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="submit">
                                                    <i class="fa-solid fa-magnifying-glass"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Pronvisi</th>
                                        <th width="200px">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $provinsis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $provinsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr id="row-<?php echo e($provinsi->id); ?>">
                                            <td><?php echo e($provinsis->firstItem() + $index); ?></td>
                                            <td><?php echo e($provinsi->namaProvinsi); ?></td>
                                            <td>
                                                <div class="table-actions">
                                                    <button class="btn btn-inverse-warning btn-sm"
                                                        onclick="editProvinsi(<?php echo e($provinsi->id); ?>)" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-danger btn-sm"
                                                        onclick="deleteProvinsi(<?php echo e($provinsi->id); ?>)" title="Hapus">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">Belum ada data Provinsi</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        
                        <?php if($provinsis->hasPages()): ?>
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div>
                                    <p class="text-muted">
                                        Menampilkan <?php echo e($provinsis->firstItem()); ?> sampai
                                        <?php echo e($provinsis->lastItem()); ?> dari <?php echo e($provinsis->total()); ?> data
                                    </p>
                                </div>
                                <nav>
                                    <?php echo e($provinsis->links('pagination::bootstrap-4')); ?>

                                </nav>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function deleteProvinsi(id) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data provinsi yang dihapus tidak bisa dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                    fetch(`/provinsi/index/${id}`, {
                            method: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': token,
                                'Accept': 'application/json'
                            }
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                document.getElementById(`row-${id}`).remove();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: data.message,
                                    timer: 2000,
                                    showConfirmButton: false
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal',
                                    text: data.message
                                });
                            }
                        })
                        .catch(error => {
                            console.error(error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Terjadi kesalahan',
                                text: 'Tidak dapat menghapus data.'
                            });
                        });
                }
            });
        }

        function editProvinsi(id) {
            window.location.href = `/provinsi/edit/${id}`;
        }

        function showDetailProvinsi(id) {
            alert("Melihat detail asal sekolah dengan ID: " + id);
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PMB\resources\views/admin/provinsi/index.blade.php ENDPATH**/ ?>