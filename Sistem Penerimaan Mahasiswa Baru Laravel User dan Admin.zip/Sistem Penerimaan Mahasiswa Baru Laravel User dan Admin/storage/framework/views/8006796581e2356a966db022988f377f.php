<?php $__env->startSection('title', 'Detail Pendaftar'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Detail Pendaftar</h4>
                            <p class="card-description">Informasi lengkap pendaftar</p>
                        </div>
                    </div>

                    <table class="table table-borderless">
                        <tr>
                            <th style="width: 200px;">Nama Lengkap</th>
                            <td>: <?php echo e($bayar->calonMahasiswa->namaLengkap); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td>: <?php echo e($bayar->calonMahasiswa->email); ?></td>
                        </tr>
                        <tr>
                            <th>No WhatsApp</th>
                            <td>: <?php echo e($bayar->calonMahasiswa->telepon); ?></td>
                        </tr>
                        <tr>
                            <th>Kelas</th>
                            <td>: <?php echo e($bayar->calonMahasiswa->kelas->namaKelas ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <th>Program Studi</th>
                            <td>: <?php echo e($bayar->calonMahasiswa->prodi->namaProdi ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <th>Promo</th>
                            <td>: <?php echo e($bayar->promo->namaPromo ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <th>Admin</th>
                            <td>: <?php echo e($bayar->admin->namaAdmin ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <th>Total Bayar</th>
                            <td>: Rp<?php echo e(number_format($bayar->totalBayar ?? 0, 0, ',', '.')); ?></td>
                        </tr>
                        <tr>
                            <th>Tanggal Bayar</th>
                            <td>: <?php echo e($bayar->tglBayar ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <th>Status Pembayaran</th>
                            <td>
                                :
                                <?php
                                    $status = $bayar->statusBayar;
                                ?>
                                <?php if($status === 'lunas'): ?>
                                    <span class="badge badge-success">Lunas</span>
                                <?php elseif($status === 'pending'): ?>
                                    <span class="badge badge-warning">Pending</span>
                                <?php elseif($status === 'gagal'): ?>
                                    <span class="badge badge-danger">Gagal</span>
                                <?php else: ?>
                                    <span class="badge badge-secondary">Belum ada data</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Bukti Pembayaran</th>
                            <td>
                                <?php if($bayar->buktiBayar): ?>
                                    <img src="<?php echo e(asset('storage/' . $bayar->buktiBayar)); ?>"
                                         width="200" style="border-radius: 5px; object-fit: cover;">
                                <?php else: ?>
                                    <span class="badge badge-secondary">Belum Upload</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>

                     <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-4">
                            <a href="<?php echo e(url('verifdaftar/index')); ?>" class="btn btn-secondary btn-icon-text">
                            <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                            </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PMB\resources\views/admin/verifdaftar/showduplikat.blade.php ENDPATH**/ ?>