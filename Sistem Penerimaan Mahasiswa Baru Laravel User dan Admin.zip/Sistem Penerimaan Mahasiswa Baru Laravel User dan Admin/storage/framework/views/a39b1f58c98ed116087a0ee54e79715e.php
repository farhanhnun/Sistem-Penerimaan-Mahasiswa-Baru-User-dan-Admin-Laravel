
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Sistem Penerimaan Mahasiswa Baru'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/feather.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/vertical-layout-light/style.css')); ?>" />

    
    <?php echo $__env->yieldPushContent('styles'); ?>

    
    <style>
        .sidebar .nav .nav-item .nav-link .menu-icon {
            width: 20px;
            min-width: 20px;
            text-align: center;
            margin-right: 12px;
            font-size: 16px;
        }

        .sidebar .nav .nav-item .nav-link .menu-title {
            flex: 1;
            font-size: 14px;
            font-weight: 400;
        }

        .sidebar .nav .nav-item .nav-link .menu-arrow {
            width: 16px;
            min-width: 16px;
            text-align: center;
            font-size: 12px;
            transition: transform 0.3s ease;
            margin-left: auto;
        }

        .sidebar .nav .nav-item .nav-link[aria-expanded="true"] .menu-arrow {
            transform: rotate(180deg);
        }


    </style>
</head>

<body>
    <div class="container-scroller">
        
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                <a class="navbar-brand brand-logo mr-5" href="<?php echo e(url('admin/index')); ?>">
                    <img src="<?php echo e(asset('images/logolp3ipanjang.png')); ?>" class="mr-2" alt="logo" />
                </a>
                <a class="navbar-brand brand-logo-mini " href="<?php echo e(url('admin/index')); ?>">
                    <img src="<?php echo e(asset('images/PoliteknikLP3I.png')); ?>" alt="logo" width="100px" />
                </a>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                <ul class="navbar-nav navbar-nav-right">
                    
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
                            <i class="bi bi-person-circle user-icon"></i>
                            <span class="user-info" style="color: black; font-weight: bold;">
                                Hai, <?php echo e(Auth::check() ? Auth::user()->username : 'Guest'); ?>

                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown"
                            aria-labelledby="profileDropdown">
                            <a class="dropdown-item">
                                <i class="fa-solid fa-gear text-primary"></i>
                                Settings
                            </a>
                             <form action="<?php echo e(route('logout')); ?>" method="POST" class="dropdown-item p-0 m-0">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-link text-dark w-100 text-left">
                                    <i class="fa-solid fa-power-off text-primary"></i>
                                    Logout
                                </button>
                            </form>
                        </div>
                    </li>

                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                    data-toggle="offcanvas">
                    <span class="fa-solid fa-bars"></span>
                </button>
            </div>
        </nav>

        <div class="container-fluid page-body-wrapper">
            
            <div class="theme-setting-wrapper">
                <div id="settings-trigger">
                    <i class="fa-solid fa-gear"></i>
                </div>
                <div id="theme-settings" class="settings-panel">
                    <i class="settings-close fa-solid fa-xmark"></i>
                    <p class="settings-heading">SIDEBAR SKINS</p>
                    <div class="sidebar-bg-options selected" id="sidebar-light-theme">
                        <div class="img-ss rounded-circle bg-light border mr-3"></div>
                        Light
                    </div>
                    <div class="sidebar-bg-options" id="sidebar-dark-theme">
                        <div class="img-ss rounded-circle bg-dark border mr-3"></div>
                        Dark
                    </div>
                    <p class="settings-heading mt-2">HEADER SKINS</p>
                    <div class="color-tiles mx-0 px-4">
                        <div class="tiles success"></div>
                        <div class="tiles warning"></div>
                        <div class="tiles danger"></div>
                        <div class="tiles info"></div>
                        <div class="tiles dark"></div>
                        <div class="tiles default"></div>
                    </div>
                </div>
            </div>

            
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('admin/index')); ?>">
                            <i class="fa-solid fa-house menu-icon"></i>
                            <span class="menu-title">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="collapse" href="#verfikasi" aria-expanded="false"
                            aria-controls="verfikasi">
                            <i class="fa-solid fa-clipboard-check menu-icon"></i>
                            <span class="menu-title">Verifikasi PMB</span>
                            <i class="fa-solid fa-chevron-down"></i>
                        </a>
                        <div class="collapse" id="verfikasi">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('verifdaftar/index')); ?>">
                                        <span class="menu-title">Verif Pendaftaran</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('verifregis/index')); ?>">
                                        <span class="menu-title">Verif Registrasi</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="collapse" href="#inputpmb" aria-expanded="false"
                            aria-controls="inputpmb">
                            <i class="fa-solid fa-plus-circle menu-icon"></i>
                            <span class="menu-title">Input PMB</span>
                            <i class="fa-solid fa-chevron-down"></i>
                        </a>
                        <div class="collapse" id="inputpmb">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('')); ?>">
                                        <span class="menu-title">Pendaftaran</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('')); ?>">
                                        <span class="menu-title">Registrasi</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="collapse" href="#inputdataumum" aria-expanded="false"
                            aria-controls="inputdataumum">
                            <i class="fa-solid fa-database menu-icon"></i>
                            <span class="menu-title">Input Data</span>
                            <i class="fa-solid fa-chevron-down"></i>
                        </a>
                        <div class="collapse" id="inputdataumum">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('user/index')); ?>">
                                        <span class="menu-title">User</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('prodi/index')); ?>">
                                        <span class="menu-title">Prodi</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('kelas/index')); ?>">
                                        <span class="menu-title">Kelas</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('asalsekolah/index')); ?>">
                                        <span class="menu-title">Asal Sekolah</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('provinsi/index')); ?>">
                                        <span class="menu-title">Provinsi</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('kabupaten/index')); ?>">
                                        <span class="menu-title">Kabupaten</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('kecamatan/index')); ?>">
                                        <span class="menu-title">Kecamatan</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('informasi/index')); ?>">
                            <i class="fa-solid fa-circle-info menu-icon"></i>
                            <span class="menu-title">Input Informasi</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('promo/index')); ?>">
                            <i class="fa-solid fa-tags menu-icon"></i>
                            <span class="menu-title">Input Promo</span>
                        </a>
                    </li>
                </ul>
            </nav>

            
            <div class="main-panel">
                <?php echo $__env->yieldContent('content'); ?>

                
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <p>Copyright &copy; 2025 Politeknik LP3I Bandung.</p>
                    </div>
                </footer>
            </div>

        </div>
    </div>

    
    <script src="<?php echo e(asset('js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('js/settings.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\PMB1\resources\views/layout/master.blade.php ENDPATH**/ ?>