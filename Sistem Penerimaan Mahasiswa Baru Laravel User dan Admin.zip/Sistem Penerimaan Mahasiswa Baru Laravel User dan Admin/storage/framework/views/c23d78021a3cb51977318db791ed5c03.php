<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(to right, #019BA4, #004168) top,
                        #ffffff bottom;
            background-repeat: no-repeat;
            background-size: 100% 33.33%, 100% 66.67%;
            background-position: top, bottom;
            min-height: 100vh;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Header Section */
        .header-section {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            align-items: stretch;
        }

        /* SIAKAD Card */
        .siakad-card {
            width: 200px;
            background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)), url('1.jpg');
            background-size: cover;
            background-position: center;
            border-radius: 15px;
            display: flex;
            align-items: flex-end;
            justify-content: center;
            padding: 20px;
            position: relative;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .siakad-button {
            background: #E1AF28;
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .siakad-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }

        /* Right Section */
        .right-section {
            flex: 1;
            display: flex;
            gap: 15px;
        }

        /* Payment Card */
        .payment-card {
            width: 200px;
            background: linear-gradient(to right, #019BA4 0%, #004168 100%);
            border-radius: 12px;
            padding: 15px;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .payment-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }

        .payment-icon {
            width: 60px;
            height: 60px;
            background: rgba(255,255,255,0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            margin-bottom: 15px;
        }

        .payment-card h3 {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .payment-card p {
            font-size: 12px;
            color: rgba(255,255,255,0.9);
            line-height: 1.4;
        }

        /* Steps Container */
        .steps-container {
            flex: 1;
            background: white;
            border-radius: 12px;
            padding: 20px;
            position: relative;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .steps-wrapper {
            display: flex;
            align-items: center;
            justify-content: space-evenly;
            height: 100%;
            position: relative;
            gap: 10px;
            padding: 15px 0; /* Tambahkan padding vertikal yang sama */
        }

        /* Progress Line - REMOVED */
        .progress-line {
            display: none;
        }

        .progress-active {
            display: none;
        }

        /* Step Cards */
        .step-card {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            cursor: pointer;
            position: relative;
            z-index: 2;
            flex: 0 1 auto;
            width: calc(20% - 8px);
            min-width: 120px;
            padding: 10px 5px; /* Tambahkan padding yang sama untuk semua step */
            margin: 0; /* Reset margin untuk konsistensi */
        }

        .step-checkbox {
            width: 50px; /* Lebar kotak ikon */
            height: 50px; /* Tinggi kotak ikon */
            border: 3px solid #e5e7eb; /* Border abu-abu */
            border-radius: 8px; /* Sudut membulat */
            display: flex; /* Flexbox untuk menengahkan ikon centang */
            align-items: center; /* Menengahkan ikon secara vertikal */
            justify-content: center; /* Menengahkan ikon secara horizontal */
            font-size: 18px; /* Ukuran font untuk ikon centang */
            margin: 0 auto 12px auto; /* Menengahkan secara horizontal dan memberi margin bawah */
            transition: all 0.3s ease; /* Transisi untuk perubahan gaya */
            background: white; /* Latar belakang putih */
            flex-shrink: 0; /* Mencegah ikon menyusut jika ruang terbatas */
        }

        /* Anda memiliki .step-icon yang tidak digunakan, jadi saya biarkan saja.
           Fokus pada .step-checkbox untuk ikon centang. */
        .step-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-bottom: 10px;
            transition: all 0.3s ease;
            border: 3px solid transparent;
        }

        .step-card h3 {
            font-size: 15px;
            font-weight: 600;
            margin: 0 0 8px 0; /* Konsisten margin bottom */
            transition: color 0.3s ease;
            text-align: center;
            word-wrap: break-word;
            hyphens: auto;
            line-height: 1.2;
        }

        .step-card p {
            font-size: 12px;
            color: black;
            line-height: 1.3;
        }

        /* --- CSS untuk status Completed --- */
        .step-card.completed .step-checkbox {
            background: #019BA4; /* Warna latar belakang hijau saat completed */
            border-color: #019BA4; /* Warna border hijau saat completed */
            color: white; /* Warna ikon centang putih */
            box-shadow: 0 0 0 4px rgba(1, 155, 164, 0.1); /* Efek bayangan saat completed */
        }

        .step-card.completed .step-checkbox i.fa-check-circle {
            color: white; /* Pastikan ikon centang di dalam checkbox berwarna putih */
        }

        /* Jika Anda menggunakan pseudo-element content: '✓', pastikan ini berfungsi
           atau gunakan langsung tag <i>. Saya sarankan <i> tag seperti yang
           saya terapkan di Blade. */
        /* .step-card.completed .step-checkbox::after {
            content: '✓';
            font-weight: bold;
        } */

        .step-card.completed h3 {
            color: #019BA4; /* Warna teks judul hijau saat completed */
        }

        /* CSS untuk step 'active' (mungkin yang sedang diisi?) */
        .step-card.active .step-checkbox {
            background: #E1AF28; /* Contoh warna kuning/emas untuk active */
            border-color: #E1AF28;
            color: white;
            box-shadow: 0 0 0 4px rgba(225, 175, 40, 0.1);
        }
        .step-card.active h3 {
            color: #E1AF28;
        }

        /* CSS untuk step 'inactive' (belum diisi) */
        .step-card.inactive .step-checkbox {
            background: #e5e7eb; /* Background abu-abu muda */
            border-color: #e5e7eb; /* Border abu-abu muda */
            color: #9ca3af; /* Warna ikon/teks abu-abu */
        }
        .step-card.inactive h3 {
            color: #9ca3af; /* Warna teks judul abu-abu */
        }


        .step-card:hover {
            transform: translateY(-2px);
        }

        /* Main Content */
        .main-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            display: flex;
            gap: 30px;
            align-items: center; /* Ubah dari flex-start ke center */
            justify-content: center; /* Tambahkan ini untuk memusatkan konten */
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        /* Building Image */
        .building-image {
            flex: 1;
            max-width: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px; /* Tambahkan padding untuk ruang di sekitar gambar */
        }

        .building-image svg {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .content-info {
            flex: 1.5;
        }

        .main-title {
            color: #004168;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 30px;
        }

        .feature-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 25px;
            gap: 15px;
        }

        .feature-icon {
            width: 40px;
            height: 40px;
            background: #019BA4;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            color: white;
        }

        .feature-content h3 {
            color: black;
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .feature-content p {
            color: gray;
            font-size: 14px;
            line-height: 1.5;
            text-align: justify; /* Tambahkan ini untuk justify teks */
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-section {
                flex-direction: column;
                gap: 15px;
            }

            .siakad-card {
                width: 100%;
                height: 120px;
            }

            .right-section {
                flex-direction: column;
                gap: 15px;
            }

            .payment-card {
                width: 100%;
            }

            .steps-container {
                padding: 15px;
            }

            .steps-wrapper {
                flex-direction: column;
                gap: 20px;
            }

            .progress-line {
                display: none;
            }

            .step-card {
                flex: none;
                width: 100%;
            }

            .main-content {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>
    
    <?php echo $__env->make('partials.navbar1', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container">
        <div class="header-section">
            <div class="siakad-card">
                <button class="siakad-button">SIAKAD</button>
            </div>

            <div class="right-section">
                <div class="payment-card" onclick="window.location.href='<?php echo e(route('form.pembayaran')); ?>'">
                    <div class="payment-icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <h3>Form Pembayaran</h3>
                    <p>Lakukan pembayaran administrasi dan SPP</p>
                </div>

                <div class="steps-container">
                    <div class="steps-wrapper">
                        
                        
                        
                        <div class="step-card <?php echo e((isset($userProgress) && $userProgress->biaya_pendaftaran_completed) ? 'completed' : 'inactive'); ?>"
                             onclick="handleStepClick('<?php echo e(route('form.pembayaran')); ?>', this)"
                             data-step="biaya-pendaftaran">
                            <div class="step-checkbox">
                                <?php if(isset($userProgress) && $userProgress->biaya_pendaftaran_completed): ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php endif; ?>
                            </div>
                            <h3>Biaya Pendaftaran</h3>
                            <p class="step-instruction" style="<?php echo e((isset($userProgress) && $userProgress->biaya_pendaftaran_completed) ? 'display: none;' : ''); ?>">Lakukan pembayaran biaya pendaftaran</p>
                            <p class="step-command" style="<?php echo e((isset($userProgress) && $userProgress->biaya_pendaftaran_completed) ? '' : 'display: none;'); ?>">Pembayaran telah dikonfirmasi</p>
                        </div>

                        
                        
                        
                        <div class="step-card <?php echo e((isset($userProgress) && $userProgress->biaya_registrasi_completed) ? 'completed' : 'inactive'); ?>"
                             onclick="handleStepClick('<?php echo e(route('form.pembayaran')); ?>', this)"
                             data-step="biaya-registrasi">
                            <div class="step-checkbox">
                                <?php if(isset($userProgress) && $userProgress->biaya_registrasi_completed): ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php endif; ?>
                            </div>
                            <h3>Biaya Registrasi</h3>
                            <p class="step-instruction" style="<?php echo e((isset($userProgress) && $userProgress->biaya_registrasi_completed) ? 'display: none;' : ''); ?>">Lakukan pembayaran biaya registrasi</p>
                            <p class="step-command" style="<?php echo e((isset($userProgress) && $userProgress->biaya_registrasi_completed) ? '' : 'display: none;'); ?>">Pembayaran telah dikonfirmasi</p>
                        </div>

                        
                        
                        
                        <div class="step-card <?php echo e((isset($userProgress) && $userProgress->data_pribadi_completed) ? 'completed' : 'inactive'); ?>"
                             onclick="handleStepClick('<?php echo e(route('form.data_diri')); ?>', this)"
                             data-step="data-pribadi">
                            <div class="step-checkbox">
                                <?php if(isset($userProgress) && $userProgress->data_pribadi_completed): ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php endif; ?>
                            </div>
                            <h3>Data Pribadi</h3>
                            <p class="step-instruction" style="<?php echo e((isset($userProgress) && $userProgress->data_pribadi_completed) ? 'display: none;' : ''); ?>">Silakan lengkapi data pribadi Anda</p>
                            <p class="step-command" style="<?php echo e((isset($userProgress) && $userProgress->data_pribadi_completed) ? '' : 'display: none;'); ?>">Data pribadi telah dilengkapi</p>
                        </div>

                        
                        
                        
                        <div class="step-card <?php echo e((isset($userProgress) && $userProgress->data_orangtua_completed) ? 'completed' : 'inactive'); ?>"
                             onclick="handleStepClick('<?php echo e(route('form.data_orangtua')); ?>', this)"
                             data-step="data-orangtua">
                            <div class="step-checkbox">
                                <?php if(isset($userProgress) && $userProgress->data_orangtua_completed): ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php endif; ?>
                            </div>
                            <h3>Data Orang Tua</h3>
                            <p class="step-instruction" style="<?php echo e((isset($userProgress) && $userProgress->data_orangtua_completed) ? 'display: none;' : ''); ?>">Silakan isi data orang tua/wali</p>
                            <p class="step-command" style="<?php echo e((isset($userProgress) && $userProgress->data_orangtua_completed) ? '' : 'display: none;'); ?>">Data orang tua telah dilengkapi</p>
                        </div>

                        
                        
                        
                        <div class="step-card <?php echo e((isset($userProgress) && $userProgress->asal_sekolah_completed) ? 'completed' : 'inactive'); ?>"
                             onclick="handleStepClick('<?php echo e(route('form.data_sekolah')); ?>', this)"
                             data-step="asal-sekolah">
                            <div class="step-checkbox">
                                <?php if(isset($userProgress) && $userProgress->asal_sekolah_completed): ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php endif; ?>
                            </div>
                            <h3>Asal Sekolah</h3>
                            <p class="step-instruction" style="<?php echo e((isset($userProgress) && $userProgress->asal_sekolah_completed) ? 'display: none;' : ''); ?>">Silakan lengkapi data sekolah asal</p>
                            <p class="step-command" style="<?php echo e((isset($userProgress) && $userProgress->asal_sekolah_completed) ? '' : 'display: none;'); ?>">Data sekolah telah dilengkapi</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="main-content" style="display: flex; gap: 30px; align-items: stretch;">
            <div class="building-image" style="flex: 1;">
                <img src="<?php echo e(asset('storage/foto/gedung.png')); ?>" alt="Gedung LP3I"
                     style="width: 110%; height: 110%; object-fit: cover; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.5);">
            </div>

            <div class="content-info" style="flex: 2;">
                <h1 class="main-title">Mengapa Kuliah di Politeknik LP3I?</h1>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-bullseye"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Praktis dan Siap Kerja</h3>
                        <p>LP3I berkomitmen menghasilkan lulusan yang relevan dengan kebutuhan industri dunia kerja.</p>
                    </div>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Kurikulum Yang Terkini</h3>
                        <p>Kurikulum LP3I selalu diupdate sesuai dengan perkembangan industri, sehingga mahasiswa memiliki pengetahuan dan keterampilan yang dibutuhkan oleh dunia kerja.</p>
                    </div>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Kampus di Lokasi Strategis</h3>
                        <p>Kurikulum LP3I selalu diupdate sesuai dengan perkembangan industri, sehingga mahasiswa memiliki pengetahuan dan keterampilan yang dibutuhkan oleh dunia kerja.</p>
                    </div>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Terdapat Banyak Beasiswa</h3>
                        <p>Kurikulum LP3I selalu diupdate sesuai dengan perkembangan industri, sehingga mahasiswa memiliki pengetahuan dan keterampilan yang dibutuhkan oleh dunia kerja.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function handleStepClick(url, element) {
            window.location.href = url;
        }

        // Fungsi scroll ke section #hero
        function scrollToHero() {
            const hero = document.getElementById('hero');
            if (hero) {
                hero.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }

        // Smooth scroll untuk semua anchor link
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PMB1\resources\views/maba/dashboard.blade.php ENDPATH**/ ?>