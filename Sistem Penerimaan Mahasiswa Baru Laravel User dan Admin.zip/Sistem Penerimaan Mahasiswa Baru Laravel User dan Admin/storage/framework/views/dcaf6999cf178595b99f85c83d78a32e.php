<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informasi Akademik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f5f5;
            background-repeat: no-repeat;
            background-size: 100% 33.33%, 100% 66.67%;
            background-position: top, bottom;
            min-height: 100vh;
        }
        .info-header {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.5);
            margin-bottom: 20px;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .logo-container {
            display: flex;
            align-items: center;
            flex-shrink: 0;
        }
        .info-icon {
            color: #004168;
            font-size: 24px;
            margin-right: 10px;
            display: flex;
            align-items: center;
        }
        .info-title {
            color: #004168;
            font-weight: bold;
            font-size: 32px;
            margin: 0;
            white-space: nowrap;
        }
        .search-box {
            margin-left: auto;
            width: 100%;
            max-width: 300px;
            position: relative;
        }
        .search-box input {
            padding-right: 35px;
            border-radius: 100px;
        }
        .search-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 10;
            background: none;
            border: none;
            color: #6c757d;
        }
        @media (max-width: 576px) {
            .search-box {
                margin-left: 0;
                margin-top: 10px;
                width: 100%;
                max-width: 100%;
            }
        }
        .announcements-container {
            background-color: #F3F4F9;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .announcement {
            background-color: white;
            border-radius: 8px;
            margin-bottom: 20px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .announcement-header {
            background: linear-gradient(to right, #019BA4, #004168);
            border-radius: 8px;
            color: white;
            padding: 12px 15px;
            font-weight: bold;
            font-size: 18px;
        }
        .announcement-content {
            padding: 15px;
        }
        .announcement-meta {
            margin-bottom: 10px;
            font-size: 14px;
            color: #666;
        }
        .announcement-message {
            font-size: 15px;
            line-height: 1.5;
            text-align: justify;
        }
    </style>
</head>
<body>
    <?php echo $__env->make('partials.navbar1', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container mt-5">
        <div class="info-header">
            <div class="logo-container">
                <div class="info-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-volume-up-fill" viewBox="0 0 16 16">
                        <path d="M11.536 14.01A8.473 8.473 0 0 0 14.026 8a8.473 8.473 0 0 0-2.49-6.01l-.708.707A7.476 7.476 0 0 1 13.025 8c0 2.071-.84 3.946-2.197 5.303l.708.707z"/>
                        <path d="M10.121 12.596A6.48 6.48 0 0 0 12.025 8a6.48 6.48 0 0 0-1.904-4.596l-.707.707A5.483 5.483 0 0 1 11.025 8a5.483 5.483 0 0 1-1.61 3.89l.706.706z"/>
                        <path d="M8.707 11.182A4.486 4.486 0 0 0 10.025 8a4.486 4.486 0 0 0-1.318-3.182L8 5.525A3.489 3.489 0 0 1 9.025 8 3.49 3.49 0 0 1 8 10.475l.707.707zM6.717 3.55A.5.5 0 0 1 7 4v8a.5.5 0 0 1-.812.39L3.825 10.5H1.5A.5.5 0 0 1 1 10V6a.5.5 0 0 1 .5-.5h2.325l2.363-1.89a.5.5 0 0 1 .529-.06z"/>
                    </svg>
                </div>
                <h1 class="info-title">Informasi</h1>
            </div>
            <div class="search-box">
                <input type="text" class="form-control" id="searchInput" placeholder="Cari Informasi" aria-label="Search">
                <button class="search-icon" type="button">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
                    </svg>
                </button>
            </div>
        </div>

        <div class="announcements-container">
            <?php $__empty_1 = true; $__currentLoopData = $informasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="announcement" data-content="<?php echo e(strtolower($info->isi)); ?>">
                    <div class="announcement-header">
                        <?php echo e(Str::upper(Str::limit($info->isi, 60))); ?>

                    </div>
                    <div class="announcement-content">
                        <div class="announcement-meta">
                            <strong><?php echo e(\Carbon\Carbon::parse($info->created_at)->translatedFormat('d F Y')); ?></strong><br>
                            <?php echo e($info->jnsInformasi); ?>

                        </div>
                        <div class="announcement-message">
                            <?php echo nl2br(e($info->isi)); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted">Belum ada informasi saat ini.</p>
            <?php endif; ?>
        </div>
    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<script>
    document.getElementById('searchInput').addEventListener('keyup', function () {
        const keyword = this.value.toLowerCase();
        const announcements = document.querySelectorAll('.announcement');

        announcements.forEach(function (item) {
            const content = item.getAttribute('data-content');
            if (content.includes(keyword)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\PMB1\resources\views/maba/informasi.blade.php ENDPATH**/ ?>