<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Navbar Dashboard</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
    />
    <style>
      body {
        background-color: #006d77;
      }

      .navbar {
        background-color: white;
        padding: 10px 30px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      }

      .navbar-brand {
        font-weight: bold;
        color: #00675b;
        display: flex;
        align-items: center;
      }

      .navbar-brand img {
        width: 120px;
        margin-right: 10px;
      }

      .nav-link {
        color: #004d40 !important;
        font-weight: 600;
        transition: all 0.3s ease;
      }

      .nav-link:hover {
        color: #00897b !important;
      }

      .user-info {
        font-weight: 600;
        color: #004d40;
        margin-left: 8px;
      }

      .user-icon {
        font-size: 1.5rem;
        color: #004d40;
        transition: 0.3s ease;
      }

      .user-icon:hover {
        color: #00897b;
        transform: scale(1.1);
      }

      @media (max-width: 768px) {
        .navbar {
          padding: 10px 15px;
        }

        .user-info {
          font-size: 0.9rem;
        }
      }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg sticky-top">
      <div class="container-fluid">
        <a class="navbar-brand d-flex align-items-center" href="<?php echo e(url('/dashboard')); ?>">
            <img src="<?php echo e(asset('images/logolp3ipanjang.png')); ?>" alt="Logo" />
            
        </a>


        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

      <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
        <i class="bi bi-house-door"></i> Dashboard
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(url('/informasi')); ?>">
        <i class="bi bi-people"></i> Informasi
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(url('/kontak')); ?>">
        <i class="bi bi-telephone"></i> Kontak
      </a>
    </li>
     <li class="nav-item">
      <a class="nav-link" href="<?php echo e(url('/login')); ?>">
        <i class="bi bi-box-arrow-right"></i> Logout
      </a>
    </li>
  </ul>
</div>


        <div class="d-flex align-items-center">
          <i class="bi bi-person-circle user-icon"></i>
          
          <span class="user-info" id="userInfo">
            Hai, <?php echo e($calonMahasiswa->namaLengkap ?? 'Calon Mahasiswa'); ?>

          </span>
        </div>
      </div>
    </nav>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        // Baris ini tidak lagi diperlukan karena nama sudah dirender langsung oleh Blade
        // const nama = document.getElementById('namaLengkap').value;
        // const userInfo = document.getElementById('userInfo');
        // if (nama) {
        //     userInfo.textContent = `Hai, ${nama}`;
        // }
    });
    </script>

  </body>
</html>
<?php /**PATH C:\Users\Siti Nazwatun M\Downloads\PMB6\PMB1\resources\views/partials/navbar1.blade.php ENDPATH**/ ?>