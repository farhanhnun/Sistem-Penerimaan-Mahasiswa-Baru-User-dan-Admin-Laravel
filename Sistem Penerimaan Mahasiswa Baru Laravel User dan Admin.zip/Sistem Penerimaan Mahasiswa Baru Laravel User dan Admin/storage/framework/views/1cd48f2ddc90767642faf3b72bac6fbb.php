<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Form Asal Sekolah</title>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
      rel="stylesheet"
    />
    <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      body {
        background: linear-gradient(to right, #019ba4, #004168) top,
          #ffffff bottom;
        background-repeat: no-repeat;
        background-size: 100% 33.33%, 100% 66.67%;
        background-position: top, bottom;
        min-height: 100vh;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
          sans-serif;
      }

      .container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 40px 20px;
      }

      .form-container {
        background-color: #ffffff;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        margin-top: 60px;
      }

      .form-title {
        text-align: center;
        font-weight: bold;
        margin-bottom: 40px;
        font-size: 28px;
        color: #004168;
      }

      .section-title {
        font-size: 18px;
        font-weight: 600;
        color: #019ba4;
        margin-bottom: 20px;
        padding-bottom: 8px;
        border-bottom: 2px solid #e9ecef;
      }

      .form-label {
        font-weight: 600;
        color: #333;
        margin-bottom: 8px;
        font-size: 14px;
      }

      .form-control,
      .form-select {
        border: 2px solid #e9ecef;
        border-radius: 10px;
        padding: 12px 16px;
        font-size: 14px;
        transition: all 0.3s ease;
        height: 48px;
      }

      .form-control:focus,
      .form-select:focus {
        border-color: #019ba4;
        box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.15);
        outline: none;
      }

      textarea.form-control {
        height: 100px;
        resize: vertical;
      }

      /* School Search Dropdown Styles */
      .school-search-container {
        position: relative;
      }

      .school-search-input {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23343a40' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m1 1 6 6-6 6'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 12px center;
        background-size: 16px;
        padding-right: 40px;
      }

      .school-dropdown {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: white;
        border: 2px solid #019ba4;
        border-top: none;
        border-radius: 0 0 10px 10px;
        max-height: 300px;
        overflow-y: auto;
        z-index: 1000;
        display: none;
      }

      .school-dropdown.show {
        display: block;
      }

      .school-option {
        padding: 12px 16px;
        cursor: pointer;
        border-bottom: 1px solid #f1f3f4;
        transition: background-color 0.2s;
      }

      .school-option:hover,
      .school-option.highlighted {
        background-color: #f8fdff;
      }

      .school-option:last-child {
        border-bottom: none;
      }

      .school-name {
        font-weight: 600;
        color: #333;
        margin-bottom: 4px;
      }

      .school-address {
        font-size: 12px;
        color: #6c757d;
      }

      .school-type {
        font-size: 11px;
        color: #019ba4;
        font-weight: 500;
        text-transform: uppercase;
      }

      .loading-spinner {
        display: none;
        position: absolute;
        right: 45px;
        top: 50%;
        transform: translateY(-50%);
        color: #019ba4;
      }

      .no-results {
        padding: 20px;
        text-align: center;
        color: #6c757d;
        font-style: italic;
      }

      .btn-submit {
        background: linear-gradient(135deg, #004168 0%, #019ba4 100%);
        color: white;
        border: none;
        padding: 15px 40px;
        border-radius: 12px;
        font-weight: 700;
        font-size: 16px;
        margin-top: 30px;
        transition: all 0.3s ease;
        width: 100%;
      }

      .btn-submit:hover {
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
      }

      .upload-area {
        border: 2px dashed #019ba4;
        border-radius: 10px;
        padding: 40px;
        text-align: center;
        background: #f8fdff;
        transition: all 0.3s ease;
        cursor: pointer;
        margin-top: 10px;
      }

      .upload-area:hover {
        background: #e3f8ff;
        border-color: #004168;
      }

      .upload-area.drag-over {
        background: #e3f8ff;
        border-color: #004168;
        transform: scale(1.02);
      }

      .upload-icon {
        font-size: 48px;
        color: #019ba4;
        margin-bottom: 15px;
      }

      .upload-text {
        color: #019ba4;
        font-weight: 600;
        font-size: 16px;
        margin-bottom: 5px;
      }

      .upload-subtext {
        color: #6c757d;
        font-size: 14px;
      }

      .file-input {
        display: none;
      }

      .uploaded-file {
        background: #e8f5e8;
        border: 1px solid #4caf50;
        border-radius: 8px;
        padding: 15px;
        margin-top: 10px;
        display: none;
      }

      .uploaded-file.show {
        display: block;
      }

      .file-info {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }

      .file-details {
        display: flex;
        align-items: center;
      }

      .file-icon {
        color: #4caf50;
        font-size: 20px;
        margin-right: 10px;
      }

      .file-name {
        font-weight: 600;
        color: #2e7d32;
      }

      .file-size {
        color: #6c757d;
        font-size: 12px;
        margin-left: 10px;
      }

      .remove-file {
        background: none;
        border: none;
        color: #dc3545;
        cursor: pointer;
        font-size: 16px;
      }

      .alert {
        border: none;
        border-radius: 10px;
        padding: 15px 20px;
      }

      .alert-success {
        background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
        color: #155724;
      }

      .alert-warning {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
        color: #856404;
      }

      /* Responsive Design */
      @media (max-width: 768px) {
        .container {
          padding: 20px 15px;
        }

        .form-container {
          padding: 25px 20px;
          margin-top: 30px;
          border-radius: 12px;
        }

        .form-title {
          font-size: 24px;
          margin-bottom: 30px;
        }

        .school-dropdown {
          max-height: 250px;
        }

        .school-option {
          padding: 10px 12px;
        }
      }

      @media (max-width: 576px) {
        .form-container {
          padding: 20px 15px;
          margin-top: 20px;
        }

        .form-title {
          font-size: 22px;
        }

        .school-dropdown {
          max-height: 200px;
        }
      }
    </style>
  </head>
  <body>
    <div class="container">
       <!-- Alert container for warnings -->
      <div id="alertContainer" style="display: none;">
        <div class="alert alert-danger" role="alert">
          <strong><i class="fas fa-exclamation-triangle me-2"></i>Peringatan!</strong>
          <span id="alertMessage">Mohon lengkapi semua field yang wajib diisi sebelum melanjutkan ke halaman berikutnya.</span>
        </div>
      </div>

      <div class="form-container">
        <h2 class="form-title">Asal Sekolah</h2>

        <form id="schoolForm">
          <div class="row g-4">
            <div class="col-12">
              <div class="mb-3">
                <label class="form-label">NISN</label>
                <input
                  type="text"
                  class="form-control"
                  name="nisn"
                  placeholder="Masukkan NISN"
                  maxlength="10"
                  required
                />
              </div>

              <div class="mb-3">
                <label class="form-label">Asal Sekolah</label>
                <div class="school-search-container">
                  <input
                    type="text"
                    class="form-control school-search-input"
                    id="schoolSearch"
                    name="asalSekolah"
                    placeholder="Ketik nama sekolah untuk mencari..."
                    autocomplete="off"
                    required
                  />
                  <div class="loading-spinner" id="loadingSpinner">
                    <i class="fas fa-spinner fa-spin"></i>
                  </div>
                  <div class="school-dropdown" id="schoolDropdown"></div>
                  <input type="hidden" name="schoolId" id="schoolId" />
                </div>
              </div>

              <div class="mb-3">
                <label class="form-label">Jurusan</label>
                <input
                  type="text"
                  class="form-control"
                  name="jurusan"
                  placeholder="Masukkan jurusan"
                />
              </div>

              <div class="mb-3">
                <label class="form-label">Alamat Sekolah</label>
                <textarea
                  class="form-control"
                  name="alamatSekolah"
                  placeholder="Alamat akan terisi otomatis setelah memilih sekolah"
                  readonly
                ></textarea>
              </div>

              <div class="mb-3">
                <label class="form-label">Tahun Kelulusan</label>
                <input
                  type="number"
                  class="form-control"
                  name="tahunKelulusan"
                  placeholder="Contoh: 2024"
                  min="2015"
                  max="2025"
                  required
                />
              </div>

              <div class="mb-4">
                <label class="form-label">Upload Ijazah</label>
                <div class="upload-area" id="uploadArea">
                  <div class="upload-icon">
                    <i class="fas fa-cloud-upload-alt"></i>
                  </div>
                  <div class="upload-text">Klik untuk upload file</div>
                  <div class="upload-subtext">
                    Format: JPG, PNG, PDF (Max 5MB)
                  </div>
                </div>
                <input
                  type="file"
                  class="file-input"
                  id="fileInput"
                  name="ijazah"
                  accept=".jpg,.jpeg,.png,.pdf"
                  required
                />
                <div class="uploaded-file" id="uploadedFile">
                  <div class="file-info">
                    <div class="file-details">
                      <i class="fas fa-file file-icon"></i>
                      <div>
                        <div class="file-name" id="fileName"></div>
                        <div class="file-size" id="fileSize"></div>
                      </div>
                    </div>
                    <button type="button" class="remove-file" id="removeFile">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div>
              </div>

              <button type="submit" class="btn btn-submit">
                <i class="fas fa-paper-plane me-2"></i>
                Submit
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
     // School search functionality dengan API real Indonesia
class SchoolSearchAPI {
  constructor() {
    this.cache = new Map();
    this.debounceTimer = null;
  }

  // Search schools menggunakan API data sekolah Indonesia
  async searchSchools(keyword) {
    if (!keyword || keyword.length < 3) return [];

    // Check cache first
    const cacheKey = keyword.toLowerCase();
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey);
    }

    try {
      // Menggunakan API data sekolah Indonesia dari Kementerian Pendidikan
      const response = await fetch(
        `https://api-sekolah-indonesia.vercel.app/sekolah?perPage=20&page=1&sekolah=${encodeURIComponent(
          keyword
        )}`
      );

      if (!response.ok) {
        throw new Error("API response not ok");
      }

      const data = await response.json();
      let schools = [];

      if (data && data.dataSekolah) {
        // Filter hanya SMA/SMK/MA/MAK
        schools = data.dataSekolah
          .filter((school) => {
            const bentuk = school.bentuk
              ? school.bentuk.toUpperCase()
              : "";
            const nama = school.sekolah
              ? school.sekolah.toUpperCase()
              : "";

            return (
              bentuk.includes("SMA") ||
              bentuk.includes("SMK") ||
              bentuk.includes("MA") ||
              bentuk.includes("MAK") ||
              nama.includes("SMA") ||
              nama.includes("SMK") ||
              nama.includes("MADRASAH ALIYAH")
            );
          })
          .slice(0, 15);
      }

      // Jika tidak ada hasil, coba API alternatif
      if (schools.length === 0) {
        schools = await this.searchAlternativeAPI(keyword);
      }

      // Cache hasil
      this.cache.set(cacheKey, schools);
      return schools;
    } catch (error) {
      console.error("API Error:", error);
      // Gunakan data mock sebagai fallback
      return this.getMockSchools(keyword);
    }
  }

  // API alternatif untuk data sekolah
  async searchAlternativeAPI(keyword) {
    try {
      // API alternatif menggunakan data referensi sekolah
      const response = await fetch(
        `https://cors-anywhere.herokuapp.com/https://referensi.data.kemdikbud.go.id/tabs.php?npsn=&sekolah=${encodeURIComponent(
          keyword
        )}&kab=&prop=&status=`,
        {
          headers: {
            "X-Requested-With": "XMLHttpRequest",
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        return this.parseAlternativeData(data, keyword);
      }
    } catch (error) {
      console.log("Alternative API also failed:", error);
    }

    return [];
  }

  // Parse data dari API alternatif
  parseAlternativeData(data, keyword) {
    if (!data || !Array.isArray(data)) return [];

    return data
      .filter((school) => {
        const bentuk = school.bentuk_pendidikan || "";
        return (
          bentuk.includes("SMA") ||
          bentuk.includes("SMK") ||
          bentuk.includes("MA")
        );
      })
      .map((school) => ({
        sekolah: school.nama || school.sekolah,
        alamat: `${school.alamat_jalan || ""}, ${
          school.nama_kabupaten || ""
        }, ${school.nama_propinsi || ""}`.replace(/^,\s*|,\s*$/g, ""),
        kode_sekolah: school.npsn || school.id,
        bentuk: school.bentuk_pendidikan || "SMA",
        kab_kota: school.nama_kabupaten,
        provinsi: school.nama_propinsi,
      }))
      .slice(0, 15);
  }

  // Data mock komprehensif untuk fallback
  getMockSchools(keyword) {
    const mockSchools = [
      // Jakarta
      {
        sekolah: "SMA Negeri 8 Jakarta",
        alamat: "Jl. Taman Bukit Duri, Jakarta Selatan",
        kode_sekolah: "20100008",
        bentuk: "SMA",
        kab_kota: "Jakarta Selatan",
        provinsi: "DKI Jakarta",
      },
      {
        sekolah: "SMA Negeri 3 Jakarta",
        alamat: "Jl. Setiabudi Raya, Jakarta Selatan",
        kode_sekolah: "20100003",
        bentuk: "SMA",
        kab_kota: "Jakarta Selatan",
        provinsi: "DKI Jakarta",
      },
      {
        sekolah: "SMA Negeri 1 Jakarta",
        alamat: "Jl. Budi Kemuliaan I, Jakarta Pusat",
        kode_sekolah: "20100001",
        bentuk: "SMA",
        kab_kota: "Jakarta Pusat",
        provinsi: "DKI Jakarta",
      },
      {
        sekolah: "SMK Negeri 1 Jakarta",
        alamat: "Jl. Budi Kemuliaan II, Jakarta Pusat",
        kode_sekolah: "20200001",
        bentuk: "SMK",
        kab_kota: "Jakarta Pusat",
        provinsi: "DKI Jakarta",
      },
      {
        sekolah: "SMK Negeri 26 Jakarta",
        alamat: "Jl. Balai Rakyat, Jakarta Pusat",
        kode_sekolah: "20200026",
        bentuk: "SMK",
        kab_kota: "Jakarta Pusat",
        provinsi: "DKI Jakarta",
      },

      // Bandung
      {
        sekolah: "SMA Negeri 1 Bandung",
        alamat: "Jl. Ir. H. Juanda No.93, Bandung",
        kode_sekolah: "20200001",
        bentuk: "SMA",
        kab_kota: "Kota Bandung",
        provinsi: "Jawa Barat",
      },
      {
        sekolah: "SMA Negeri 3 Bandung",
        alamat: "Jl. Belitung No.8, Bandung",
        kode_sekolah: "20200003",
        bentuk: "SMA",
        kab_kota: "Kota Bandung",
        provinsi: "Jawa Barat",
      },
      {
        sekolah: "SMK Negeri 1 Bandung",
        alamat: "Jl. Wastukancana No.3, Bandung",
        kode_sekolah: "20210001",
        bentuk: "SMK",
        kab_kota: "Kota Bandung",
        provinsi: "Jawa Barat",
      },

      // Surabaya
      {
        sekolah: "SMA Negeri 1 Surabaya",
        alamat: "Jl. Wijaya Kusuma No.48, Surabaya",
        kode_sekolah: "20350001",
        bentuk: "SMA",
        kab_kota: "Kota Surabaya",
        provinsi: "Jawa Timur",
      },
      {
        sekolah: "SMA Negeri 5 Surabaya",
        alamat: "Jl. Kusuma Bangsa No.21, Surabaya",
        kode_sekolah: "20350005",
        bentuk: "SMA",
        kab_kota: "Kota Surabaya",
        provinsi: "Jawa Timur",
      },
      {
        sekolah: "SMK Negeri 1 Surabaya",
        alamat: "Jl. Smea No.4, Surabaya",
        kode_sekolah: "20360001",
        bentuk: "SMK",
        kab_kota: "Kota Surabaya",
        provinsi: "Jawa Timur",
      },

      // Yogyakarta
      {
        sekolah: "SMA Negeri 1 Yogyakarta",
        alamat: "Jl. HOS Cokroaminoto No.10, Yogyakarta",
        kode_sekolah: "20340001",
        bentuk: "SMA",
        kab_kota: "Kota Yogyakarta",
        provinsi: "DIY Yogyakarta",
      },
      {
        sekolah: "SMA Negeri 3 Yogyakarta",
        alamat: "Jl. Yos Sudarso No.7, Yogyakarta",
        kode_sekolah: "20340003",
        bentuk: "SMA",
        kab_kota: "Kota Yogyakarta",
        provinsi: "DIY Yogyakarta",
      },
      {
        sekolah: "SMK Negeri 2 Yogyakarta",
        alamat: "Jl. AM Sangaji No.47, Yogyakarta",
        kode_sekolah: "20341002",
        bentuk: "SMK",
        kab_kota: "Kota Yogyakarta",
        provinsi: "DIY Yogyakarta",
      },

      // Medan
      {
        sekolah: "SMA Negeri 1 Medan",
        alamat: "Jl. Bunga Lau No.187, Medan",
        kode_sekolah: "10270001",
        bentuk: "SMA",
        kab_kota: "Kota Medan",
        provinsi: "Sumatera Utara",
      },
      {
        sekolah: "SMA Negeri 4 Medan",
        alamat: "Jl. Mataram No.25, Medan",
        kode_sekolah: "10270004",
        bentuk: "SMA",
        kab_kota: "Kota Medan",
        provinsi: "Sumatera Utara",
      },
      {
        sekolah: "SMK Negeri 1 Medan",
        alamat: "Jl. Sindoro No.1, Medan",
        kode_sekolah: "10271001",
        bentuk: "SMK",
        kab_kota: "Kota Medan",
        provinsi: "Sumatera Utara",
      },

      // Semarang
      {
        sekolah: "SMA Negeri 1 Semarang",
        alamat: "Jl. Taman Menteri Supeno No.1, Semarang",
        kode_sekolah: "20330001",
        bentuk: "SMA",
        kab_kota: "Kota Semarang",
        provinsi: "Jawa Tengah",
      },
      {
        sekolah: "SMA Negeri 3 Semarang",
        alamat: "Jl. Pemuda No.149, Semarang",
        kode_sekolah: "20330003",
        bentuk: "SMA",
        kab_kota: "Kota Semarang",
        provinsi: "Jawa Tengah",
      },
      {
        sekolah: "SMK Negeri 4 Semarang",
        alamat: "Jl. Prof. Hamka Ngaliyan, Semarang",
        kode_sekolah: "20331004",
        bentuk: "SMK",
        kab_kota: "Kota Semarang",
        provinsi: "Jawa Tengah",
      },

      // Madrasah Aliyah
      {
        sekolah: "MA Negeri 1 Jakarta",
        alamat: "Jl. Raya Pasar Minggu, Jakarta Selatan",
        kode_sekolah: "20300001",
        bentuk: "MA",
        kab_kota: "Jakarta Selatan",
        provinsi: "DKI Jakarta",
      },
      {
        sekolah: "MA Negeri 2 Jakarta",
        alamat: "Jl. Kramat Raya No.18, Jakarta Pusat",
        kode_sekolah: "20300002",
        bentuk: "MA",
        kab_kota: "Jakarta Pusat",
        provinsi: "DKI Jakarta",
      },
      {
        sekolah: "MAK Al-Ikhlas Jakarta",
        alamat: "Jl. Pemuda No.45, Jakarta Timur",
        kode_sekolah: "20300050",
        bentuk: "MAK",
        kab_kota: "Jakarta Timur",
        provinsi: "DKI Jakarta",
      },
    ];

    return mockSchools
      .filter(
        (school) =>
          school.sekolah.toLowerCase().includes(keyword.toLowerCase()) ||
          school.kab_kota.toLowerCase().includes(keyword.toLowerCase()) ||
          school.provinsi.toLowerCase().includes(keyword.toLowerCase())
      )
      .slice(0, 15);
  }
}

// Initialize school search
const schoolAPI = new SchoolSearchAPI();
const schoolSearch = document.getElementById("schoolSearch");
const schoolDropdown = document.getElementById("schoolDropdown");
const loadingSpinner = document.getElementById("loadingSpinner");
const schoolId = document.getElementById("schoolId");
const alamatSekolah = document.querySelector(
  'textarea[name="alamatSekolah"]'
);

let selectedSchoolIndex = -1;
let currentSchools = [];

// Debounced search function
function debounceSearch(func, delay) {
  return function (...args) {
    clearTimeout(this.debounceTimer);
    this.debounceTimer = setTimeout(() => func.apply(this, args), delay);
  };
}

// Search schools
const searchSchools = debounceSearch(async (keyword) => {
  if (keyword.length < 3) {
    hideDropdown();
    return;
  }

  showLoading();
  try {
    currentSchools = await schoolAPI.searchSchools(keyword);
    displaySchools(currentSchools);
  } catch (error) {
    console.error("Search error:", error);
    showNoResults();
  } finally {
    hideLoading();
  }
}, 300);

// Event listeners
schoolSearch.addEventListener("input", (e) => {
  const keyword = e.target.value.trim();
  selectedSchoolIndex = -1;

  if (keyword.length === 0) {
    hideDropdown();
    clearSelection();
    return;
  }

  searchSchools(keyword);
});

schoolSearch.addEventListener("keydown", (e) => {
  const options = schoolDropdown.querySelectorAll(".school-option");

  switch (e.key) {
    case "ArrowDown":
      e.preventDefault();
      selectedSchoolIndex = Math.min(
        selectedSchoolIndex + 1,
        options.length - 1
      );
      updateHighlight(options);
      break;

    case "ArrowUp":
      e.preventDefault();
      selectedSchoolIndex = Math.max(selectedSchoolIndex - 1, -1);
      updateHighlight(options);
      break;

    case "Enter":
      e.preventDefault();
      if (selectedSchoolIndex >= 0 && options[selectedSchoolIndex]) {
        selectSchool(currentSchools[selectedSchoolIndex]);
      }
      break;

    case "Escape":
      hideDropdown();
      schoolSearch.blur();
      break;
  }
});

// Click outside to close dropdown
document.addEventListener("click", (e) => {
  if (!e.target.closest(".school-search-container")) {
    hideDropdown();
  }
});

// Functions
function showLoading() {
  loadingSpinner.style.display = "block";
}

function hideLoading() {
  loadingSpinner.style.display = "none";
}

function displaySchools(schools) {
  if (schools.length === 0) {
    showNoResults();
    return;
  }

  schoolDropdown.innerHTML = schools
    .map(
      (school, index) => `
    <div class="school-option" data-index="${index}">
      <div class="school-name">${school.sekolah}</div>
      <div class="school-type">${school.bentuk || "SMA"}</div>
      <div class="school-address">${
        school.alamat || "Alamat tidak tersedia"
      }</div>
      ${
        school.kab_kota && school.provinsi
          ? `<div style="font-size: 11px; color: #8a8a8a; margin-top: 2px;">${school.kab_kota}, ${school.provinsi}</div>`
          : ""
      }
    </div>
  `
    )
    .join("");

  // Add click listeners
  schoolDropdown
    .querySelectorAll(".school-option")
    .forEach((option, index) => {
      option.addEventListener("click", () =>
        selectSchool(schools[index])
      );
    });

  showDropdown();
}

function showNoResults() {
  schoolDropdown.innerHTML =
    '<div class="no-results">Tidak ada sekolah ditemukan.<br><small>Coba gunakan kata kunci yang berbeda</small></div>';
  showDropdown();
}

function showDropdown() {
  schoolDropdown.classList.add("show");
}

function hideDropdown() {
  schoolDropdown.classList.remove("show");
  selectedSchoolIndex = -1;
}

function updateHighlight(options) {
  options.forEach((option, index) => {
    option.classList.toggle("highlighted", index === selectedSchoolIndex);
  });
}

function selectSchool(school) {
  schoolSearch.value = school.sekolah;
  schoolId.value = school.kode_sekolah || school.sekolah;
  alamatSekolah.value = school.alamat || "Alamat tidak tersedia";
  hideDropdown();

  // Remove any validation errors
  schoolSearch.classList.remove("is-invalid");
}

function clearSelection() {
  schoolId.value = "";
  alamatSekolah.value = "";
}

// File upload functionality
const uploadArea = document.getElementById("uploadArea");
const fileInput = document.getElementById("fileInput");
const uploadedFile = document.getElementById("uploadedFile");
const fileName = document.getElementById("fileName");
const fileSize = document.getElementById("fileSize");
const removeFile = document.getElementById("removeFile");

// Click to upload
uploadArea.addEventListener("click", () => {
  fileInput.click();
});

// Drag and drop functionality
uploadArea.addEventListener("dragover", (e) => {
  e.preventDefault();
  uploadArea.classList.add("drag-over");
});

uploadArea.addEventListener("dragleave", () => {
  uploadArea.classList.remove("drag-over");
});

uploadArea.addEventListener("drop", (e) => {
  e.preventDefault();
  uploadArea.classList.remove("drag-over");
  const files = e.dataTransfer.files;
  if (files.length > 0) {
    handleFile(files[0]);
  }
});

// File input change
fileInput.addEventListener("change", (e) => {
  if (e.target.files.length > 0) {
    handleFile(e.target.files[0]);
  }
});

// Handle file selection
function handleFile(file) {
  const allowedTypes = [
    "image/jpeg",
    "image/jpg",
    "image/png",
    "application/pdf",
  ];
  if (!allowedTypes.includes(file.type)) {
    showAlert(
      "Format file tidak didukung! Gunakan JPG, PNG, atau PDF.",
      "warning"
    );
    return;
  }

  const maxSize = 5 * 1024 * 1024;
  if (file.size > maxSize) {
    showAlert("Ukuran file terlalu besar! Maksimal 5MB.", "warning");
    return;
  }

  const dt = new DataTransfer();
  dt.items.add(file);
  fileInput.files = dt.files;

  fileName.textContent = file.name;
  fileSize.textContent = formatFileSize(file.size);
  uploadedFile.classList.add("show");
  uploadArea.style.display = "none";
}

// Remove file
removeFile.addEventListener("click", () => {
  fileInput.value = "";
  uploadedFile.classList.remove("show");
  uploadArea.style.display = "block";
});

// Format file size
function formatFileSize(bytes) {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

// NISN validation
document
  .querySelector('input[name="nisn"]')
  .addEventListener("input", function (e) {
    this.value = this.value.replace(/\D/g, "");
  });

// Year validation
document
  .querySelector('input[name="tahunKelulusan"]')
  .addEventListener("input", function (e) {
    const currentYear = new Date().getFullYear();
    const value = parseInt(this.value);

    if (value > currentYear + 1) {
      this.value = currentYear + 1;
    }
    if (value < 2015) {
      this.value = 2015;
    }
  });

// Form validation and submit
document
  .getElementById("schoolForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    const requiredFields = this.querySelectorAll("[required]");
    let isValid = true;

    requiredFields.forEach((field) => {
      if (!field.value.trim()) {
        isValid = false;
        field.classList.add("is-invalid");
      } else {
        field.classList.remove("is-invalid");
      }
    });

    // Validate school selection
    if (!schoolId.value) {
      showAlert(
        "Mohon pilih sekolah dari daftar yang tersedia!",
        "warning"
      );
      schoolSearch.classList.add("is-invalid");
      return;
    }

    if (!isValid) {
      showAlert("Mohon lengkapi semua field yang diperlukan!", "warning");
      return;
    }

    const nisn = document.querySelector('input[name="nisn"]').value;
    if (nisn.length !== 10) {
      showAlert("NISN harus terdiri dari 10 digit!", "warning");
      return;
    }

    if (!fileInput.files.length) {
      showAlert("Mohon upload file ijazah!", "warning");
      return;
    }

    // Simulate form submission
    const submitBtn = document.querySelector(".btn-submit");
    const originalText = submitBtn.innerHTML;

    submitBtn.innerHTML =
      '<i class="fas fa-spinner fa-spin me-2"></i>Memproses...';
    submitBtn.disabled = true;

    setTimeout(() => {
      // Show success alert
      showAlert("Data asal sekolah berhasil disimpan!", "success");

      // Wait for alert to be visible, then redirect to dashboard
      setTimeout(() => {
        window.location.href = "../dashboard.html";
      }, 2000); // 2 second delay to show the success message

      // Reset button state (though we're redirecting)
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
    }, 2000);
  });

// Function to show alerts
function showAlert(message, type) {
  const existingAlert = document.querySelector(".alert");
  if (existingAlert) {
    existingAlert.remove();
  }

  const alertDiv = document.createElement("div");
  alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
  alertDiv.innerHTML = `
          ${message}
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      `;

  document
    .querySelector(".form-container")
    .insertBefore(alertDiv, document.querySelector("form"));

  setTimeout(() => {
    if (alertDiv && alertDiv.parentNode) {
      alertDiv.remove();
    }
  }, 5000);
}
    </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\PMB\resources\views/maba/form/data_sekolah.blade.php ENDPATH**/ ?>