<?php $__env->startSection('title', 'Edit Verifikasi Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Edit Verifikasi Pendaftaran</h4>
                            <p class="card-description">Ubah informasi data pendaftaran</p>
                        </div>

                    </div>

                    <form id="verifikasiForm" action="<?php echo e(route('verifdaftar.update', $pendaftaran->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="namaLengkap">Nama Lengkap</label>
                            <input type="text" class="form-control" id="namaLengkap" name="namaLengkap"
                                value="<?php echo e(old('namaLengkap', $pendaftaran->namaLengkap)); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email"
                                value="<?php echo e(old('email', $pendaftaran->email)); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="telepon">No WhatsApp</label>
                            <input type="text" class="form-control" id="telepon" name="telepon"
                                value="<?php echo e(old('telepon', $pendaftaran->telepon)); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="kelas_id">Kelas</label>
                            <select name="kelas_id" id="kelas_id" class="form-control">
                                <option value="">-- Pilih Kelas --</option>
                                <?php $__currentLoopData = $kelases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kelas->id); ?>" <?php echo e($pendaftaran->kelas_id == $kelas->id ? 'selected' : ''); ?>>
                                        <?php echo e($kelas->namaKelas); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="prodi_id">Program Studi</label>
                            <select name="prodi_id" id="prodi_id" class="form-control">
                                <option value="">-- Pilih Prodi --</option>
                                <?php $__currentLoopData = $prodis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prodi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($prodi->id); ?>" <?php echo e($pendaftaran->prodi_id == $prodi->id ? 'selected' : ''); ?>>
                                        <?php echo e($prodi->namaProdi); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="buktiBayar">Bukti Pembayaran</label><br>
                            <?php if($pendaftaran->bayar && $pendaftaran->bayar->buktiBayar): ?>
                                <img src="<?php echo e(asset('storage/' . $pendaftaran->bayar->buktiBayar)); ?>" width="80" height="80"
                                    style="object-fit: cover; border-radius: 5px;" class="mb-2"><br>
                            <?php endif; ?>
                            <input type="file" class="form-control-file" name="buktiBayar">
                        </div>

                        <div class="form-group">
                            <label for="statusBayar">Status Pembayaran</label>
                            <select name="statusBayar" id="statusBayar" class="form-control">
                                <option value="">-- Pilih Status --</option>
                                <option value="pending" <?php echo e(optional($pendaftaran->bayar)->statusBayar == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="lunas" <?php echo e(optional($pendaftaran->bayar)->statusBayar == 'lunas' ? 'selected' : ''); ?>>Lunas</option>
                                <option value="gagal" <?php echo e(optional($pendaftaran->bayar)->statusBayar == 'gagal' ? 'selected' : ''); ?>>Gagal</option>
                            </select>
                        </div>

                        <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-4">
                            <a href="<?php echo e(url('verifdaftar/index')); ?>" class="btn btn-secondary btn-icon-text">
                            <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                            </a>
                            <div class="d-flex align-items-center">
                                <button type="reset" class="btn btn-light me-2" id="resetBtn">
                                    <i class="fa-solid fa-rotate-left me-1"></i> Reset
                                </button>
                                <button type="submit" class="btn btn-primary" id="submitBtn">
                                    <i class="fa-solid fa-save me-1"></i> Simpan Perubahan
                                </button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .btn+.btn {
            margin-left: 0.75rem;
        }

        .form-control:focus,
        textarea.form-control:focus {
            border-color: #0d6efd;
        }

        .form-control.is-valid {
            border-color: #0d6efd;
        }

        .form-control.is-invalid {
            border-color: #dc3545;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
    $(document).ready(function () {
        // === SweetAlert for Success Message ===
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: "<?php echo e(session('success')); ?>",
                timer: 2500,
                showConfirmButton: false
            });
        <?php endif; ?>

        // === SweetAlert for Error Message ===
        <?php if(session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: "<?php echo e(session('error')); ?>",
                showConfirmButton: true
            });
        <?php endif; ?>

        // === Validasi error dari Laravel ===
        <?php if($errors->any()): ?>
            let errorMessages = '';
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                errorMessages += '- <?php echo e($error); ?>\n';
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            Swal.fire({
                icon: 'error',
                title: 'Validasi Gagal',
                text: errorMessages,
                customClass: {
                    popup: 'text-left'
                }
            });
        <?php endif; ?>

        // === Loading Saat Submit Form ===
        $('#verifikasiForm').on('submit', function (e) {
            const submitBtn = $('#submitBtn');
            const originalHtml = submitBtn.html();

            submitBtn.prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Menyimpan...'
            );

            setTimeout(() => {
                submitBtn.prop('disabled', false).html(originalHtml);
            }, 3000);
        });

        // === Validasi Input Real-Time ===
        $('.form-control[required]').on('input change', function () {
            const $input = $(this);
            if ($input.val().trim() !== '') {
                $input.removeClass('is-invalid').addClass('is-valid');
            } else {
                $input.removeClass('is-valid is-invalid');
            }
        });

        // === Reset Form ===
        $('#resetBtn').on('click', function (e) {
            e.preventDefault();
            $('#verifikasiForm')[0].reset();
            $('.form-control').removeClass('is-valid is-invalid');
            $('.invalid-feedback').hide();
            $(this).prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Resetting...'
            );
            setTimeout(() => {
                $(this).prop('disabled', false).html(
                    '<i class="fa-solid fa-undo mr-1"></i> Reset'
                );
                $('#namaSekolah').focus();
            }, 500);
        });

        // === Scroll ke error pertama (jika ada) ===
        if ($('.is-invalid').length > 0) {
            $('html, body').animate({
                scrollTop: $('.is-invalid').first().offset().top - 100
            }, 500);
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PMB\resources\views/admin/verifdaftar/edit.blade.php ENDPATH**/ ?>