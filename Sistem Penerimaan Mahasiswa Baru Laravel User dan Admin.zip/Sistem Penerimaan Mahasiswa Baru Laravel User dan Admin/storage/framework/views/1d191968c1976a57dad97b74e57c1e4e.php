<?php $__env->startSection('title', 'Edit Verifikasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Edit Verifikasi Pendaftaran</h4>
            <form action="<?php echo e(route('verifdaftar.update', $pendaftaran->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div class="form-group">
                    <label>Nama Lengkap</label>
                    <input type="text" name="namaLengkap" class="form-control" value="<?php echo e(old('namaLengkap', $pendaftaran->namaLengkap)); ?>" required>
                </div>

                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $pendaftaran->email)); ?>" required>
                </div>

                
                <div class="form-group">
                    <label>No WhatsApp</label>
                    <input type="text" name="telepon" class="form-control" value="<?php echo e(old('telepon', $pendaftaran->telepon)); ?>" required>
                </div>

                
                <div class="form-group">
                    <label>Kelas</label>
                    <select name="kelas_id" class="form-control">
                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $pendaftaran->kelas_id ? 'selected' : ''); ?>>
                                <?php echo e($item->namaKelas); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="form-group">
                    <label>Program Studi</label>
                    <select name="prodi_id" class="form-control">
                        <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $pendaftaran->prodi_id ? 'selected' : ''); ?>>
                                <?php echo e($item->namaProdi); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div class="form-group">
                    <label>Bukti Pembayaran</label><br>
                    <?php if($bayar->nama_file_bukti_bayar): ?>
                        <img src="<?php echo e(route('verifdaftar.lihatBukti', $bayar->id)); ?>" width="100" class="mb-2"><br>
                        <small><?php echo e($bayar->nama_file_bukti_bayar); ?></small><br>
                    <?php endif; ?>
                    <input type="file" name="buktiBayar" class="form-control-file">
                </div>

                
                <div class="form-group">
                    <label>Status Pembayaran</label>
                    <select name="statusBayar" class="form-control" required>
                        <option value="pending" <?php echo e($bayar->statusBayar == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="lunas" <?php echo e($bayar->statusBayar == 'lunas' ? 'selected' : ''); ?>>Lunas</option>
                        <option value="gagal" <?php echo e($bayar->statusBayar == 'gagal' ? 'selected' : ''); ?>>Gagal</option>
                    </select>
                </div>

                <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-4">
                            <a href="<?php echo e(route('verifdaftar.index')); ?>" class="btn btn-secondary btn-icon-text">
                                <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                            </a>
                            <div>
                                <button type="reset" class="btn btn-light me-2" id="resetBtn">
                                    <i class="fa-solid fa-rotate-left me-1"></i> Reset
                                </button>
                                <button type="submit" class="btn btn-primary" id="submitBtn">
                                    <i class="fa-solid fa-save me-1"></i> Simpan Perubahan
                                </button>
                            </div>
                        </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Siti Nazwatun M\Downloads\PMB6\PMB1\resources\views/admin/verifdaftar/edit.blade.php ENDPATH**/ ?>