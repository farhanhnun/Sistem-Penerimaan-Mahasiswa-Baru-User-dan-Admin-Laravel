<?php $__env->startSection('title', 'Verifikasi Registrasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Verifikasi Pembayaran Registrasi</h4>
                            <p class="card-description">Kelola pembayaran registrasi mahasiswa baru</p>
                        </div>
                    </div>

                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <form method="GET" action="<?php echo e(route('verifregis.index')); ?>">
                                <div class="input-group">
                                    <input type="text" name="search" class="form-control" placeholder="Cari nama/email..." value="<?php echo e(request('search')); ?>">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary" type="submit">
                                            <i class="fa-solid fa-magnifying-glass"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Lengkap</th>
                                    <th>Email</th>
                                    <th>No WA</th>
                                    <th>Promo</th>
                                    <th>Jumlah Bayar</th>
                                    <th>Bukti Bayar</th>
                                    <th>Status Bayar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $registrasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr id="row-<?php echo e($data->id); ?>">
                                        <td><?php echo e($registrasis->firstItem() + $index); ?></td>
                                        <td><?php echo e($data->calonMahasiswa->namaLengkap ?? '-'); ?></td>
                                        <td><?php echo e($data->calonMahasiswa->email ?? '-'); ?></td>
                                        <td><?php echo e($data->calonMahasiswa->telepon ?? '-'); ?></td>
                                        <td><?php echo e($data->promo->namaPromo ?? '-'); ?></td>
                                        <td>Rp <?php echo e(number_format($data->totalBayar, 0, ',', '.')); ?></td>
                                        <td>
                                            <?php if($data->buktiBayar_blob): ?>
                                                <a href="<?php echo e(route('verifregis.lihatBukti', $data->id)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">Lihat File</a>
                                            <?php else: ?>
                                                <span class="badge badge-secondary">Belum Upload</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($data->statusBayar === 'lunas'): ?>
                                                <span class="badge badge-success">Lunas</span>
                                            <?php elseif($data->statusBayar === 'pending'): ?>
                                                <span class="badge badge-warning">Pending</span>
                                            <?php elseif($data->statusBayar === 'gagal'): ?>
                                                <span class="badge badge-danger">Gagal</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-nowrap">
                                            <a href="<?php echo e(route('verifregis.edit', $data->id)); ?>" class="btn btn-inverse-warning btn-sm m-1" title="Edit">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>
                                            <button class="btn btn-inverse-danger btn-sm m-1" onclick="hapusRegistrasi(<?php echo e($data->id); ?>)" title="Hapus">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                            <a href="<?php echo e(route('verifregis.show', $data->id)); ?>" class="btn btn-inverse-success btn-sm m-1" title="Lihat Detail">
                                                <i class="fa-solid fa-eye"></i>
                                            </a>
                                            
                                            <button class="btn btn-inverse-info btn-sm"
                                                    onclick="verifikasi(<?php echo e($data->id); ?>, '<?php echo e($data->calonMahasiswa->namaLengkap); ?>', '<?php echo e($data->calonMahasiswa->telepon); ?>')" title="Verifikasi">
                                                    <i class="fa-solid fa-check"></i>
                                                </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="9" class="text-center text-muted">Belum ada data pembayaran registrasi</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    
                    <?php if($registrasis->hasPages()): ?>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <div>
                                <p class="text-muted">
                                    Menampilkan <?php echo e($registrasis->firstItem()); ?> sampai <?php echo e($registrasis->lastItem()); ?> dari <?php echo e($registrasis->total()); ?> data
                                </p>
                            </div>
                            <nav>
                                <?php echo e($registrasis->links('pagination::bootstrap-4')); ?>

                            </nav>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function hapusRegistrasi(id) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Data pembayaran registrasi yang dihapus tidak bisa dikembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Ya, hapus!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch(`/verifregis/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById(`row-${id}`).remove();
                        Swal.fire('Berhasil', data.message, 'success');
                    } else {
                        Swal.fire('Gagal', data.message, 'error');
                    }
                })
                .catch(error => {
                    console.error(error);
                    Swal.fire('Error', 'Terjadi kesalahan saat menghapus.', 'error');
                });
            }
        });
    }

    function verifikasi(id, nama, no_wa) {
    Swal.fire({
        title: 'Verifikasi pembayaran?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Verifikasi',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/verifregis/verifikasi/${id}`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': token
                }
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil',
                        text: data.message,
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        // Format nomor WA
                        const formattedWa = no_wa.replace(/^0/, '62');
                        const pesan = `Halo ${nama}, pembayaran Anda telah diverifikasi. Terima kasih telah mendaftar.`;
                        const url = `https://wa.me/${formattedWa}?text=${encodeURIComponent(pesan)}`;

                        // Buka WhatsApp dan reload halaman
                        window.open(url, '_blank');
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: data.message
                    });
                }
            });
        }
    });
}


    // function verifikasiRegistrasi(id) {
    //     Swal.fire({
    //         title: 'Verifikasi pembayaran registrasi?',
    //         icon: 'question',
    //         showCancelButton: true,
    //         confirmButtonText: 'Verifikasi',
    //         cancelButtonText: 'Batal'
    //     }).then((result) => {
    //         if (result.isConfirmed) {
    //             fetch(`/verifregis/verifikasi/${id}`, {
    //                 method: 'POST',
    //                 headers: {
    //                     'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
    //                 }
    //             })
    //             .then(res => res.json())
    //             .then(data => {
    //                 if (data.success) {
    //                     Swal.fire('Berhasil', data.message, 'success');
    //                     location.reload();
    //                 } else {
    //                     Swal.fire('Gagal', data.message, 'error');
    //                 }
    //             });
    //         }
    //     });
    // }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Siti Nazwatun M\Downloads\PMB6\PMB1\resources\views/admin/verifregis/index.blade.php ENDPATH**/ ?>