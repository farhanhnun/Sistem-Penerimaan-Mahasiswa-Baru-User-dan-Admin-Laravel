<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lupa Password</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    html, body {
      height: 100vh;
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', sans-serif;
      overflow: hidden;
      background-color: #fff;
    }

    /* Lingkaran Dekoratif */
    .circle-bottom-left,
    .circle-top-right {
      position: absolute;
      border-radius: 50%;
      z-index: 0;
    }

    .circle-bottom-left {
      position: fixed;
      width: 800px;
      height: 800px;
      bottom: -300px;
      left: -250px;
      background: radial-gradient(circle at center, #019BA4, #004168);
      z-index: 0;
    }



    .circle-top-right {
      position: fixed;
      width: 300px;
      height: 300px;
      background: radial-gradient(circle at center, #019BA4, #004168);
      top: -100px;
      right: -100px;
    }

    /* Header */
    .header {
      padding: 10px 16px;
      position: relative;
      z-index: 3;
    }

    .header h1 {
      font-size: 1.8rem;
      font-weight: 700;
      color: #004168;
      margin: 0;
    }

    .header p {
      font-size: 1.2rem;
      color: #1976d2;
      margin: 0;
    }

    /* Form Card - Same as login */
    .form-card {
      background-color: white;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.1);
      max-width: 500px;
      width: 100%;
      position: relative;
      z-index: 3;
      margin-bottom: 70px;
    }

    .form-card h3 {
      text-align: center;
      font-weight: bold;
      margin-bottom: 30px;
      font-size: 28px;
      color: #004168;
    }

    .form-description {
      text-align: center;
      color: #6c757d;
      margin-bottom: 30px;
      font-size: 16px;
      line-height: 1.5;
    }

    /* Form styling to match login exactly */
    .form-label {
      font-weight: 600;
      color: #333;
      margin-bottom: 8px;
      font-size: 14px;
    }

    .form-control {
      border: 2px solid #e9ecef;
      border-radius: 10px;
      padding: 12px 16px;
      font-size: 14px;
      transition: all 0.3s ease;
      height: 48px;
    }

    .form-control:focus {
      border-color: #019BA4;
      box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.15);
      outline: none;
    }

    .btn-primary {
      background: linear-gradient(135deg, #004168 0%, #019BA4 100%);
      color: white;
      border: none;
      padding: 15px 40px;
      border-radius: 12px;
      font-weight: 700;
      font-size: 16px;
      width: 100%;
      transition: all 0.3s ease;
    }

    .btn-primary:hover {
      color: white;
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.2);
    }

    .form-link a {
      color: #004168;
      text-decoration: none;
      font-weight: 500;
    }

    .form-link a:hover {
      text-decoration: underline;
      color: #019BA4;
    }

    .form-container {
      height: calc(100vh - 80px);
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
      position: relative;
      z-index: 3;
    }

    /* Responsive Design */
    @media (max-width: 992px) {
      .form-card {
        max-width: 450px;
        padding: 35px;
      }

      .circle-bottom-left {
        width: 600px;
        height: 600px;
        bottom: -250px;
        left: -250px;
      }
    }

    @media (max-width: 768px) {
      .form-card {
        max-width: 100%;
        padding: 25px 20px;
      }

      .form-card h3 {
        font-size: 24px;
        margin-bottom: 25px;
      }

      .form-description {
        font-size: 14px;
        margin-bottom: 25px;
      }

      .circle-bottom-left {
        width: 400px;
        height: 400px;
        bottom: -150px;
        left: -150px;
      }

      .circle-top-right {
        width: 200px;
        height: 200px;
        top: -75px;
        right: -75px;
      }

      .header h1 {
        font-size: 1.5rem;
      }

      .header p {
        font-size: 1rem;
      }
    }

    @media (max-width: 576px) {
      .circle-bottom-left {
        width: 300px;
        height: 300px;
        bottom: -100px;
        left: -100px;
      }

      .circle-top-right {
        width: 150px;
        height: 150px;
        top: -50px;
        right: -50px;
      }

      .form-card {
        padding: 20px 15px;
        margin: 10px auto;
        border-radius: 10px;
      }

      .form-card h3 {
        font-size: 20px;
        margin-bottom: 20px;
      }

      .form-description {
        font-size: 13px;
        margin-bottom: 20px;
      }

      .header {
        padding: 10px;
      }

      .form-control {
        font-size: 16px;
        height: 44px;
        padding: 10px 14px;
      }

      .btn-primary {
        font-size: 14px;
        padding: 12px 25px;
      }

      .form-label {
        font-size: 13px;
      }
    }
  </style>
</head>
<body>

  <!-- Dekorasi Lingkaran -->
  <div class="circle-bottom-left"></div>
  <div class="circle-top-right"></div>

  <!-- Gambar Brand Ambassador -->
  <!-- <img src="2.png" alt="Brand Ambassador" class="brand-ambassador img-fluid"> -->

  <!-- Header -->
  <div class="header d-flex align-items-center">
     <img src="<?php echo e(asset('storage/foto/PoliteknikLP3I.png')); ?>" alt="Logo" class="img-fluid me-3" style="width: 50px; height: auto;">
    <div>
      <h1>Selamat Datang</h1>
      <p>calon mahasiswa!</p>
    </div>
  </div>

  <!-- Form Lupa Password -->
  <div class="form-container">
    <div class="form-card">
      <h3 class="text-center fw-bold mb-4">Lupa Password</h3>
      <p class="form-description">Masukkan email yang anda gunakan untuk mendaftar sebelumnya</p>

<form method="POST" action="<?php echo e(route('lupa.password.proses')); ?>">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="email" class="form-label">Email</label>
    <input type="email" class="form-control" name="email" required placeholder="Masukkan email">
  </div>
  <div class="d-grid">
    <button type="submit" class="btn btn-primary">
      <i class="fas fa-paper-plane me-2"></i> Kirim Link Reset
    </button>
  </div>
</form>

    </div>
  </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\PMB1\resources\views/maba/login/lupa_pasword.blade.php ENDPATH**/ ?>