<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* CSS Umum */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(to right, #019BA4, #004168) top,
                        #ffffff bottom;
            background-repeat: no-repeat;
            background-size: 100% 33.33%, 100% 66.67%;
            background-position: top, bottom;
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; /* Tambahkan font family */
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Header Section */
        .header-section {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            align-items: stretch;
        }

        /* SIAKAD Card */
        .siakad-card {
            width: 200px;
            background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)), url('https://placehold.co/200x150/000000/FFFFFF?text=SIAKAD'); /* Placeholder image */
            background-size: cover;
            background-position: center;
            border-radius: 15px;
            display: flex;
            align-items: flex-end;
            justify-content: center;
            padding: 20px;
            position: relative;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .siakad-button {
            background: #E1AF28;
            color: white;
            padding: 8px 20px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .siakad-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }

        /* Right Section */
        .right-section {
            flex: 1;
            display: flex;
            gap: 15px;
            flex-wrap: wrap; /* Izinkan wrap pada ukuran kecil */
        }

        /* Payment Card */
        .payment-card {
            width: 200px;
            background: linear-gradient(to right, #019BA4 0%, #004168 100%);
            border-radius: 12px;
            padding: 15px;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .payment-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        }

        .payment-icon {
            width: 60px;
            height: 60px;
            background: rgba(255,255,255,0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
            margin-bottom: 15px;
        }

        .payment-card h3 {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .payment-card p {
            font-size: 12px;
            color: rgba(255,255,255,0.9);
            line-height: 1.4;
        }

        /* Steps Container */
        .steps-container {
            flex: 1;
            background: white;
            border-radius: 12px;
            padding: 20px;
            position: relative;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .steps-wrapper {
            display: flex;
            align-items: center;
            justify-content: space-evenly;
            height: 100%;
            position: relative;
            gap: 10px;
            padding: 15px 0;
            flex-wrap: wrap; /* Izinkan wrap pada ukuran kecil */
        }

        /* Progress Line - REMOVED (sesuai kode Anda) */
        .progress-line {
            display: none;
        }

        .progress-active {
            display: none;
        }

        /* Step Cards */
        .step-card {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            cursor: pointer;
            position: relative;
            z-index: 2;
            flex: 0 1 auto;
            width: calc(20% - 8px); /* 5 kartu per baris, dengan gap 10px */
            min-width: 120px; /* Lebar minimum untuk kartu agar tidak terlalu kecil */
            padding: 10px 5px;
            margin: 0;
            transition: all 0.3s ease;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05); /* Bayangan default */
            border: 1px solid #e0e0e0; /* Border default */
            border-radius: 8px;
        }

        .step-card:hover:not(.completed) {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        }

        .step-checkbox {
            width: 50px;
            height: 50px;
            border: 3px solid #e5e7eb;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            margin: 0 auto 12px auto;
            transition: all 0.3s ease;
            background: white;
            flex-shrink: 0;
            color: #9ca3af; /* Warna ikon default abu-abu */
        }

        /* .step-icon tidak digunakan dalam struktur yang baru Anda berikan, dipertahankan saja */
        .step-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-bottom: 10px;
            transition: all 0.3s ease;
            border: 3px solid transparent;
        }

        .step-card h3 {
            font-size: 15px;
            font-weight: 600;
            margin: 0 0 8px 0;
            transition: color 0.3s ease;
            text-align: center;
            word-wrap: break-word;
            hyphens: auto;
            line-height: 1.2;
            color: #495057; /* Warna teks judul default */
        }

        .step-card p {
            font-size: 12px;
            color: #6c757d;
            line-height: 1.3;
        }

        /* --- CSS untuk status Completed --- */
        .step-card.completed {
            background-color: #d4edda; /* Warna latar belakang hijau muda */
            border-color: #198754; /* Border hijau */
            cursor: default; /* Ubah kursor */
            pointer-events: none; /* Mencegah semua event klik */
            opacity: 1; /* Pastikan tidak pudar */
            box-shadow: 0 4px 10px rgba(25, 135, 84, 0.1); /* Bayangan hijau */
        }
        .step-card.completed .step-checkbox {
            background: #198754; /* Warna latar belakang hijau saat completed */
            border-color: #198754; /* Warna border hijau saat completed */
            color: white; /* Warna ikon centang putih */
            box-shadow: 0 0 0 4px rgba(25, 135, 84, 0.2); /* Efek bayangan saat completed */
        }
        .step-card.completed h3 {
            color: #155724; /* Warna teks judul hijau tua saat completed */
        }
        .step-card.completed p {
            color: #155724; /* Warna teks deskripsi hijau tua saat completed */
        }

        /* CSS untuk step 'inactive' (belum diisi) */
        .step-card.inactive {
            background: #f8f9fa; /* Background abu-abu muda */
            border-color: #e9ecef; /* Border abu-abu muda */
        }
        .step-card.inactive .step-checkbox {
            background: #e9ecef; /* Background abu-abu muda */
            border-color: #e9ecef;
            color: #6c757d; /* Warna ikon default abu-abu */
        }
        .step-card.inactive h3 {
            color: #495057;
        }
        .step-card.inactive p {
            color: #6c757d;
        }

        /* Main Content */
        .main-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            display: flex;
            gap: 30px;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-top: 30px; /* Tambahkan margin atas */
        }

        /* Building Image */
        .building-image {
            flex: 1;
            max-width: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .building-image img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .content-info {
            flex: 1.5;
        }

        .main-title {
            color: #004168;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 30px;
        }

        .feature-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 25px;
            gap: 15px;
        }

        .feature-icon {
            width: 40px;
            height: 40px;
            background: #019BA4;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            color: white;
        }

        .feature-content h3 {
            color: black;
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .feature-content p {
            color: gray;
            font-size: 14px;
            line-height: 1.5;
            text-align: justify;
        }

        /* Responsive Design */
        @media (max-width: 991.98px) { /* Medium devices (tablets) */
            .header-section {
                flex-direction: column;
                gap: 15px;
            }

            .siakad-card {
                width: 100%;
                height: 150px; /* Adjust height for mobile */
            }

            .right-section {
                flex-direction: column;
                gap: 15px;
                flex: none; /* Lepaskan flex grow untuk column layout */
            }

            .payment-card {
                width: 100%;
            }

            .steps-container {
                padding: 15px;
            }

            .steps-wrapper {
                flex-wrap: wrap; /* Tetap wrap */
                justify-content: center; /* Pusat di tengah */
                gap: 15px;
            }

            .step-card {
                flex: 0 0 calc(50% - 10px); /* 2 kartu per baris di tablet */
                max-width: calc(50% - 10px);
                min-width: unset; /* Izinkan menyusut lebih lanjut */
            }

            .main-content {
                flex-direction: column;
                margin-top: 20px;
            }

            .building-image {
                max-width: 100%;
                padding: 10px;
            }

            .main-title {
                font-size: 24px;
                margin-bottom: 20px;
            }

            .feature-item {
                margin-bottom: 20px;
            }
        }

        @media (max-width: 575.98px) { /* Small devices (phones) */
            .siakad-card {
                height: 100px;
            }
            .step-card {
                flex: 0 0 100%; /* 1 kartu per baris di HP */
                max-width: 100%;
            }
        }
    </style>
</head>

<body>
    
    <?php echo $__env->make('partials.navbar1', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 

    <div class="container">
        <div class="header-section">
            <div class="siakad-card">
    <button class="siakad-button" onclick="window.location.href='https://siakad.plb.ac.id/'">SIAKAD</button>
</div>


            <div class="right-section">


                <div class="steps-container">
                    <div class="steps-wrapper">
                        
                        
                        
                        <div class="step-card <?php echo e((isset($userProgress) && $userProgress->biaya_pendaftaran_completed) ? 'completed' : 'inactive'); ?>"
                             onclick="handleStepClick('<?php echo e(route('form.pembayaran')); ?>', this)"
                             data-step="biaya-pendaftaran">
                            <div class="step-checkbox">
                                <?php if(isset($userProgress) && $userProgress->biaya_pendaftaran_completed): ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php else: ?>
                                    <i class="fas fa-circle"></i> 
                                <?php endif; ?>
                            </div>
                            <h3>Biaya Pendaftaran</h3>
                            <p class="step-instruction" style="<?php echo e((isset($userProgress) && $userProgress->biaya_pendaftaran_completed) ? 'display: none;' : ''); ?>">Lakukan pembayaran biaya pendaftaran</p>
                            <p class="step-command" style="<?php echo e((isset($userProgress) && $userProgress->biaya_pendaftaran_completed) ? '' : 'display: none;'); ?>">Pembayaran telah dikonfirmasi</p>
                        </div>

                        
                        
                        
                        <div class="step-card <?php echo e((isset($userProgress) && $userProgress->biaya_registrasi_completed) ? 'completed' : 'inactive'); ?>"
                             onclick="handleStepClick('<?php echo e(route('form.registrasi')); ?>', this)"
                             data-step="biaya-registrasi">
                            <div class="step-checkbox">
                                <?php if(isset($userProgress) && $userProgress->biaya_registrasi_completed): ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php else: ?>
                                    <i class="fas fa-circle"></i>
                                <?php endif; ?>
                            </div>
                            <h3>Biaya Registrasi</h3>
                            <p class="step-instruction" style="<?php echo e((isset($userProgress) && $userProgress->biaya_registrasi_completed) ? 'display: none;' : ''); ?>">Lakukan pembayaran biaya registrasi</p>
                            <p class="step-command" style="<?php echo e((isset($userProgress) && $userProgress->biaya_registrasi_completed) ? '' : 'display: none;'); ?>">Pembayaran telah dikonfirmasi</p>
                        </div>

                        
                        
                        
                        <div class="step-card <?php echo e((isset($userProgress) && $userProgress->data_pribadi_completed) ? 'completed' : 'inactive'); ?>"
                             onclick="handleStepClick('<?php echo e(route('form.data_diri')); ?>', this)"
                             data-step="data-pribadi">
                            <div class="step-checkbox">
                                <?php if(isset($userProgress) && $userProgress->data_pribadi_completed): ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php else: ?>
                                    <i class="fas fa-circle"></i>
                                <?php endif; ?>
                            </div>
                            <h3>Data Pribadi</h3>
                            <p class="step-instruction" style="<?php echo e((isset($userProgress) && $userProgress->data_pribadi_completed) ? 'display: none;' : ''); ?>">Silakan lengkapi data pribadi Anda</p>
                            <p class="step-command" style="<?php echo e((isset($userProgress) && $userProgress->data_pribadi_completed) ? '' : 'display: none;'); ?>">Data pribadi telah dilengkapi</p>
                        </div>

                        
                        
                        
                        <div class="step-card <?php echo e((isset($userProgress) && $userProgress->data_orangtua_completed) ? 'completed' : 'inactive'); ?>"
                             onclick="handleStepClick('<?php echo e(route('form.data_orangtua')); ?>', this)"
                             data-step="data-orangtua">
                            <div class="step-checkbox">
                                <?php if(isset($userProgress) && $userProgress->data_orangtua_completed): ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php else: ?>
                                    <i class="fas fa-circle"></i>
                                <?php endif; ?>
                            </div>
                            <h3>Data Orang Tua</h3>
                            <p class="step-instruction" style="<?php echo e((isset($userProgress) && $userProgress->data_orangtua_completed) ? 'display: none;' : ''); ?>">Silakan isi data orang tua/wali</p>
                            <p class="step-command" style="<?php echo e((isset($userProgress) && $userProgress->data_orangtua_completed) ? '' : 'display: none;'); ?>">Data orang tua telah dilengkapi</p>
                        </div>

                        
                        
                        
                        <div class="step-card <?php echo e((isset($userProgress) && $userProgress->asal_sekolah_completed) ? 'completed' : 'inactive'); ?>"
                             onclick="handleStepClick('<?php echo e(route('form.data_sekolah')); ?>', this)"
                             data-step="asal-sekolah">
                            <div class="step-checkbox">
                                <?php if(isset($userProgress) && $userProgress->asal_sekolah_completed): ?>
                                    <i class="fas fa-check-circle"></i>
                                <?php else: ?>
                                    <i class="fas fa-circle"></i>
                                <?php endif; ?>
                            </div>
                            <h3>Asal Sekolah</h3>
                            <p class="step-instruction" style="<?php echo e((isset($userProgress) && $userProgress->asal_sekolah_completed) ? 'display: none;' : ''); ?>">Silakan lengkapi data sekolah asal</p>
                            <p class="step-command" style="<?php echo e((isset($userProgress) && $userProgress->asal_sekolah_completed) ? '' : 'display: none;'); ?>">Data sekolah telah dilengkapi</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="main-content">
            <div class="building-image">
                <img src="<?php echo e(asset('storage/foto/gedung.png')); ?>" alt="Gedung LP3I">
            </div>

            <div class="content-info">
                <h1 class="main-title">Mengapa Kuliah di Politeknik LP3I?</h1>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-bullseye"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Praktis dan Siap Kerja</h3>
                        <p>LP3I berkomitmen menghasilkan lulusan yang relevan dengan kebutuhan industri dunia kerja.</p>
                    </div>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Kurikulum Yang Terkini</h3>
                        <p>Kurikulum LP3I selalu diupdate sesuai dengan perkembangan industri, sehingga mahasiswa memiliki pengetahuan dan keterampilan yang dibutuhkan oleh dunia kerja.</p>
                    </div>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Kampus di Lokasi Strategis</h3>
                        <p>Kurikulum LP3I selalu diupdate sesuai dengan perkembangan industri, sehingga mahasiswa memiliki pengetahuan dan keterampilan yang dibutuhkan oleh dunia kerja.</p>
                    </div>
                </div>

                <div class="feature-item">
                    <div class="feature-icon">
                        <i class="fas fa-trophy"></i>
                    </div>
                    <div class="feature-content">
                        <h3>Terdapat Banyak Beasiswa</h3>
                        <p>Kurikulum LP3I selalu diupdate sesuai dengan perkembangan industri, sehingga mahasiswa memiliki pengetahuan dan keterampilan yang dibutuhkan oleh dunia kerja.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        /**
         * Fungsi untuk menangani klik pada step-card di dashboard.
         * Mencegah navigasi jika tahapan sudah selesai (memiliki class 'completed').
         * @param {string} url - URL tujuan saat tahapan diklik.
         * @param {HTMLElement} element - Elemen div step-card yang diklik.
         */
        function handleStepClick(url, element) {
            // Periksa apakah kartu memiliki kelas 'completed'
            if (element.classList.contains('completed')) {
                console.log('Tahapan ini sudah selesai, tidak bisa diakses lagi.');
                // Tambahkan efek glow merah sementara
                element.style.boxShadow = '0 0 15px rgba(220, 53, 69, 0.7)';
                setTimeout(() => {
                    // Kembalikan bayangan ke nilai default setelah waktu tertentu
                    // Menggunakan style.removeProperty() lebih baik jika defaultnya dari CSS
                    // Jika tidak, set ke nilai default Anda: '0 2px 5px rgba(0,0,0,0.05)'
                    element.style.removeProperty('box-shadow');
                }, 700); // Durasi glow
                return; // Mencegah navigasi
            }

            // Jika tahapan belum selesai, arahkan ke URL
            window.location.href = url;
        }

        // Fungsi scroll ke section #hero
        function scrollToHero() {
            const hero = document.getElementById('hero');
            if (hero) {
                hero.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }

        // Smooth scroll untuk semua anchor link
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });

            // --- Logika untuk menampilkan pop-up registrasi sukses (jika ada) ---
            const registrationSuccessMeta = document.querySelector('meta[name="registration-success"]');
            if (registrationSuccessMeta && registrationSuccessMeta.content === 'true') {
                const username = document.querySelector('meta[name="registration-username"]').content;
                const password = document.querySelector('meta[name="registered-password"]').content;
                showVerificationModal(username, password);

                // Hapus meta tag setelah digunakan agar tidak muncul lagi jika user refresh halaman
                registrationSuccessMeta.remove();
                const usernameMeta = document.querySelector('meta[name="registration-username"]');
                if (usernameMeta) usernameMeta.remove();
                const passwordMeta = document.querySelector('meta[name="registered-password"]');
                if (passwordMeta) passwordMeta.remove();
            }

            // --- Fungsi showVerificationModal dan terkait (disertakan lengkap di sini) ---
            function showVerificationModal(username = '', password = '') {
                console.log('Showing verification modal for username:', username);

                const existingModal = document.getElementById('verificationModal');
                if (existingModal) {
                    existingModal.remove();
                }

                const modal = document.createElement('div');
                modal.className = 'modal fade';
                modal.id = 'verificationModal';
                modal.setAttribute('tabindex', '-1');
                modal.setAttribute('aria-labelledby', 'verificationModalLabel');
                modal.setAttribute('aria-hidden', 'true');
                modal.setAttribute('data-bs-backdrop', 'static');
                modal.setAttribute('data-bs-keyboard', 'false');

                const usernameText = username ? `Username: <strong>${username}</strong><br>` : '';
                const passwordText = password ? `Password: <strong>${password}</strong><br>` : '';

                modal.innerHTML = `
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content" style="border-radius: 15px; border: none; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
                            <div class="modal-body text-center p-5">
                                <div class="mb-4">
                                    <div style="background: linear-gradient(135deg, #28a745, #20c997); border-radius: 50%; width: 80px; height: 80px; margin: 0 auto; display: flex; align-items: center; justify-content: center;">
                                        <i class="fas fa-check text-white" style="font-size: 2.5rem;"></i>
                                    </div>
                                </div>
                                <h4 class="modal-title mb-3" style="color: #004168; font-weight: bold;">Registrasi Berhasil!</h4>
                                <p class="text-muted mb-4" style="font-size: 16px; line-height: 1.5;">
                                    Akun PMB Anda telah berhasil dibuat.<br><br>
                                    ${usernameText}
                                    ${passwordText}
                                    <br>Silahkan gunakan <strong>username</strong> dan <strong>password</strong> di atas untuk login.
                                </p>
                                <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                                    <button type="button" class="btn btn-primary me-md-2" onclick="redirectToLogin()" style="background: linear-gradient(135deg, #004168, #019BA4); border: none; border-radius: 10px; padding: 12px 30px; font-weight: 600;">
                                        <i class="fas fa-sign-in-alt me-2"></i>Login Sekarang
                                    </button>
                                    <button type="button" class="btn btn-outline-secondary" onclick="closeModalAndResetForm()" style="border-radius: 10px; padding: 12px 30px; font-weight: 600;">
                                        <i class="fas fa-times me-2"></i>Tutup
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);

                if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                    const bootstrapModal = new bootstrap.Modal(modal, {
                        backdrop: 'static',
                        keyboard: false
                    });
                    bootstrapModal.show();
                } else {
                    modal.style.display = 'block';
                    modal.classList.add('show');
                    document.body.classList.add('modal-open');
                    const backdrop = document.createElement('div');
                    backdrop.className = 'modal-backdrop fade show';
                    document.body.appendChild(backdrop);
                }
            }

            function redirectToLogin() {
                console.log('Redirecting to login');
                const modal = document.getElementById('verificationModal');
                if (modal) {
                    if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                        const bootstrapModal = bootstrap.Modal.getInstance(modal);
                        if (bootstrapModal) {
                            bootstrapModal.hide();
                        }
                    } else {
                        modal.style.display = 'none';
                        modal.classList.remove('show');
                        document.body.classList.remove('modal-open');
                        const backdrop = document.querySelector('.modal-backdrop');
                        if (backdrop) {
                            backdrop.remove();
                        }
                    }
                }
                setTimeout(() => {
                    window.location.href = '<?php echo e(route('login')); ?>';
                }, 300);
            }

            function closeModalAndResetForm() {
                console.log('Closing modal and resetting form');
                const modal = document.getElementById('verificationModal');
                if (modal) {
                    if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
                        const bootstrapModal = bootstrap.Modal.getInstance(modal);
                        if (bootstrapModal) {
                            bootstrapModal.hide();
                        }
                    } else {
                        modal.style.display = 'none';
                        modal.classList.remove('show');
                        document.body.classList.remove('modal-open');
                        const backdrop = document.querySelector('.modal-backdrop');
                        if (backdrop) {
                            backdrop.remove();
                        }
                    }
                }
            }
            // --- End of showVerificationModal and related functions ---

            // Logika untuk menampilkan alert success/error dari Laravel Session (jika ada)
            <?php if(session('success') && !session('show_registration_modal')): ?>
                showAlert('<?php echo e(session('success')); ?>', 'success');
            <?php endif; ?>

            <?php if(session('error')): ?>
                showAlert('<?php echo e(session('error')); ?>', 'danger');
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    showAlert('<?php echo e($error); ?>', 'danger');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            // Fungsi showAlert (disertakan lengkap di sini agar selalu tersedia)
            function showAlert(message, type = 'danger') {
                const existingAlert = document.querySelector('.alert');
                if (existingAlert) { existingAlert.remove(); }
                const alertDiv = document.createElement('div');
                alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
                alertDiv.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
                // Menggunakan document.querySelector('.container') sebagai target default yang lebih aman
                let insertTarget = document.querySelector('.container');
                if (insertTarget) { insertTarget.insertBefore(alertDiv, insertTarget.firstChild); }
                setTimeout(() => { if (alertDiv && alertDiv.parentNode) { alertDiv.classList.remove('show'); setTimeout(() => { if (alertDiv.parentNode) { alertDiv.remove(); } }, 150); } }, 5000);
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\Users\Siti Nazwatun M\Downloads\PMB6\PMB1\resources\views/maba/dashboard.blade.php ENDPATH**/ ?>