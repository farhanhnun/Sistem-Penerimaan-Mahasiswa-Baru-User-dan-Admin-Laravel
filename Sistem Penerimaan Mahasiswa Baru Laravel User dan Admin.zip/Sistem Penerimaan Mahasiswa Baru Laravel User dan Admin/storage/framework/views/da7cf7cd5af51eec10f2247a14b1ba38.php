<?php $__env->startSection('title', 'Edit Verifikasi Registrasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Edit Verifikasi Registrasi</h4>
                            <p class="card-description">Perbarui data registrasi calon mahasiswa</p>
                        </div>
                    </div>

                    <form id="verifikasiForm" action="<?php echo e(route('verifregis.update', $bayar->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        
                        <div class="form-group">
                            <label for="namaLengkap">Nama Lengkap</label>
                            <input type="text" class="form-control" id="namaLengkap" name="namaLengkap"
                                value="<?php echo e(old('namaLengkap', $bayar->calonMahasiswa->namaLengkap ?? '')); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email"
                                value="<?php echo e(old('email', $bayar->calonMahasiswa->email ?? '')); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="telepon">No WhatsApp</label>
                            <input type="text" class="form-control" id="telepon" name="telepon"
                                value="<?php echo e(old('telepon', $bayar->calonMahasiswa->telepon ?? '')); ?>" required>
                        </div>

                        
                        <div class="form-group">
                            <label for="buktiBayar">Bukti Pembayaran</label><br>
                            <?php if(!empty($bayar->nama_file_bukti_bayar)): ?>
                                <a href="<?php echo e(route('verifregis.lihatBukti', $bayar->id)); ?>" target="_blank">
                                    <span class="badge bg-info text-white">
                                        <?php echo e($bayar->nama_file_bukti_bayar); ?>

                                    </span>
                                </a>
                            <?php else: ?>
                                <span class="badge bg-secondary">Belum Upload</span>
                            <?php endif; ?>
                            <input type="file" class="form-control mt-2" name="buktiBayar">
                        </div>

                        
                        <div class="form-group">
                            <label for="statusBayar">Status Pembayaran</label>
                            <select name="statusBayar" id="statusBayar" class="form-control" required>
                                <option value="">-- Pilih Status --</option>
                                <option value="pending" <?php echo e($bayar->statusBayar == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                <option value="lunas" <?php echo e($bayar->statusBayar == 'lunas' ? 'selected' : ''); ?>>Lunas</option>
                                <option value="gagal" <?php echo e($bayar->statusBayar == 'gagal' ? 'selected' : ''); ?>>Gagal</option>
                            </select>
                        </div>

                        
                        <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-4">
                            <a href="<?php echo e(route('verifregis.index')); ?>" class="btn btn-secondary btn-icon-text">
                                <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                            </a>
                            <div>
                                <button type="reset" class="btn btn-light me-2" id="resetBtn">
                                    <i class="fa-solid fa-rotate-left me-1"></i> Reset
                                </button>
                                <button type="submit" class="btn btn-primary" id="submitBtn">
                                    <i class="fa-solid fa-save me-1"></i> Simpan Perubahan
                                </button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        $('#verifikasiForm').on('submit', function () {
            $('#submitBtn').prop('disabled', true).html(
                '<span class="spinner-border spinner-border-sm" role="status"></span> Menyimpan...'
            );
        });

        $('#resetBtn').on('click', function (e) {
            e.preventDefault();
            $('#verifikasiForm')[0].reset();
        });

        <?php if(session('success')): ?>
            Swal.fire('Berhasil', '<?php echo e(session('success')); ?>', 'success');
        <?php endif; ?>

        <?php if($errors->any()): ?>
            Swal.fire({
                icon: 'error',
                title: 'Validasi Gagal',
                html: `<?php echo implode('<br>', $errors->all()); ?>`
            });
        <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Siti Nazwatun M\Downloads\PMB6\PMB1\resources\views/admin/verifregis/edit.blade.php ENDPATH**/ ?>