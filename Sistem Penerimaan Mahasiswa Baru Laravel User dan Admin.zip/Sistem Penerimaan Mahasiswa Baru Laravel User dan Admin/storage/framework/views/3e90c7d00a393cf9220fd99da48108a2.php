<?php $__env->startSection('title', 'Data Kabupaten'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Data Kabupaten</h4>
                                <p class="card-description">Kelola data Kabupaten</p>
                            </div>
                            <a href="<?php echo e(url('kabupaten/create')); ?>" class="btn btn-primary btn-icon-text">
                                <i class="fa-solid fa-plus"></i>
                                Tambah Kabupaten
                            </a>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <form method="GET" action="<?php echo e(url('kabupaten/index')); ?>">
                                    <div class="form-group">
                                        <div class="input-group search-box">
                                            <input type="text" class="form-control" placeholder="Cari kabupaten..."
                                                name="search" value="<?php echo e(request('search')); ?>" />
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="submit">
                                                    <i class="fa-solid fa-magnifying-glass"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Kabupaten</th>
                                        <th>Nama Provinsi</th>
                                        <th width="200px">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $kabupatens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kabupaten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr id="row-<?php echo e($kabupaten->id); ?>">
                                            <td><?php echo e($kabupatens->firstItem() + $index); ?></td>
                                            <td><?php echo e($kabupaten->namaKabupaten); ?></td>
                                            <td><?php echo e($kabupaten->provinsi->namaProvinsi ?? '-'); ?></td>
                                            <td>
                                                <div class="table-actions">
                                                    <button class="btn btn-inverse-warning btn-sm"
                                                        onclick="editKabupaten(<?php echo e($kabupaten->id); ?>)" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-danger btn-sm"
                                                        onclick="deleteKabupaten(<?php echo e($kabupaten->id); ?>)" title="Hapus">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">Belum ada data Kabupaten</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        
                        <?php if($kabupatens->hasPages()): ?>
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div>
                                    <p class="text-muted">
                                        Menampilkan <?php echo e($kabupatens->firstItem()); ?> sampai
                                        <?php echo e($kabupatens->lastItem()); ?> dari <?php echo e($kabupatens->total()); ?> data
                                    </p>
                                </div>
                                <nav>
                                    <?php echo e($kabupatens->links('pagination::bootstrap-4')); ?>

                                </nav>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function deleteKabupaten(id) {
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Data kabupaten yang dihapus tidak bisa dikembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                    fetch(`/kabupaten/index/${id}`, {
                            method: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': token,
                                'Accept': 'application/json'
                            }
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                document.getElementById(`row-${id}`).remove();
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: data.message,
                                    timer: 2000,
                                    showConfirmButton: false
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal',
                                    text: data.message
                                });
                            }
                        })
                        .catch(error => {
                            console.error(error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Terjadi kesalahan',
                                text: 'Tidak dapat menghapus data.'
                            });
                        });
                }
            });
        }

        function editKabupaten(id) {
            window.location.href = `/kabupaten/edit/${id}`;
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PMB\resources\views/admin/kabupaten/index.blade.php ENDPATH**/ ?>