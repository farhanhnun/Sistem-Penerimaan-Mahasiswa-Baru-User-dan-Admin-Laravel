<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <title>Form Kabupaten</title>
    <!-- plugins:css -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.2/css/bootstrap.min.css"
    />
    <!-- Custom CSS to match Skydash theme -->
    <style>
      body {
        font-family: "Poppins", sans-serif;
        background-color: #f4f5f7;
      }
      .navbar {
        background: linear-gradient(90deg, #4b73e1 0%, #9baaf3 100%);
        padding: 0.75rem 0;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      }
      .navbar-brand {
        color: white !important;
        font-size: 1.5rem;
        font-weight: 600;
      }
      .card {
        border: none;
        border-radius: 15px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08),
          0 2px 8px rgba(0, 0, 0, 0.04);
        background: linear-gradient(135deg, #ffffff 0%, #f8f9fb 100%);
        overflow: hidden;
        position: relative;
      }
      .card::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(
          90deg,
          #4b73e1 0%,
          #667eea 50%,
          #764ba2 100%
        );
      }
      .card-body {
        padding: 2.5rem;
      }
      .card-title {
        color: #2d3748;
        font-weight: 700;
        font-size: 1.5rem;
        margin-bottom: 0.5rem;
        background: linear-gradient(135deg, #4b73e1 0%, #667eea 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
      }
      .card-description {
        color: #718096;
        font-size: 0.95rem;
        margin-bottom: 2rem;
        font-weight: 400;
      }
      .form-control {
        border: 1px solid #e3e6f0;
        border-radius: 8px;
        padding: 0.75rem 1rem;
        font-size: 0.875rem;
        transition: all 0.3s ease;
        background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
      }
      .form-control:focus {
        border-color: #4b73e1;
        box-shadow: 0 0 0 0.2rem rgba(75, 115, 225, 0.25),
          0 2px 8px rgba(75, 115, 225, 0.15);
        background: #ffffff;
        transform: translateY(-1px);
      }
      .form-group label {
        color: #495057;
        font-weight: 600;
        margin-bottom: 0.5rem;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        opacity: 0.9;
      }
      .btn-primary {
        background: linear-gradient(135deg, #4b73e1 0%, #667eea 100%);
        border: none;
        border-radius: 8px;
        padding: 0.75rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
        box-shadow: 0 3px 6px rgba(75, 115, 225, 0.3);
      }
      .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(75, 115, 225, 0.5);
        background: linear-gradient(135deg, #3d63d4 0%, #4b73e1 100%);
      }
      .btn-light {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        border: 1px solid #dee2e6;
        color: #6c757d;
        border-radius: 8px;
        padding: 0.75rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      }
      .btn-light:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
        background: linear-gradient(135deg, #e9ecef 0%, #dee2e6 100%);
        color: #495057;
      }
      .btn-secondary {
        background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
        border: none;
        color: white;
        border-radius: 8px;
        padding: 0.75rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(108, 117, 125, 0.2);
      }
      .btn-secondary:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(108, 117, 125, 0.4);
        color: white;
      }
      .container-fluid {
        padding: 2rem;
      }
      .grid-margin {
        margin-bottom: 2rem;
      }

      /* Modal Styles */
      .modal-content {
        border: none;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
      }
      .modal-header {
        background: linear-gradient(90deg, #28a745 0%, #20c997 100%);
        color: white;
        border-radius: 10px 10px 0 0;
        border-bottom: none;
      }
      .modal-title {
        font-weight: 600;
      }
      .btn-close {
        color: white;
        opacity: 0.8;
      }
      .btn-close:hover {
        opacity: 1;
      }
      .modal-body {
        padding: 2rem;
        text-align: center;
      }
      .success-icon {
        font-size: 4rem;
        color: #28a745;
        margin-bottom: 1rem;
      }
      .alert-success {
        background: linear-gradient(90deg, #d4edda 0%, #c3e6cb 100%);
        border: 1px solid #c3e6cb;
        color: #155724;
        border-radius: 8px;
      }

      /* Responsive Improvements */
      @media (max-width: 768px) {
        .container-fluid {
          padding: 1rem;
        }

        .card-body {
          padding: 1.5rem;
        }

        .card-title {
          font-size: 1.25rem;
        }

        .card-description {
          font-size: 0.875rem;
          margin-bottom: 1.5rem;
        }

        .form-control {
          padding: 0.875rem 1rem;
          font-size: 1rem;
        }

        .form-group label {
          font-size: 0.875rem;
        }

        .btn {
          padding: 0.875rem 1.25rem;
          font-size: 0.875rem;
          width: 100%;
          margin-bottom: 0.5rem;
        }

        .d-flex.justify-content-between {
          flex-direction: column-reverse;
        }

        .d-flex.align-items-center {
          flex-direction: column;
          width: 100%;
        }

        .btn-kembali {
          margin-top: 1rem;
        }

        .modal-body {
          padding: 1.5rem;
        }

        .success-icon {
          font-size: 3rem;
        }
      }

      @media (max-width: 576px) {
        .container-fluid {
          padding: 0.75rem;
        }

        .card {
          border-radius: 10px;
          margin: 0;
        }

        .card-body {
          padding: 1rem;
        }

        .card-title {
          font-size: 1.125rem;
          text-align: center;
        }

        .card-description {
          text-align: center;
          margin-bottom: 1.25rem;
        }

        .form-control {
          padding: 1rem;
          font-size: 1rem;
        }

        .form-group {
          margin-bottom: 1.25rem;
        }

        .btn {
          padding: 1rem;
          font-size: 1rem;
        }

        .modal-dialog {
          margin: 1rem;
        }

        .modal-body {
          padding: 1rem;
        }

        .success-icon {
          font-size: 2.5rem;
        }
      }

      /* Touch friendly improvements */
      @media (hover: none) and (pointer: coarse) {
        .btn {
          min-height: 48px;
        }

        .form-control {
          min-height: 48px;
        }
      }

      /* Landscape phone adjustments */
      @media (max-width: 896px) and (orientation: landscape) {
        .container-fluid {
          padding: 1rem 2rem;
        }

        .card-body {
          padding: 1.5rem 2rem;
        }
      }
    </style>
  </head>

  <body>
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-12 col-lg-8 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Form Kabupaten</h4>
              <p class="card-description">
                Formulir untuk menambah atau mengedit data Kabupaten
              </p>
              <form class="forms-sample" id="kabupatenForm">
                <div class="form-group">
                  <label for="noKabupaten">No</label>
                  <input
                    type="number"
                    class="form-control"
                    id="noKabupaten"
                    placeholder="Contoh: 1"
                    min="1"
                    required
                  />
                </div>
                <div class="form-group">
                  <label for="kabupaten">Kabupaten</label>
                  <input
                    type="text"
                    class="form-control"
                    id="kabupaten"
                    placeholder="Contoh: Bandung Barat"
                    required
                  />
                </div>
                <div class="form-group">
                  <label for="provinsi">Provinsi</label>
                  <select class="form-control" id="provinsi" required>
                    <option value="">Pilih Aksi</option>
                    <option value="Aktif">Aktif</option>
                    <option value="Non-Aktif">Non-Aktif</option>
                    <option value="Pending">Pending</option>
                    <option value="Verifikasi">Verifikasi</option>
                    <option value="Ditolak">Ditolak</option>
                  </select>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                  <a
                    href="../../pages/ui-features/asalsekolah.html"
                    class="btn btn-secondary btn-kembali"
                  >
                    <i class="fas fa-arrow-left mr-2"></i>Kembali
                  </a>
                  <div class="d-flex align-items-center">
                    <button type="submit" class="btn btn-primary mr-2">
                      <i class="fas fa-save mr-2"></i>Simpan
                    </button>
                    <button type="reset" class="btn btn-light">
                      <i class="fas fa-undo mr-2"></i>Reset
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Success Modal -->
    <div
      class="modal fade"
      id="successModal"
      tabindex="-1"
      aria-labelledby="successModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="successModalLabel">
              <i class="fas fa-check-circle mr-2"></i>Berhasil!
            </h5>
            <button
              type="button"
              class="btn-close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="success-icon">
              <i class="fas fa-check-circle"></i>
            </div>
            <h5>Data Berhasil Disimpan!</h5>
            <p class="mb-0">
              Data asal sekolah telah berhasil ditambahkan ke dalam sistem.
            </p>
            <div class="alert alert-success mt-3" id="savedDataInfo">
              <!-- Data yang disimpan akan ditampilkan di sini -->
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">
              <i class="fas fa-check mr-2"></i>OK
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.2/js/bootstrap.bundle.min.js"></script>

    <script>
      $(document).ready(function () {
        // Handle form submission
        $("#kabupatenForm").on("submit", function (e) {
          e.preventDefault();

          // Get form data
          const formData = {
          noKabupaten: $("#noKabupaten").val(),
          kabupaten: $("#kabupaten").val(),
          provinsi: $("#provinsi").val(),
        };


          // Validate required fields
          let isValid = true;
          const requiredFields = [
            "noKabupaten",
            "kabupaten",
            "provinsi",
          ];

          requiredFields.forEach((field) => {
            if (!formData[field]) {
              isValid = false;
              $(`#${field}`).addClass("is-invalid");
            } else {
              $(`#${field}`).removeClass("is-invalid");
            }
          });

          if (!isValid) {
            alert("Mohon lengkapi semua field yang wajib diisi!");
            return;
          }

          // Simulate saving process
          const saveButton = $(this).find('button[type="submit"]');
          const originalText = saveButton.html();

          // Show loading state
          saveButton
            .html('<i class="fas fa-spinner fa-spin mr-2"></i>Menyimpan...')
            .prop("disabled", true);

          // Simulate API call delay
          setTimeout(() => {
            // Reset button
            saveButton.html(originalText).prop("disabled", false);

            // Show saved data in modal
            let savedDataHtml = `
            <strong>Data yang disimpan:</strong><br>
            <small>
              <strong>No:</strong> ${formData.noKabupaten}<br>
              <strong>Kabupaten:</strong> ${formData.kabupaten}<br>
              <strong>Provinsi:</strong> ${formData.provinsi}<br>
            </small>
          `;

            $("#savedDataInfo").html(savedDataHtml);

            // Show success modal
            $("#successModal").modal("show");

            // Reset form after showing modal
            $("#asalSekolahForm")[0].reset();
          }, 1500);
        });

        // Handle modal close - could add additional actions here
        $("#successModal").on("hidden.bs.modal", function () {
          // Optional: redirect or refresh page
          console.log("Modal ditutup - data telah disimpan");
        });

        // Add some interactive effects
        $(".form-control")
          .on("focus", function () {
            $(this).parent().addClass("focused");
          })
          .on("blur", function () {
            $(this).parent().removeClass("focused");
          });

        // Real-time validation feedback
        $(".form-control[required]").on("input change", function () {
          if ($(this).val()) {
            $(this).removeClass("is-invalid").addClass("is-valid");
          } else {
            $(this).removeClass("is-valid");
          }
        });
      });
    </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\PMB\resources\views/admin/form/form_kabupaten.blade.php ENDPATH**/ ?>