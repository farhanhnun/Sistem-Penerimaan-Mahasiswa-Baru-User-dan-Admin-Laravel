<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Form Data Orang Tua</title>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
      rel="stylesheet"
    />
    <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      body {
        background: linear-gradient(to right, #019ba4, #004168) top,
          #ffffff bottom;
        background-repeat: no-repeat;
        background-size: 100% 33.33%, 100% 66.67%;
        background-position: top, bottom;
        min-height: 100vh;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
          sans-serif;
      }

      .container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 40px 20px;
      }

      .form-container {
        background-color: #ffffff;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        margin-top: 60px;
      }

      .form-title {
        text-align: center;
        font-weight: bold;
        margin-bottom: 40px;
        font-size: 28px;
        color: #004168;
      }

      .section-title {
        font-size: 18px;
        font-weight: 600;
        color: #019ba4;
        margin-bottom: 20px;
        padding-bottom: 8px;
        border-bottom: 2px solid #e9ecef;
      }

      .form-label {
        font-weight: 600;
        color: #333;
        margin-bottom: 8px;
        font-size: 14px;
      }

      .form-control,
      .form-select {
        border: 2px solid #e9ecef;
        border-radius: 10px;
        padding: 12px 16px;
        font-size: 14px;
        transition: all 0.3s ease;
        height: 48px;
      }

      .form-control:focus,
      .form-select:focus {
        border-color: #019ba4;
        box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.15);
        outline: none;
      }

      .form-section {
            background-color: #f8f9fa;   /* abu-abu muda */
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05); /* opsional */
        }

      textarea.form-control {
        height: 100px;
        resize: vertical;
      }

      .btn-next {
        background: linear-gradient(135deg, #004168 0%, #019ba4 100%);
        color: white;
        border: none;
        padding: 15px 40px;
        border-radius: 12px;
        font-weight: 700;
        font-size: 16px;
        float: right;
        margin-top: 30px;
        transition: all 0.3s ease;
      }

      .btn-next:hover {
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
      }

              .info-card {
            background: linear-gradient(135deg, #f8fdff 0%, #e8f8f9 100%);
            border: 1px solid #019BA4;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .info-card .info-title {
            color: #004168;
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 10px;
        }

        .info-card .info-text {
            color: #019BA4;
            font-size: 14px;
            line-height: 1.5;
        }

      .row-custom {
        display: flex;
        gap: 15px;
      }

      .col-custom {
        flex: 1;
      }

      .col-custom-small {
        flex: 0 0 100px;
      }

      .loading {
        opacity: 0.6;
        pointer-events: none;
      }

      .form-select:disabled {
        background-color: #f8f9fa;
        opacity: 0.6;
      }

      /* Success Popup Styles */
      .success-popup-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        opacity: 0;
        animation: fadeIn 0.3s ease forwards;
      }

      @keyframes fadeIn {
        to {
          opacity: 1;
        }
      }

      .success-popup {
        background: white;
        padding: 40px 30px;
        border-radius: 20px;
        text-align: center;
        max-width: 400px;
        width: 90%;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        transform: scale(0.7);
        animation: popIn 0.3s ease 0.1s forwards;
      }

      @keyframes popIn {
        to {
          transform: scale(1);
        }
      }

      .success-popup-icon {
        margin-bottom: 20px;
      }

      .checkmark-circle {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #28a745, #20c997);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
        position: relative;
        animation: pulse 0.6s ease-in-out;
      }

      @keyframes pulse {
        0% {
          transform: scale(0);
        }
        50% {
          transform: scale(1.1);
        }
        100% {
          transform: scale(1);
        }
      }

      .checkmark-circle i {
        color: white;
        font-size: 32px;
        animation: checkmarkAppear 0.3s ease 0.3s both;
      }

      @keyframes checkmarkAppear {
        from {
          opacity: 0;
          transform: scale(0);
        }
        to {
          opacity: 1;
          transform: scale(1);
        }
      }

      .success-popup h3 {
        color: #004168;
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 15px;
        animation: slideUp 0.3s ease 0.4s both;
      }

      .success-popup p {
        color: #666;
        font-size: 16px;
        margin-bottom: 30px;
        line-height: 1.5;
        animation: slideUp 0.3s ease 0.5s both;
      }

      @keyframes slideUp {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .btn-lanjutkan {
        background: linear-gradient(135deg, #004168 0%, #019ba4 100%);
        color: white;
        border: none;
        padding: 12px 30px;
        border-radius: 25px;
        font-weight: 600;
        font-size: 16px;
        cursor: pointer;
        transition: all 0.3s ease;
        animation: slideUp 0.3s ease 0.6s both;
        min-width: 120px;
      }

      .btn-lanjutkan:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
      }

      @media (max-width: 992px) {
        .form-container {
          padding: 30px 25px;
        }

        .form-title {
          font-size: 26px;
        }

        .row-custom {
          gap: 10px;
        }
      }

      @media (max-width: 768px) {
        .container {
          padding: 20px 15px;
        }

        .form-container {
          padding: 25px 20px;
          margin-top: 30px;
          border-radius: 12px;
        }

        .form-title {
          font-size: 24px;
          margin-bottom: 30px;
        }

        .section-title {
          font-size: 16px;
          margin-bottom: 15px;
        }

        .row-custom {
          flex-direction: column;
          gap: 0;
        }

        .col-custom-small {
          flex: 1;
        }

        .btn-next {
          width: 100%;
          float: none;
          margin-top: 20px;
          padding: 12px 30px;
        }

        .form-control,
        .form-select {
          height: 50px;
          font-size: 16px;
        }

        textarea.form-control {
          height: 80px;
        }

        .success-popup {
          padding: 30px 25px;
          max-width: 350px;
        }

        .success-popup h3 {
          font-size: 22px;
        }

        .success-popup p {
          font-size: 15px;
        }
      }

      @media (max-width: 576px) {
        body {
          background-size: 100% 25%, 100% 75%;
        }

        .container {
          padding: 15px 10px;
        }

        .form-container {
          padding: 20px 15px;
          margin-top: 20px;
          border-radius: 10px;
        }

        .form-title {
          font-size: 22px;
          margin-bottom: 25px;
        }

        .section-title {
          font-size: 15px;
          margin-bottom: 12px;
        }

        .form-label {
          font-size: 13px;
          margin-bottom: 6px;
        }

        .form-control,
        .form-select {
          height: 48px;
          padding: 10px 12px;
          font-size: 16px;
        }

        textarea.form-control {
          height: 70px;
          padding: 10px 12px;
        }

        .btn-next {
          padding: 14px 20px;
          font-size: 15px;
          margin-top: 15px;
        }

        .row-custom {
          gap: 0;
        }

        .mb-3 {
          margin-bottom: 1rem !important;
        }

        .mb-4 {
          margin-bottom: 1.25rem !important;
        }

        .success-popup {
          padding: 25px 20px;
          max-width: 320px;
        }

        .checkmark-circle {
          width: 70px;
          height: 70px;
        }

        .checkmark-circle i {
          font-size: 28px;
        }

        .success-popup h3 {
          font-size: 20px;
        }

        .success-popup p {
          font-size: 14px;
        }

        .btn-lanjutkan {
          padding: 10px 25px;
          font-size: 15px;
        }
      }

      @media (max-width: 400px) {
        .form-title {
          font-size: 20px;
          margin-bottom: 20px;
        }

        .section-title {
          font-size: 14px;
        }

        .form-container {
          padding: 15px 12px;
        }

        .btn-next {
          padding: 12px 15px;
          font-size: 14px;
        }
      }

      .alert {
        border: none;
        border-radius: 10px;
        padding: 15px 20px;
      }

      .alert-success {
        background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
        color: #155724;
      }

      .alert-warning {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
        color: #856404;
      }

      .alert-danger {
        background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
        color: #721c24;
      }

      .is-invalid {
        border-color: #dc3545 !important;
        box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.15) !important;
      }

      .invalid-feedback {
        display: block;
        width: 100%;
        margin-top: 0.25rem;
        font-size: 0.875em;
        color: #dc3545;
      }


    </style>
  </head>
  <body>
    <div class="container">
      <!-- Alert container for warnings -->
      <div id="alertContainer" style="display: none;">
        <div class="alert alert-danger" role="alert">
          <strong><i class="fas fa-exclamation-triangle me-2"></i>Peringatan!</strong>
          <span id="alertMessage">Mohon lengkapi semua field yang wajib diisi sebelum melanjutkan ke halaman berikutnya.</span>
        </div>
      </div>

      <div class="form-container">
        <h2 class="form-title">Data Orang Tua</h2>
                    <div class="info-card">
                <div class="info-title">
                    <i class="fas fa-info-circle me-2"></i>Informasi Pengisian Data
                </div>
                <div class="info-text">
                    Lengkapi semua data dengan benar sesuai dokumen resmi. Pastikan foto yang diupload jelas dan data yang dimasukkan valid.
                </div>
            </div>

        <form id="parentForm" method="POST" action="<?php echo e(route('form.data_orangtua.store')); ?>">
    <?php echo csrf_field(); ?>
          <div class="row g-4">
            <!-- Left Column - Data Ayah/Wali -->
            <div class="col-lg- col-md-12">
              <h4 class="section-title">
                <i class="fas fa-male me-2"></i>Data Ayah/Wali
              </h4>

              <div class="form-section">
              <div class="mb-3">
                <label class="form-label">Nama Ayah/Wali</label>
                <input
                  type="text"
                  class="form-control"
                  name="namaAyah"
                  placeholder="Masukkan nama lengkap ayah/wali"
                  required
                />
              </div>

              <div class="mb-3">
                <label class="form-label">Nama Ibu/Wali</label>
                <input
                  type="text"
                  class="form-control"
                  name="namaIbu"
                  placeholder="Masukkan nama lengkap ibu/wali"
                  required
                />
              </div>

              <div class="mb-3">
                <label class="form-label">No WhatsApp Orang Tua/Wali</label>
                <input
  type="tel"
  class="form-control"
  name="telepon"
  placeholder="Contoh: 08123456789"
  required
  inputmode="numeric"
  pattern="[0-9]*"
  maxlength="13"
/>
              </div>

              <div class="mb-3">
                <label class="form-label">Email</label>
                <input
                  type="email"
                  class="form-control"
                  name="email"
                  placeholder="contoh@email.com"
                  required
                />
              </div>

              <div class="mb-3">
                <label class="form-label">Agama</label>
                <select class="form-select" name="agama" required>
                  <option value="" selected disabled>Pilih agama</option>
                  <option value="islam">Islam</option>
                  <option value="kristen">Kristen</option>
                  <option value="katolik">Katolik</option>
                  <option value="hindu">Hindu</option>
                  <option value="buddha">Buddha</option>
                  <option value="konghucu">Konghucu</option>
                </select>
              </div>

              <div class="mb-3">
                <label class="form-label">Pekerjaan</label>
                <select class="form-select" name="pekerjaan" required>
                  <option value="" selected disabled>Pilih pekerjaan</option>
                  <option value="pns">PNS</option>
                  <option value="swasta">Karyawan Swasta</option>
                  <option value="wiraswasta">Wiraswasta</option>
                  <option value="petani">Petani</option>
                  <option value="pedagang">Pedagang</option>
                  <option value="buruh">Buruh</option>
                  <option value="pensiunan">Pensiunan</option>
                  <option value="ibu_rumah_tangga">Ibu Rumah Tangga</option>
                  <option value="lainnya">Lainnya</option>
                </select>
              </div>

              <div class="mb-4">
                <label class="form-label">Pendidikan Terakhir</label>
                <select class="form-select" name="pendidikanTerakhir" required>
                  <option value="" selected disabled>
                    Pilih pendidikan terakhir
                  </option>
                  <option value="sd">SD/Sederajat</option>
                  <option value="smp">SMP/Sederajat</option>
                  <option value="sma">SMA/SMK/Sederajat</option>
                </select>
              </div>
              </div>
            </div>

            <!-- Right Column - Alamat & Info Tambahan -->
            <div class="col-lg- col-md-12">
              <h4 class="section-title">
                <i class="fas fa-map-marker-alt me-2"></i>Alamat & Informasi
                Tambahan
              </h4>

              <div class="form-section">
              <!-- Provinsi -->
<div class="mb-3">
  <label class="form-label">Provinsi</label>
  <select class="form-select" name="provinsi_id" id="provinsi" required>
    <option value="" selected disabled>Pilih provinsi</option>
    <?php $__currentLoopData = $provinsis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($prov->id); ?>"><?php echo e($prov->namaProvinsi); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>

<!-- Kabupaten -->
<div class="mb-3">
  <label class="form-label">Kabupaten/Kota</label>
  <select class="form-select" name="kabupaten_id" id="kabupaten" required disabled>
    <option value="" selected disabled>Pilih kabupaten/kota</option>
  </select>
</div>

<!-- Kecamatan -->
<div class="mb-3">
  <label class="form-label">Kecamatan</label>
  <select class="form-select" name="kecamatan_id" id="kecamatan" required disabled>
    <option value="" selected disabled>Pilih kecamatan</option>
  </select>
</div>

<!-- Desa -->
<div class="mb-3">
  <label class="form-label">Desa/Kelurahan</label>
  <input type="text" class="form-control" name="desa" placeholder="Masukkan desa/kelurahan" required>
</div>


              <div class="mb-3">
                <label class="form-label">Alamat</label>
                <textarea
                  class="form-control"
                  name="alamat"
                  placeholder="Masukkan alamat lengkap"
                  required
                ></textarea>
              </div>

<div class="row mb-3">
  <div class="col-12 col-md-3">
    <label class="form-label">RT</label>
    <input
      type="text"
      class="form-control"
      name="rt"
      placeholder="RT"
      maxlength="3"
      required
    />
  </div>

  <div class="col-12 col-md-3">
    <label class="form-label">RW</label>
    <input
      type="text"
      class="form-control"
      name="rw"
      placeholder="RW"
      maxlength="3"
      required
    />
  </div>

  <div class="col-12 col-md-6">
    <label class="form-label">Kode Pos</label>
    <input
      type="text"
      class="form-control"
      name="kodepos"
      placeholder="Kode pos"
      maxlength="5"
      required
    />
  </div>
</div>


              <div class="mb-4">
                <label class="form-label">Penghasilan Per Bulan</label>
                <select class="form-select" name="penghasilan" required>
                  <option value="" selected disabled>
                    Pilih rentang penghasilan
                  </option>
                  <option value="1jt">Kurang dari Rp 1.000.000</option>
                  <option value="1-3jt">Rp 1.000.000 - Rp 3.000.000</option>
                  <option value="3-5jt">Rp 3.000.000 - Rp 5.000.000</option>
                  <option value="5-10jt">Rp 5.000.000 - Rp 10.000.000</option>
                  <option value=">10jt">Lebih dari Rp 10.000.000</option>
                </select>
              </div>

              <button type="button" id="nextButton" class="btn btn-next">
    <i class="fas fa-save me-2"></i>
    Simpan Data Orang Tua
</button>

            </div>
            </div>
          </div>
        </form>
      </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
  const provinsiSelect = document.getElementById('provinsi');
  const kabupatenSelect = document.getElementById('kabupaten');
  const kecamatanSelect = document.getElementById('kecamatan');

  provinsiSelect.addEventListener('change', function () {
    const id = this.value;
    kabupatenSelect.innerHTML = '<option value="">Loading...</option>';
    kabupatenSelect.disabled = true;
    kecamatanSelect.innerHTML = '<option value="">Pilih kecamatan</option>';
    kecamatanSelect.disabled = true;

    fetch(`/get-kabupaten/${id}`)
      .then(res => res.json())
      .then(data => {
        kabupatenSelect.innerHTML = '<option value="">Pilih kabupaten/kota</option>';
        data.forEach(item => {
          const option = document.createElement('option');
          option.value = item.id;
          option.textContent = item.namaKabupaten;
          kabupatenSelect.appendChild(option);
        });
        kabupatenSelect.disabled = false;
      });
  });

  kabupatenSelect.addEventListener('change', function () {
    const id = this.value;
    kecamatanSelect.innerHTML = '<option value="">Loading...</option>';
    kecamatanSelect.disabled = true;

    fetch(`/get-kecamatan/${id}`)
      .then(res => res.json())
      .then(data => {
        kecamatanSelect.innerHTML = '<option value="">Pilih kecamatan</option>';
        data.forEach(item => {
          const option = document.createElement('option');
          option.value = item.id;
          option.textContent = item.namaKecamatan;
          kecamatanSelect.appendChild(option);
        });
        kecamatanSelect.disabled = false;
      });
  });
});

      // Success Popup Functions
        function showSuccessPopup() {
  const popup = document.createElement('div');
  popup.className = 'success-popup-overlay';
  popup.innerHTML = `
    <div class="success-popup">
      <div class="success-popup-icon">
        <div class="checkmark-circle">
          <i class="fas fa-check"></i>
        </div>
      </div>
      <h3>Data Berhasil Disimpan!</h3>
      <p>Data orang tua telah berhasil disimpan. Silakan lanjutkan Mengisi Form Asal Sekolah.</p>
      <button class="btn-lanjutkan" id="btnLanjutkanPopup">Lanjutkan</button>
    </div>
  `;
  document.body.appendChild(popup);

  // Event setelah klik tombol "Lanjutkan"
  document.getElementById('btnLanjutkanPopup').addEventListener('click', () => {
    popup.remove();
    document.getElementById('parentForm').submit();
  });
}


      // Form validation and next button functionality
document.getElementById('nextButton').addEventListener('click', function () {
  const valid = validateAndProceed();
  if (valid) {
    // Jangan submit langsung, tunggu popup
    // form submit dilakukan setelah user klik "Lanjutkan"
  }
});


      // Also validate on form submit
      document.getElementById('parentForm').addEventListener('submit', function(e) {
  const valid = validateAndProceed();
  if (!valid) {
    e.preventDefault(); // hanya batalkan submit jika tidak valid
  }
});


      // Function to validate form and show warnings
      function validateAndProceed() {
        const form = document.getElementById('parentForm');
        const requiredFields = form.querySelectorAll('[required]');
        let isValid = true;
        let emptyFields = [];

        // Hide previous alerts
        hideAlert();

        // Remove previous invalid classes
        document.querySelectorAll('.is-invalid').forEach(field => {
          field.classList.remove('is-invalid');
          const feedback = field.parentNode.querySelector('.invalid-feedback');
          if (feedback) {
            feedback.remove();
          }
        });

        requiredFields.forEach(field => {
          const fieldName = getFieldDisplayName(field);

          if (!field.value.trim()) {
            isValid = false;
            emptyFields.push(fieldName);
            field.classList.add('is-invalid');

            // Add invalid feedback message
            const feedback = document.createElement('div');
            feedback.className = 'invalid-feedback';
            feedback.textContent = `${fieldName} wajib diisi`;
            field.parentNode.appendChild(feedback);
          }
        });

        if (!isValid) {
  return false;
} else {
  showSuccessPopup();
  // Delay submit agar popup terlihat dulu
  setTimeout(() => {
    document.getElementById('parentForm').submit();
  }, 1500);
  return true;
}
      }

      // Function to get display name for fields
      function getFieldDisplayName(field) {
        const labels = {
          'namaAyah': 'Nama Ayah/Wali',
          'namaIbu': 'Nama Ibu/Wali',
          'noTelp': 'No Telp',
          'email': 'Email',
          'agama': 'Agama',
          'pekerjaan': 'Pekerjaan',
          'pendidikan': 'Pendidikan Terakhir',
          'provinsi': 'Provinsi',
          'kabupaten': 'Kabupaten/Kota',
          'kecamatan': 'Kecamatan',
          'desa': 'Desa/Kelurahan',
          'alamat': 'Alamat',
          'rt': 'RT',
          'rw': 'RW',
          'kodepos': 'Kode Pos',
          'penghasilan': 'Penghasilan Per Bulan'
        };

        return labels[field.name] || field.name;
      }

      // Function to show alert
      function showAlert(message) {
        const alertContainer = document.getElementById('alertContainer');
        const alertMessage = document.getElementById('alertMessage');

        alertMessage.textContent = message;
        alertContainer.style.display = 'block';
        alertContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }

      // Function to hide alert
      function hideAlert() {
        const alertContainer = document.getElementById('alertContainer');
        alertContainer.style.display = 'none';
      }

      // Auto-hide alert when user starts typing in invalid fields
      document.addEventListener('input', function(e) {
        if (e.target.classList.contains('is-invalid')) {
          e.target.classList.remove('is-invalid');
          const feedback = e.target.parentNode.querySelector('.invalid-feedback');
          if (feedback) {
            feedback.remove();
          }

          // Check if there are still invalid fields
          const stillInvalidFields = document.querySelectorAll('.is-invalid');
          if (stillInvalidFields.length === 0) {
            hideAlert();
          }
        }
      });

      // Auto-hide alert when user changes select options
      document.addEventListener('change', function(e) {
        if (e.target.classList.contains('is-invalid')) {
          e.target.classList.remove('is-invalid');
          const feedback = e.target.parentNode.querySelector('.invalid-feedback');
          if (feedback) {
            feedback.remove();
          }

          // Check if there are still invalid fields
          const stillInvalidFields = document.querySelectorAll('.is-invalid');
          if (stillInvalidFields.length === 0) {
            hideAlert();
          }
        }
      });

      // Phone number validation
        document.querySelector('input[name="telepon"]').addEventListener('input', function () {
    this.value = this.value.replace(/[^0-9]/g, '');
  });

      // Postal code validation
      document.querySelector('input[name="kodepos"]').addEventListener('input', function() {
        let value = this.value.replace(/\D/g, ''); // Remove non-numeric characters
        if (value.length > 5) {
          value = value.substring(0, 5);
        }
        this.value = value;
      });

      // RT/RW validation
      document.querySelector('input[name="rt"]').addEventListener('input', function() {
        let value = this.value.replace(/\D/g, '');
        if (value.length > 3) {
          value = value.substring(0, 3);
        }
        this.value = value;
      });

      document.querySelector('input[name="rw"]').addEventListener('input', function() {
        let value = this.value.replace(/\D/g, '');
        if (value.length > 3) {
          value = value.substring(0, 3);
        }
        this.value = value;
      });
     </script>
  </body>
</html>
<?php /**PATH C:\Users\Siti Nazwatun M\Downloads\PMB6\PMB1\resources\views/maba/form/data_orangtua.blade.php ENDPATH**/ ?>