<?php $__env->startSection('title', 'Detail User'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 mx-auto grid-margin stretch-card">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h4 class="card-title mb-2">Detail User</h4>
                            <p class="card-description">Informasi lengkap data user</p>
                        </div>
                    </div>

                    <div class="mb-3">
                        <h6 class="font-weight-bold mb-1">Role:</h6>
                        <p class="p-2 "><?php echo e($user->role); ?></p>
                    </div>

                    <div class="mb-3">
                        <h6 class="font-weight-bold mb-1">Username:</h6>
                        <p class="p-2 "><?php echo e($user->username); ?></p>
                    </div>

                    <?php if($user->role === 'admin' && $user->admin): ?>
                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Nama Admin:</h6>
                            <p class="p-2 "><?php echo e($user->admin->namaAdmin); ?></p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Telepon:</h6>
                            <p class="p-2 "><?php echo e($user->admin->telepon); ?></p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Email:</h6>
                            <p class="p-2 "><?php echo e($user->admin->email); ?></p>
                        </div>
                    <?php elseif($user->role === 'calon_mahasiswa' && $user->calonMahasiswa): ?>
                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Nama Lengkap:</h6>
                            <p class="p-2 "><?php echo e($user->calonMahasiswa->namaLengkap); ?></p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Telepon:</h6>
                            <p class="p-2 "><?php echo e($user->calonMahasiswa->telepon); ?></p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Email:</h6>
                            <p class="p-2 "><?php echo e($user->calonMahasiswa->email); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="d-flex justify-content-between align-items-center pt-3 mt-4">
                        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary">
                            <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PMB1\resources\views/admin/user/show.blade.php ENDPATH**/ ?>