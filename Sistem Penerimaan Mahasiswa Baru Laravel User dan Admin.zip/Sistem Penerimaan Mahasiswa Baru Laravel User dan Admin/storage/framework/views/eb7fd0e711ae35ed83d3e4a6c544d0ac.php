<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Footer Responsive LP3I</title>

    <!-- Bootstrap 5 CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <!-- Bootstrap Icons -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
      rel="stylesheet"/>

      <style>
                /* Footer */
        .footer {
          background: linear-gradient(145deg, #2c3e50, #34495e);
          color: white;
          position: relative;
          overflow: hidden;
        }

        .footer::before {
          content: "";
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 4px;
          background: linear-gradient(90deg, #3498db, #2ecc71, #f39c12, #e74c3c);
        }

        .footer-divider {
          background: linear-gradient(
            90deg,
            transparent,
            rgba(255, 255, 255, 0.3),
            transparent
          );
          height: 2px;
          border: none;
          margin: 2rem 0;
        }

        .section-title {
          color: #fff;
          font-weight: 600;
          margin-bottom: 1rem;
          position: relative;
        }

        .title-underline {
          background: linear-gradient(90deg, #3498db, #2ecc71);
          height: 3px;
          width: 4rem;
          border-radius: 2px;
          margin-bottom: 1rem;
        }

        .social-icons a {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 40px;
          height: 40px;
          background: linear-gradient(45deg, #3498db, #2ecc71);
          color: white;
          border-radius: 50%;
          text-decoration: none;
          margin-right: 0.75rem;
          transition: all 0.3s ease;
          box-shadow: 0 4px 15px rgba(52, 152, 219, 0.3);
        }

        .social-icons a:hover {
          transform: translateY(-3px) scale(1.1);
          box-shadow: 0 8px 25px rgba(52, 152, 219, 0.5);
        }

        .contact-item {
          display: flex;
          align-items: center;
          margin-bottom: 1rem;
          color: #bdc3c7;
          transition: color 0.3s ease;
        }

        .contact-item:hover {
          color: #3498db;
        }

        .contact-item i {
          width: 20px;
          margin-right: 1rem;
          color: #3498db;
        }

        .useful-links ul {
          list-style: none;
          padding: 0;
        }

        .useful-links li {
          margin-bottom: 0.75rem;
          color: #bdc3c7;
          cursor: pointer;
          transition: all 0.3s ease;
          padding-left: 0;
        }

        .useful-links li:hover {
          color: #3498db;
          padding-left: 0.5rem;
        }

        .about-text {
          color: #bdc3c7;
          line-height: 1.6;
          text-align: justify;
        }

        .copyright {
          background: rgba(0, 0, 0, 0.2);
          padding: 1rem 0;
          margin-top: 1rem;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .copyright p {
          margin: 0;
          color: #95a5a6;
        }

        @media (max-width: 768px) {
          .footer {
            padding: 2rem 1rem !important;
          }

          .social-icons {
            justify-content: center;
            margin: 1rem 0;
          }

          .useful-links,
          .contact-info {
            text-align: center;
          }
        }
      </style>
  </head>
  <body>
  <!-- Awal Footer -->
      <footer class="footer p-5">
        <div class="container">
          <div class="row py-2 justify-content-between">
            <!-- About Us Section -->
            <div class="col-12 col-md-4 mb-4 useful-links">
              <h3 class="section-title">Seputar PLB</h3>
              <div class="title-underline"></div>
              <ul>
                <li>Mengapa PLB</li>
                <li>Jalur Masuk</li>
                <li>Testimoni Alumni</li>
                <li>Kegiatan Mahasiswa</li>
              </ul>
              <div class="social-icons d-flex py-3">
                <a href="#" aria-label="Facebook">
                  <i class="fab fa-facebook-f"></i>
                </a>
                <a href="#" aria-label="Instagram">
                  <i class="fab fa-instagram"></i>
                </a>
                <a href="#" aria-label="Twitter">
                  <i class="fab fa-twitter"></i>
                </a>
                <a href="#" aria-label="WhatsApp">
                  <i class="fab fa-whatsapp"></i>
                </a>
              </div>
            </div>

            <!-- Useful Links Section -->
            <div class="col-12 col-md-4 mb-4 useful-links">
              <h3 class="section-title">Program Studi</h3>
              <div class="title-underline"></div>
              <ul>
                <li>Administrasi Bisnis</li>
                <li>Manajemen Informatika</li>
                <li>Hubungan Masyarakat</li>
                <li>Bisnis Digital</li>
                <li>Akutansi</li>
              </ul>
            </div>

            <!-- Get in Touch Section -->
            <div class="col-12 col-md-4 mb-4 contact-info">
              <h3 class="section-title">Hubungi Kami</h3>
              <div class="title-underline"></div>

              <div class="contact-item">
                <i class="fas fa-user"></i>
                <span>Politeknik LP3I</span>
              </div>
              <div class="contact-item">
                <i class="fas fa-map-marker-alt"></i>
                <span>Jl Pahlawan</span>
              </div>
              <div class="contact-item">
                <i class="fas fa-envelope"></i>
                <span>PoliteknikLP3I@gmail.com</span>
              </div>
              <div class="contact-item">
                <i class="fas fa-globe"></i>
                <span>plb.ac.id</span>
              </div>
            </div>
          </div>

          <hr class="footer-divider" />

          <!-- Copyright Section -->
          <div class="copyright">
            <div class="row">
              <div class="col-12 text-center">
                <p>&copy; 2024 Politeknik LP3I Bandung. All rights reserved.</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
      <!-- Footer 4 Ends -->
       </body>

</html>
<?php /**PATH C:\Users\Lenovo\Downloads\PMB\resources\views/partials/footer.blade.php ENDPATH**/ ?>