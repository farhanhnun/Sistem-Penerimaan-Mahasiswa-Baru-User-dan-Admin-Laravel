<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pembayaran</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(to right, #019BA4, #004168) top,
                        #ffffff bottom;
            background-repeat: no-repeat;
            background-size: 100% 33.33%, 100% 66.67%;
            background-position: top, bottom;
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .form-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            margin-top: 60px;
        }

        .form-title {
            text-align: center;
            font-weight: bold;
            margin-bottom: 40px;
            font-size: 28px;
            color: #004168;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #019BA4;
            margin-bottom: 20px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e9ecef;
        }

        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 14px;
            transition: all 0.3s ease;
            height: 48px;
        }

        .form-control:focus, .form-select:focus {
            border-color: #019BA4;
            box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.15);
            outline: none;
        }

        .payment-info-card {
            background: linear-gradient(135deg, #019BA4 0%, #004168 100%);
            border-radius: 15px;
            padding: 25px;
            color: white;
            margin-bottom: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .payment-info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .payment-info-row:last-child {
            margin-bottom: 0;
        }

        .payment-info-label {
            font-weight: 500;
            opacity: 0.9;
        }

        .payment-info-value {
            font-weight: 700;
            font-size: 16px;
        }

        .payment-detail-card {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 12px;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid #dee2e6;
        }

        .payment-detail-title {
            font-size: 16px;
            font-weight: 600;
            color: #004168;
            margin-bottom: 15px;
            text-align: center;
        }

        .payment-detail-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            padding: 8px 0;
            border-bottom: 1px solid rgba(0,0,0,0.1);
        }

        .payment-detail-row:last-child {
            margin-bottom: 0;
            border-bottom: none;
            font-weight: 600;
            color: #004168;
            font-size: 16px;
        }

        .payment-detail-label {
            font-weight: 500;
            color: #666;
        }

        .payment-detail-value {
            font-weight: 600;
            color: #333;
        }

        .total-amount-card {
            background: linear-gradient(135deg, #E1AF28 0%, #F4C842 100%);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            color: white;
            margin: 20px 0;
            box-shadow: 0 4px 15px rgba(225, 175, 40, 0.3);
        }

        .total-amount-label {
            font-size: 14px;
            opacity: 0.9;
            margin-bottom: 5px;
        }

        .total-amount-value {
            font-size: 24px;
            font-weight: bold;
        }

        .btn-apply-promo {
            background-color: #019BA4;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            height: 48px;
            transition: all 0.3s ease;
        }

        .btn-apply-promo:hover {
            background-color: #017a80;
            color: white;
            transform: translateY(-1px);
        }

        .btn-confirm {
            background: linear-gradient(135deg, #004168 0%, #019BA4 100%);
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 16px;
            width: 100%;
            margin-top: 30px;
            transition: all 0.3s ease;
        }

        .btn-confirm:hover {
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        .file-upload {
            border: 2px dashed #019BA4;
            border-radius: 12px;
            padding: 30px 20px;
            text-align: center;
            background: linear-gradient(135deg, #f8fdff 0%, #e8f8f9 100%);
            cursor: pointer;
            transition: all 0.3s ease;
            height: 120px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .file-upload:hover {
            border-color: #004168;
            background: linear-gradient(135deg, #e8f8f9 0%, #d1f2f4 100%);
            transform: translateY(-1px);
        }

        .file-upload input[type="file"] {
            display: none;
        }

        .file-upload-text {
            color: #019BA4;
            font-size: 14px;
            font-weight: 500;
        }

        .form-check-input {
    border: 2px solid #0d6efd;
    border-radius: 4px;
    width: 20px;
    height: 20px;
    box-shadow: none;
    outline: none;
    transition: 0.3s;
}

.form-check-input:checked {
    border-color: #0d6efd;
    background-color: #0d6efd;
}

        .form-check-input:focus {
            box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.25);
        }

        .form-check-label {
            font-weight: 500;
            color: #333;
            cursor: pointer;
        }

        .payment-options {
            background-color: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin: 15px 0;
        }

        .form-check {
            margin-bottom: 12px;
            padding: 12px;
            background: white;
            border-radius: 8px;
            border: 1px solid #e9ecef;
            transition: all 0.3s ease;
        }

        .form-check:hover {
            border-color: #019BA4;
            box-shadow: 0 2px 8px rgba(1, 155, 164, 0.1);
        }

        .form-check:last-child {
            margin-bottom: 0;
        }

        .promo-section {
            background-color: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin: 15px 0;
        }

        .input-group {
            display: flex;
            gap: 10px;
            align-items: stretch;
        }

        .input-group .form-control {
            flex: 1;
            min-width: 0;
        }

        .input-group .btn-apply-promo {
            flex-shrink: 0;
            white-space: nowrap;
        }

        @media (max-width: 768px) {
            .container {
                padding: 20px 15px;
            }

            .form-container {
                padding: 25px 20px;
                margin-top: 30px;
            }

            .form-title {
                font-size: 24px;
                margin-bottom: 30px;
            }

            .payment-info-row, .payment-detail-row {
                flex-direction: column;
                align-items: flex-start;
                gap: 5px;
            }

            .input-group {
                flex-direction: column;
                gap: 10px;
            }

            .input-group .form-control {
                width: 100%;
            }

            .btn-apply-promo {
                width: 100%;
                min-height: 48px;
            }

            .total-amount-value {
                font-size: 20px;
            }
        }

        @media (max-width: 576px) {
            .promo-section {
                padding: 15px;
                margin: 10px 0;
            }

            .input-group {
                gap: 8px;
            }

            .btn-apply-promo {
                font-size: 13px;
                padding: 12px 16px;
            }
            .info-card {
                padding: 15px;
                margin-bottom: 20px;
            }

            .info-card .info-title {
                font-size: 14px;
            }

            .info-card .info-text {
                font-size: 13px;
            }
        }

        .alert {
            border: none;
            border-radius: 10px;
            padding: 15px 20px;
        }

        .alert-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
        }


       .success-popup-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
}

.success-popup {
    background: white;
    padding: 3rem 2rem;
    border-radius: 20px;
    text-align: center;
    max-width: 400px;
    width: 90%;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
}

.success-popup-icon {
    margin-bottom: 2rem;
}

.checkmark-circle {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: linear-gradient(135deg, #4CAF50, #45a049);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    box-shadow: 0 4px 20px rgba(76, 175, 80, 0.3);
}

.checkmark-circle i {
    font-size: 2.5rem;
    color: white;
    font-weight: bold;
}

.success-popup h3 {
    color: #333;
    margin-bottom: 1rem;
    font-size: 1.5rem;
    font-weight: 600;
}

.success-popup p {
    color: #666;
    margin-bottom: 2rem;
    line-height: 1.5;
    font-size: 1rem;
}

.btn-lanjutkan {
    background: linear-gradient(135deg, #17a2b8, #138496);
    color: white;
    border: none;
    padding: 12px 40px;
    border-radius: 25px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(23, 162, 184, 0.3);
}

.btn-lanjutkan:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(23, 162, 184, 0.4);
}


    .file-upload {
        border: 2px dashed #ddd;
        border-radius: 8px;
        padding: 2rem;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s ease;
        background: #f8f9fa;
    }

    .file-upload:hover {
        border-color: #007bff;
        background: #e3f2fd;
    }

    .file-upload input[type="file"] {
        display: none;
    }

    .file-upload-text {
        color: #666;
    }

    .is-invalid {
        border-color: #dc3545 !important;
        box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
    }

    .invalid-feedback {
        display: block;
        width: 100%;
        margin-top: 0.25rem;
        font-size: 0.875em;
        color: #dc3545;
    }

    .payment-detail-card {
        background: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1rem;
    }

    .payment-detail-title {
        font-weight: 600;
        color: black;
        margin-bottom: 0.75rem;
        font-size: 0.95rem;
    }

    .payment-detail-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.5rem 0;
        border-bottom: 1px solid #e9ecef;
        font-size: 0.9rem;
    }

    .payment-detail-row:last-child {
        border-bottom: none;
    }

    .payment-detail-label {
        color: black;
    }

    .payment-detail-value {
        font-weight: 500;
        color: black;
    }

    /* .total-amount-card {
        background: linear-gradient(135deg, #007bff, #0056b3);
        color: white;
        border-radius: 8px;
        padding: 1rem;
        text-align: center;
        margin-bottom: 1.5rem;
    } */

    .total-amount-label {
        font-size: 0.9rem;
        opacity: 0.9;
        margin-bottom: 0.25rem;
    }

    .total-amount-value {
        font-size: 1.5rem;
        font-weight: 700;
    }
    .form-control.is-invalid,
.form-select.is-invalid {
    border-color: #dc3545 !important;
    box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
}

        .info-card {
            background: linear-gradient(135deg, #f8fdff 0%, #e8f8f9 100%);
            border: 1px solid #019BA4;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .info-card .info-title {
            color: #004168;
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 10px;
        }

        .info-card .info-text {
            color: #019BA4;
            font-size: 14px;
            line-height: 1.5;
        }


        .form-section {
            background-color: #f8f9fa;   /* abu-abu muda */
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05); /* opsional */
        }

    </style>

</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Form Pembayaran</h2>
             <div class="info-card">
                <div class="info-title">
                    <i class="fas fa-info-circle me-2"></i>Informasi Pendaftaran
                </div>
                <div class="info-text">
                    Lengkapi semua data dengan benar. Pastikan email dan nomor HP yang didaftarkan aktif untuk menerima pesan penting.
                </div>
            </div>

<form id="paymentForm" method="POST" action="<?php echo e(route('form.pembayaran.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

        <!-- Hidden Inputs (Wajib untuk totalBayar dan promo_id) -->
    <input type="hidden" name="totalBayar" id="inputTotalBayar" value="300000">
    <input type="hidden" name="promo_id" id="promoId" value="">

                    <!-- Left Column - Data Mahasiswa -->
                    <div>
                        <h4 class="section-title">
                            <i class="fas fa-user me-2"></i>Data Mahasiswa
                        </h4>

                            <div class="form-section">
                                <!-- Nama Lengkap -->
<div class="mb-3">
    <label class="form-label">Nama Lengkap</label>
    <input type="text" class="form-control" name="nama" value="<?php echo e($calon->namaLengkap ?? ''); ?>" readonly>
</div>

<!-- Nomor WhatsApp -->
<div class="mb-3">
    <label class="form-label">Nomor WhatsApp</label>
    <input type="tel" class="form-control" name="telp" value="<?php echo e($calon->telepon ?? ''); ?>" readonly>
</div>

<!-- Email -->
<div class="mb-3">
    <label class="form-label">Email</label>
    <input type="email" class="form-control" name="email" value="<?php echo e($calon->email ?? ''); ?>" readonly>
</div>

        <!-- Kelas -->
        <div class="mb-3">
            <label class="form-label">Kelas</label>
            <select class="form-select" name="kelas_id" required>
                <option value="" disabled selected>Pilih Kelas</option>
                <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->namaKelas); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Prodi -->
        <div class="mb-3">
            <label class="form-label">Program Studi</label>
            <select class="form-select" name="prodi_id" required>
                <option value="" disabled selected>Pilih Prodi</option>
                <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->namaProdi); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>


<div class="row">
    <div class="col-lg-6">
        <h4 class="section-title">
            <i class="fas fa-money-bill-wave me-2"></i>Pilih Jenis Pembayaran
        </h4>

        <!-- Keterangan untuk pengguna -->
        <div class="alert alert-info">
            <strong>Catatan:</strong> Jika Anda hanya ingin mendaftar, tidak perlu mencentang pilihan <strong>Biaya Registrasi</strong>. Centang hanya jika Anda ingin langsung daftar dan registrasi.
        </div>

        <div class="form-section">
            <!-- Opsi Pembayaran -->
            <div class="form-check mt-3">
                <input class="form-check-input" type="checkbox" id="biayaRegistrasi" value="3000000">
                <label class="form-check-label" for="biayaRegistrasi">
                    <strong>Biaya Registrasi</strong>
                    <br><small class="text-muted">Rp 3.000.000</small>
                </label>
            </div>

            <!-- Input Promo -->
            <div class="mt-4">
                <label class="form-label">Kode Promo (Opsional)</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="promoCode" placeholder="Masukkan kode promo">
                    <button type="button" class="btn btn-apply-promo" id="applyPromo">
                        <i class="fas fa-tag me-1"></i>Terapkan
                    </button>
                </div>
            </div>

            <!-- Rincian Pembayaran -->
            <div id="paymentDetails" class="mt-4">
                <div class="payment-detail-row">
                    <span class="payment-detail-label">Biaya Pendaftaran</span>
                    <span class="payment-detail-value">Rp 300.000</span>
                </div>
                <div class="payment-detail-row" id="registrationRow" style="display: none;">
                    <span class="payment-detail-label">Biaya Registrasi</span>
                    <span class="payment-detail-value">Rp 3.000.000</span>
                </div>
                <div class="payment-detail-row" id="promoRow" style="display: none;">
                    <span class="payment-detail-label">Diskon Promo</span>
                    <span class="payment-detail-value" id="promoAmount">- Rp 0</span>
                </div>
            </div>

            <!-- Total -->
            <div class="total-amount-card">
                <div class="total-amount-label">Total Tagihan</div>
                <div class="total-amount-value" id="totalAmount">Rp 300.000</div>
            </div>
        </div>
    </div>

    <!-- Informasi Pembayaran -->
    <div class="col-lg-6">
        <h4 class="section-title">
            <i class="fas fa-credit-card me-2"></i>Informasi Pembayaran
        </h4>
        <div class="form-section">
            <div class="payment-info-card">
                <div class="payment-info-row">
                    <span class="payment-info-label">
                        <i class="fas fa-university me-2"></i>Nama Bank
                    </span>
                    <span class="payment-info-value">Bank Mandiri</span>
                </div>
                <div class="payment-info-row">
                    <span class="payment-info-label">
                        <i class="fas fa-credit-card me-2"></i>No Virtual Account
                    </span>
                    <span class="payment-info-value">1234 5678 9101 1112</span>
                </div>
                <div class="payment-info-row">
                    <span class="payment-info-label">
                        <i class="fas fa-user me-2"></i>Atas Nama
                    </span>
                    <span class="payment-info-value">Politeknik LP3I</span>
                </div>
            </div>

            <!-- Upload Bukti Pembayaran -->
            <div class="mb-3">
                <label class="form-label">Upload Bukti Pembayaran</label>
                <div class="file-upload" onclick="document.getElementById('fileInput').click()">
                    <input type="file" id="fileInput" name="buktiBayar" accept="image/*,.pdf" onchange="showFileName(this)">
                    <i class="fas fa-cloud-upload-alt fa-2x mb-2"></i>
                    <div class="file-upload-text">
                        <strong id="fileNameDisplay">Klik untuk upload file</strong>
                        <br>
                        <small>Format: JPG, PNG, PDF (Max 5MB)</small>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-confirm">
                <i class="fas fa-check-circle me-2"></i>
                Konfirmasi Pembayaran
            </button>
        </div>
    </div>
</div>
</form>
        </div>
    </div>
    <div id="popup-container"></div>
</body>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script>
function showFileName(input) {
    if (input.files && input.files[0]) {
        document.getElementById('fileNameDisplay').innerText = input.files[0].name;
    }
}

function validateWhatsApp(phoneNumber) {
    const cleanNumber = phoneNumber.replace(/\D/g, '');
    const isValid = /^08\d{10}$/.test(cleanNumber);
    return { isValid, cleanNumber };
}

function formatRupiah(amount) {
    return 'Rp ' + amount.toLocaleString('id-ID');
}

function getFieldDisplayName(field) {
    const labels = {
        'nama': 'Nama Lengkap',
        'telp': 'Nomor WhatsApp',
        'email': 'Email',
        'kelas_id': 'Kelas',
        'prodi_id': 'Program Studi'
    };
    return labels[field.name] || field.name;
}

function showError(input, message) {
    input.classList.add('is-invalid');
    const feedback = document.createElement('div');
    feedback.className = 'invalid-feedback';
    feedback.textContent = message;
    input.parentNode.appendChild(feedback);
}

function clearError(input) {
    input.classList.remove('is-invalid');
    const existing = input.parentNode.querySelector('.invalid-feedback');
    if (existing) existing.remove();
}

function clearAllErrors() {
    document.querySelectorAll('.form-control, .form-select').forEach(clearError);
}

function calculateTotal() {
    let total = 300000;
    const registrasi = document.getElementById('biayaRegistrasi');
    const regRow = document.getElementById('registrationRow');

    if (registrasi.checked) {
        total += 3000000;
        regRow.style.display = 'flex';
    } else {
        regRow.style.display = 'none';
    }

    const promoAmountText = document.getElementById('promoAmount').textContent;
    const promoDiscount = parseInt(promoAmountText.replace(/[^\d]/g, '')) || 0;
    total -= promoDiscount;

    document.getElementById('totalAmount').textContent = formatRupiah(total);
    document.getElementById('inputTotalBayar').value = total;
}

function applyPromo() {
    const promoCode = document.getElementById('promoCode').value.trim().toUpperCase();
    const promoRow = document.getElementById('promoRow');
    const promoAmount = document.getElementById('promoAmount');
    const promoIdInput = document.getElementById('promoId');

    const validPromos = {
        'DISKON10': { diskon: 30000, id: 1 },
        'MAHASISWA': { diskon: 50000, id: 2 },
        'EARLY2024': { diskon: 100000, id: 3 }
    };

    if (validPromos[promoCode]) {
        const { diskon, id } = validPromos[promoCode];
        promoAmount.textContent = '- ' + formatRupiah(diskon);
        promoRow.style.display = 'flex';
        promoIdInput.value = id;
    } else {
        promoAmount.textContent = '- Rp 0';
        promoRow.style.display = 'none';
        promoIdInput.value = '';
    }

    calculateTotal();
}

function validateAndProceed() {
    const form = document.getElementById('paymentForm');
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;

    clearAllErrors();

    const fileInput = document.getElementById('fileInput');
    const fileUpload = document.querySelector('.file-upload');
    document.querySelectorAll('.file-upload-error').forEach(e => e.remove());

    if (!fileInput.files.length) {
        isValid = false;
        fileUpload.style.border = '2px solid #dc3545';
        fileUpload.style.color = '#dc3545';

        const error = document.createElement('div');
        error.className = 'file-upload-error text-danger mt-2';
        error.innerHTML = '<i class="fas fa-exclamation-circle me-1"></i>Bukti pembayaran wajib diupload';
        fileUpload.parentNode.appendChild(error);
    } else {
        fileUpload.style.border = '2px dashed #28a745';
        fileUpload.style.color = '#28a745';
    }

    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            isValid = false;
            showError(field, `${getFieldDisplayName(field)} wajib diisi`);
        }
    });

    if (isValid) showSuccessPopup();
    else {
        const firstError = document.querySelector('.is-invalid');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            firstError.focus();
        }
    }

    return isValid;
}

function showSuccessPopup() {
    const popup = document.createElement('div');
    popup.className = 'success-popup-overlay';
    popup.innerHTML = `
        <div class="success-popup">
            <div class="success-popup-icon">
                <div class="checkmark-circle">
                    <i class="fas fa-check"></i>
                </div>
            </div>
            <h3>Data Berhasil Disimpan!</h3>
            <p>Silakan lanjutkan mengisi form Data Orang Tua.</p>
            <button class="btn-lanjutkan" onclick="closeSuccessPopup()">
                Lanjutkan
            </button>
        </div>
    `;
    document.body.appendChild(popup);
}

function closeSuccessPopup() {
    document.querySelector('.success-popup-overlay')?.remove();
    document.getElementById('paymentForm').submit();
}

document.addEventListener('DOMContentLoaded', () => {
    calculateTotal();

    document.getElementById('biayaRegistrasi').addEventListener('change', calculateTotal);
    document.getElementById('applyPromo').addEventListener('click', applyPromo);

    document.getElementById('promoCode').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            applyPromo();
        }
    });

    document.getElementById('fileInput').addEventListener('change', function () {
        showFileName(this);
    });

    document.getElementById('paymentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        if (validateAndProceed()) {
            // Form submit dilakukan di closeSuccessPopup()
        }
    });

    // Clear error saat user mulai mengetik/memilih
    document.querySelectorAll('.form-control, .form-select').forEach(input => {
        input.addEventListener('input', () => clearError(input));
        input.addEventListener('change', () => clearError(input));
    });
});
</script>
</html>
<?php /**PATH C:\xampp\htdocs\PMB\resources\views/maba/form/pembayaran.blade.php ENDPATH**/ ?>