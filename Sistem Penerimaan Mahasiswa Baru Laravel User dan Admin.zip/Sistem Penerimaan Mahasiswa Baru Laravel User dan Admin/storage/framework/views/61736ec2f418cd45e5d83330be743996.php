<!DOCTYPE html>
  <html lang="id">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <title>Navbar Gradasi LP3I</title>

      <!-- Bootstrap 5 CSS -->
      <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
        rel="stylesheet"
      />

      <!-- Bootstrap Icons -->
      <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
        rel="stylesheet"
      />
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      />

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(to right, #019BA4, #004168) top,
                        #ffffff bottom;
            background-repeat: no-repeat;
            background-size: 100% 33.33%, 100% 66.67%;
            background-position: top, bottom;
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

                /* Navbar Styles */
        .navbar-gradient {
            background: #005f73;
            border-radius: 50px;
            margin: 20px auto 10px auto; /* Reduced bottom margin */
            padding: 10px 30px;
            max-width: 1100px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .sticky-navbar {
            position: sticky;
            top: 0;
            z-index: 1030;
            animation: slideFade 0.8s ease;
        }

        @keyframes slideFade {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .navbar-brand img {
            border-radius: 4px;
            max-height: 40px;
            width: auto;
        }

        .nav-link {
            color: white !important;
            transition: rgba(0, 135, 113, 0.1);
            border-radius: 20px;
            padding: 6px 12px;
        }

        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .btn-login {
            border-radius: 25px;
            padding: 6px 20px;
            font-weight: 500;
            transition: all 0.3s ease;
            background-color: #00bcd4;
            color: #fff;
            border: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-login:hover {
            background-color: #0097a7;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            color: #fff;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .form-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            margin-top: 60px;
        }

        .form-title {
            text-align: center;
            font-weight: bold;
            margin-bottom: 40px;
            font-size: 28px;
            color: #004168;
        }

        .personal-data-layout  {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin: 15px 0;
            border: 1px solid #e9ecef;
        }

        .password-section {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin: 15px 0;
            border: 1px solid #e9ecef;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #019BA4;
            margin-bottom: 20px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e9ecef;
        }

        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 14px;
            transition: all 0.3s ease;
            height: 48px;
        }

        .form-control:focus, .form-select:focus {
            border-color: #019BA4;
            box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.15);
            outline: none;
        }

        .input-group {
            display: flex;
            align-items: stretch;
        }

        .input-group .form-control {
            border-right: none;
            border-top-right-radius: 0;
            border-bottom-right-radius: 0;
        }

        .btn-eye {
            background: none;
            border: 2px solid #e9ecef;
            border-left: none;
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
            padding: 0 12px;
            cursor: pointer;
            color: #6c757d;
            transition: all 0.3s ease;
        }

        .btn-eye:hover {
            color: #019BA4;
            border-color: #019BA4;
        }

        .input-group:focus-within .btn-eye {
            border-color: #019BA4;
        }

        .btn-daftar {
            background: linear-gradient(135deg, #004168 0%, #019BA4 100%);
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 16px;
            width: 100%;
            margin-top: 20px;
            transition: all 0.3s ease;
        }

        .btn-daftar:hover {
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        .btn-daftar:disabled {
    opacity: 0.7;
    transform: none;
}

        .password-strength {
            height: 4px;
            border-radius: 2px;
            margin-top: 8px;
            transition: all 0.3s ease;
            background-color: transparent;
        }

        .strength-weak {
            background: linear-gradient(90deg, #dc3545 0%, #dc3545 33%, transparent 33%);
        }
        .strength-medium {
            background: linear-gradient(90deg, #ffc107 0%, #ffc107 66%, transparent 66%);
        }
        .strength-strong {
            background: linear-gradient(90deg, #198754 0%, #198754 100%);
        }

        .error-message {
            color: #dc3545;
            font-size: 0.875em;
            margin-top: 0.5rem;
            font-weight: 500;
        }

        .success-message {
            color: #198754;
            font-size: 0.875em;
            margin-top: 0.5rem;
            font-weight: 500;
        }

        .is-invalid {
            border-color: #dc3545 !important;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.15);
        }

        .is-valid {
            border-color: #198754 !important;
            box-shadow: 0 0 0 0.2rem rgba(25, 135, 84, 0.15);
        }

        .info-card {
            background: linear-gradient(135deg, #f8fdff 0%, #e8f8f9 100%);
            border: 1px solid #019BA4;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .info-card .info-title {
            color: #004168;
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 10px;
        }

        .info-card .info-text {
            color: #019BA4;
            font-size: 14px;
            line-height: 1.5;
        }

        .alert {
            border: none;
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
        }

        .alert-danger {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            color: #721c24;
        }

        /* Mobile Responsive Improvements */
        @media (max-width: 991.98px) {
            .section-title {
                margin-top: 30px;
            }

            .section-title:first-child {
                margin-top: 0;
            }
        }

        @media (max-width: 768px) {
            .container {
                padding: 20px 15px;
            }

            .form-container {
                padding: 25px 20px;
                margin-top: 30px;
            }

            .form-title {
                font-size: 24px;
                margin-bottom: 30px;
            }

            .section-title {
                font-size: 16px;
                margin-bottom: 15px;
                margin-top: 25px;
            }

            .section-title:first-child {
                margin-top: 0;
            }

            .btn-daftar {
                font-size: 14px;
                padding: 12px 30px;
            }

            /* Stack form fields vertically on mobile */
            .row .col-lg-6:nth-child(2) {
                margin-top: 0;
            }
        }

        @media (max-width: 576px) {
            body {
                background-size: 100% 25%, 100% 75%;
            }

            .container {
                padding: 15px 10px;
            }

            .form-container {
                padding: 20px 15px;
                margin-top: 20px;
                border-radius: 10px;
            }

            .form-title {
                font-size: 20px;
                margin-bottom: 25px;
            }

            .section-title {
                font-size: 15px;
                margin-bottom: 12px;
                margin-top: 20px;
            }

            .section-title:first-child {
                margin-top: 0;
            }

            .form-control, .form-select {
                font-size: 16px; /* Prevent zoom on iOS */
                height: 44px;
                padding: 10px 14px;
            }

            .info-card {
                padding: 15px;
                margin-bottom: 20px;
            }

            .info-card .info-title {
                font-size: 14px;
            }

            .info-card .info-text {
                font-size: 13px;
            }

            .btn-daftar {
                font-size: 14px;
                padding: 12px 25px;
                margin-top: 15px;
            }

            .form-label {
                font-size: 13px;
            }

            .personal-data-layout {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin: 15px 0;
            border: 1px solid #e9ecef;
            }
        }

        /* Ensure proper spacing between sections on mobile */
        @media (max-width: 991.98px) {
            .form-section-personal,
            .form-section-security {
                margin-bottom: 20px;
            }
        }
    </style>
    </head>
    <body>
      <!-- NAVBAR -->
      <nav class="navbar navbar-expand-lg navbar-dark navbar-gradient sticky-navbar">
  <div class="container-fluid">
    <!-- Logo + Brand -->
    <a class="navbar-brand d-flex align-items-center me-3" href="#">
      <img
        src="<?php echo e(asset('storage/foto/PoliteknikLP3I.png')); ?>"
        alt="Logo"
        class="me-2"
        style="height: 40px; width: auto"
      />
      <span>Politeknik LP3I</span>
    </a>

    <!-- Toggle Button -->
    <button
      class="navbar-toggler"
      type="button"
      data-bs-toggle="collapse"
      data-bs-target="#navbarNav"
      aria-controls="navbarNav"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menu -->
    <div class="collapse navbar-collapse justify-content-end flex-wrap" id="navbarNav">
      <ul class="navbar-nav align-items-center">
        <li class="nav-item">
          <a class="nav-link active d-flex align-items-center" href="<?php echo e(url('/')); ?>">
            <i class="bi bi-house-door me-1"></i> Home
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link d-flex align-items-center" href="<?php echo e(url('/#alur')); ?>">
            <i class="bi bi-book me-1"></i> Alur PMB
          </a>
        </li>
        <li class="nav-item">
          <a class="btn btn-login ms-3 mt-2 mt-lg-0" href="<?php echo e(url('/login')); ?>">
            <i class="bi bi-box-arrow-in-right"></i> Login
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    </body>
  </html>


<?php /**PATH C:\Users\Lenovo\Downloads\PMB\resources\views/partials/navbar.blade.php ENDPATH**/ ?>