<?php $__env->startSection('title', 'Dashboard'); ?>

<style>
    .dropdown-toggle::after {
        display: none !important;
    }
</style>

<?php $__env->startSection('content'); ?>
    
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="row">
                    <div class="col-12 col-xl-8 mb-3 mb-xl-0">
                        <h3 class="font-weight-bold">Selamat Datang Admin</h3>
                        <h6 class="font-weight-normal mb-0">
                            Selamat datang di dashboard pendaftaran
                        </h6>
                    </div>
                    <div class="col-12 col-xl-4">
                        <div class="justify-content-end d-flex">
                            <div class="dropdown flex-md-grow-1 flex-xl-grow-0">
                                <button class="btn btn-sm btn-light bg-white dropdown-toggle" type="button"
                                    id="dropdownMenuDate2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                    <i class="fa-solid fa-calendar m-1"></i> Today (10 Jan 2021)
                                </button>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuDate2">
                                    <a class="dropdown-item" href="#">January - March</a>
                                    <a class="dropdown-item" href="#">March - June</a>
                                    <a class="dropdown-item" href="#">June - August</a>
                                    <a class="dropdown-item" href="#">August - November</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Bagian Kartu: Registrasi & Daftar -->
        <div class="row">
            <div class="col-md-6 mb-4 stretch-card transparent">
                <a href="form-registrasi.html" class="text-decoration-none text-dark w-100">
                    <div class="card card-tale h-100">
                        <div class="card-body">
                            <p class="mb-4">Registrasi</p>
                            <p class="fs-30 mb-2">4006</p>
                            <p>10.00% (30 days)</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6 mb-4 stretch-card transparent">
                <a href="form-daftar.html" class="text-decoration-none text-dark w-100">
                    <div class="card card-dark-blue h-100">
                        <div class="card-body">
                            <p class="mb-4">Daftar</p>
                            <p class="fs-30 mb-2">61344</p>
                            <p>22.00% (30 days)</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>


        <!-- Bagian Grafik: di bawah -->
        <div class="row">
            <div class="col-md-12">
                <div class="card mt-2">
                    <div class="card-body">
                        <h4 class="card-title">Grafik Pendaftaran Pertahun</h4>
                        <canvas id="grafikTahunan" height="100"></canvas>
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
    </div>



    </div>
    <!-- content-wrapper ends -->

    </div>
    <!-- main-panel ends -->
    
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script src="vendors/js/vendor.bundle.base.js"></script>

    <!-- endinject -->
    <!-- Plugin js for this page -->
    
    <script src="vendors/chart.js/Chart.min.js"></script>
    <script src="vendors/datatables.net/jquery.dataTables.js"></script>
    <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
    <script src="js/dataTables.select.min.js"></script>

    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="js/off-canvas.js"></script>
    <script src="js/hoverable-collapse.js"></script>
    <script src="js/template.js"></script>
    <script src="js/settings.js"></script>
    <script src="js/todolist.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="js/dashboard.js"></script>
    <script src="js/Chart.roundedBarCharts.js"></script>
    <!-- End custom js for this page-->

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const ctx = document.getElementById('grafikTahunan').getContext('2d');
            const grafikTahunan = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['2020', '2021', '2022', '2023', '2024'],
                    datasets: [{
                        label: 'Jumlah Pendaftaran',
                        data: [3000, 4500, 5200, 6100, 7000],
                        backgroundColor: 'rgba(54, 162, 235, 0.6)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\Downloads\PMB\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>