
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Sistem Penerimaan Mahasiswa Baru'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('css/feather.css')); ?>" />
    
    <link rel="stylesheet" href="<?php echo e(asset('css/vertical-layout-light/style.css')); ?>" />
    

    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <div class="container-scroller">
        
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                <a class="navbar-brand brand-logo mr-5" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('images/logolp3ipanjang.png')); ?>" class="mr-2" alt="logo" />
                </a>
                <a class="navbar-brand brand-logo-mini " href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('images/PoliteknikLP3I.png')); ?>" alt="logo" width="100px"/>
                </a>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item dropdown">
                        <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#"
                            data-toggle="dropdown">
                            <i class="fa-solid fa-bell mx-0"></i>
                            <span class="count"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list"
                            aria-labelledby="notificationDropdown">
                            <p class="mb-0 font-weight-normal float-left dropdown-header">
                                Notifications
                            </p>
                            <a class="dropdown-item preview-item">
                                <div class="preview-thumbnail">
                                    <div class="preview-icon bg-success">
                                        <i class="fa-solid fa-circle-info mx-0"></i>
                                    </div>
                                </div>
                                <div class="preview-item-content">
                                    <h6 class="preview-subject font-weight-normal">
                                        Application Error
                                    </h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        Just now
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item preview-item">
                                <div class="preview-thumbnail">
                                    <div class="preview-icon bg-warning">
                                        <i class="fa-solid fa-gear mx-0"></i>
                                    </div>
                                </div>
                                <div class="preview-item-content">
                                    <h6 class="preview-subject font-weight-normal">Settings</h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        Private message
                                    </p>
                                </div>
                            </a>
                            <a class="dropdown-item preview-item">
                                <div class="preview-thumbnail">
                                    <div class="preview-icon bg-info">
                                        <i class="fa-solid fa-user mx-0"></i>
                                    </div>
                                </div>
                                <div class="preview-item-content">
                                    <h6 class="preview-subject font-weight-normal">
                                        New user registration
                                    </h6>
                                    <p class="font-weight-light small-text mb-0 text-muted">
                                        2 days ago
                                    </p>
                                </div>
                            </a>
                        </div>
                    </li>
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="profileDropdown">
                            <img src="<?php echo e(asset('images/face28.jpg')); ?>" alt="profile" />
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown"
                            aria-labelledby="profileDropdown">
                            <a class="dropdown-item">
                                <i class="fa-solid fa-gear text-primary"></i>
                                Settings
                            </a>
                            <a class="dropdown-item">
                                <i class="fa-solid fa-power-off text-primary"></i>
                                Logout
                            </a>
                        </div>
                    </li>

                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                    data-toggle="offcanvas">
                    <span class="fa-solid fa-bars"></span>
                </button>
            </div>
        </nav>

        <div class="container-fluid page-body-wrapper">
            
            <div class="theme-setting-wrapper">
                <div id="settings-trigger">
                    <i class="fa-solid fa-gear"></i>
                </div>
                <div id="theme-settings" class="settings-panel">
                    <i class="settings-close fa-solid fa-xmark"></i>
                    <p class="settings-heading">SIDEBAR SKINS</p>
                    <div class="sidebar-bg-options selected" id="sidebar-light-theme">
                        <div class="img-ss rounded-circle bg-light border mr-3"></div>
                        Light
                    </div>
                    <div class="sidebar-bg-options" id="sidebar-dark-theme">
                        <div class="img-ss rounded-circle bg-dark border mr-3"></div>
                        Dark
                    </div>
                    <p class="settings-heading mt-2">HEADER SKINS</p>
                    <div class="color-tiles mx-0 px-4">
                        <div class="tiles success"></div>
                        <div class="tiles warning"></div>
                        <div class="tiles danger"></div>
                        <div class="tiles info"></div>
                        <div class="tiles dark"></div>
                        <div class="tiles default"></div>
                    </div>
                </div>
            </div>

            
<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('admin/index')); ?>">
                <i class="fa-solid fa-house menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#verfikasi" aria-expanded="false"
                aria-controls="verfikasi">
                <i class="fa-solid fa-clipboard-check menu-icon"></i>
                <span class="menu-title">Verifikasi PMB</span>
                
            </a>
            <div class="collapse" id="verfikasi">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('verifdaftar/index')); ?>">
                            Verif Pendaftaran
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('verifdaftar/duplikat')); ?>">
                            Verif Registrasi
                        </a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#inputpmb" aria-expanded="false"
                aria-controls="inputpmb">
                <i class="fa-solid fa-plus-circle menu-icon"></i>
                <span class="menu-title">Input PMB</span>
                
            </a>
            <div class="collapse" id="inputpmb">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('')); ?>">
                            Pendaftaran
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('')); ?>">
                            Registrasi
                        </a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#inputdataumum" aria-expanded="false"
                aria-controls="inputdataumum">
                <i class="fa-solid fa-database menu-icon"></i>
                <span class="menu-title">Input Data</span>
                
            </a>
            <div class="collapse" id="inputdataumum">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('prodi/index')); ?>">
                            Prodi
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('kelas/index')); ?>">
                            Kelas
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('asalsekolah/index')); ?>">
                            Asal Sekolah
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('provinsi/index')); ?>">
                            Provinsi
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('kabupaten/index')); ?>">
                            Kabupaten
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('kecamatan/index')); ?>">
                            Kecamatan
                        </a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('informasi/index')); ?>">
                <i class="fa-solid fa-circle-info menu-icon"></i>
                <span class="menu-title">Input Informasi</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('promo/index')); ?>">
                <i class="fa-solid fa-tags menu-icon"></i>
                <span class="menu-title">Input Promo</span>
            </a>
        </li>
    </ul>
</nav>

            
            <div class="main-panel">
                <?php echo $__env->yieldContent('content'); ?>

                
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">
                            Hand-crafted & made with
                            <i class="fa-solid fa-heart text-danger ml-1"></i>
                        </span>
                    </div>
                </footer>
            </div>

        </div>
    </div>

    
    <script src="<?php echo e(asset('js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('js/settings.js')); ?>"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PMB\resources\views/layout/master.blade.php ENDPATH**/ ?>