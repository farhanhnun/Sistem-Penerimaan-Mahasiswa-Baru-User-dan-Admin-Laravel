<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Data Diri PMB</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.7.32/sweetalert2.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert2/11.7.32/sweetalert2.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(to right, #019BA4, #004168) top,
                        #ffffff bottom;
            background-repeat: no-repeat;
            background-size: 100% 33.33%, 100% 66.67%;
            background-position: top, bottom;
            min-height: 100vh;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .form-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            margin-top: 60px;
        }

        .form-title {
            text-align: center;
            font-weight: bold;
            margin-bottom: 40px;
            font-size: 28px;
            color: #004168;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: #019BA4;
            margin-bottom: 20px;
            margin-top: 30px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e9ecef;
        }

        .section-title:first-child {
            margin-top: 0;
        }

        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-control, .form-select {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 12px 16px;
            font-size: 14px;
            transition: all 0.3s ease;
            height: 48px;
        }

        .form-control:focus, .form-select:focus {
            border-color: #019BA4;
            box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.15);
            outline: none;
        }

        .btn-simpan {
            background: linear-gradient(135deg, #004168 0%, #019BA4 100%);
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 12px;
            font-weight: 700;
            font-size: 16px;
            width: 100%;
            margin-top: 30px;
            transition: all 0.3s ease;
        }

        .btn-simpan:hover {
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.2);
        }

        .error-message {
            color: #dc3545;
            font-size: 0.875em;
            margin-top: 0.5rem;
            font-weight: 500;
        }

        .success-message {
            color: #198754;
            font-size: 0.875em;
            margin-top: 0.5rem;
            font-weight: 500;
        }

        .is-invalid {
            border-color: #dc3545 !important;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.15);
        }

        .is-valid {
            border-color: #198754 !important;
            box-shadow: 0 0 0 0.2rem rgba(25, 135, 84, 0.15);
        }

        .info-card {
            background: linear-gradient(135deg, #f8fdff 0%, #e8f8f9 100%);
            border: 1px solid #019BA4;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
        }

        .info-card .info-title {
            color: #004168;
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 10px;
        }

        .info-card .info-text {
            color: #019BA4;
            font-size: 14px;
            line-height: 1.5;
        }

        .alert {
            border: none;
            border-radius: 10px;
            padding: 15px 20px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
        }

        .alert-danger {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            color: #721c24;
        }

        /* Photo Upload Styles */
        .photo-upload {
            position: relative;
            width: 150px;
            height: 150px;
            border: 3px dashed #019BA4;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            background: linear-gradient(135deg, #f8fdff 0%, #e8f8f9 100%);
        }

        .photo-upload:hover {
            border-color: #004168;
            background: linear-gradient(135deg, #e8f8f9 0%, #d1f2f4 100%);
        }

        .photo-upload.has-image {
            border-style: solid;
            border-color: #019BA4;
            padding: 5px;
        }

        .photo-preview {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 10px;
        }

        .photo-placeholder {
            text-align: center;
            color: #019BA4;
        }

        .photo-placeholder i {
            font-size: 30px;
            margin-bottom: 8px;
            display: block;
        }

        .photo-placeholder .upload-text {
            font-size: 11px;
            font-weight: 500;
        }

        #foto {
            display: none;
        }

        /* Date Input */
        .date-input {
            width: 100%;
        }

        /* Address Section */
        .address-section {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            margin: 15px 0;
            border: 1px solid #e9ecef;
        }

        /* School Search */
        .school-search-container {
            position: relative;
        }

        .school-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 2px solid #019BA4;
            border-top: none;
            border-radius: 0 0 10px 10px;
            max-height: 200px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }

        .school-suggestion {
            padding: 10px 16px;
            cursor: pointer;
            border-bottom: 1px solid #e9ecef;
            transition: background-color 0.2s ease;
        }

        .school-suggestion:hover,
        .school-suggestion.active {
            background-color: #f8f9fa;
        }

        .school-suggestion:last-child {
            border-bottom: none;
        }

        /* Personal Data Layout */
        .personal-data-layout {
            background: #f8f9fa;
            display: flex;
            gap: 30px;
            align-items: flex-start;
        }

        .photo-section {
            flex-shrink: 0;
        }

        .data-fields {
            flex: 1;
        }

        /* Mobile Responsive Improvements */
        @media (max-width: 991.98px) {
            .section-title {
                margin-top: 30px;
            }

            .section-title:first-child {
                margin-top: 0;
            }

            .personal-data-layout {

                flex-direction: column;
                align-items: center;
                gap: 20px;
            }
        }

        @media (max-width: 768px) {
            .container {
                padding: 20px 15px;
            }

            .form-container {
                padding: 25px 20px;
                margin-top: 30px;
            }

            .form-title {
                font-size: 24px;
                margin-bottom: 30px;
            }

            .section-title {
                font-size: 16px;
                margin-bottom: 15px;
                margin-top: 25px;
            }

            .section-title:first-child {
                margin-top: 0;
            }

            .btn-simpan {
                font-size: 14px;
                padding: 12px 30px;
            }

            .photo-upload {
                width: 120px;
                height: 120px;
            }

            .personal-data-layout {
                gap: 15px;
            }
        }

        @media (max-width: 576px) {
            body {
                background-size: 100% 25%, 100% 75%;
            }

            .container {
                padding: 15px 10px;
            }

            .form-container {
                padding: 20px 15px;
                margin-top: 20px;
                border-radius: 10px;
            }

            .form-title {
                font-size: 20px;
                margin-bottom: 25px;
            }

            .section-title {
                font-size: 15px;
                margin-bottom: 12px;
                margin-top: 20px;
            }

            .section-title:first-child {
                margin-top: 0;
            }

            .form-control, .form-select {
                font-size: 16px; /* Prevent zoom on iOS */
                height: 44px;
                padding: 10px 14px;
            }

            .address-section {
                padding: 15px;
                margin: 10px 0;
            }

            .info-card {
                padding: 15px;
                margin-bottom: 20px;
            }

            .info-card .info-title {
                font-size: 14px;
            }

            .info-card .info-text {
                font-size: 13px;
            }

            .btn-simpan {
                font-size: 14px;
                padding: 12px 25px;
                margin-top: 20px;
            }

            .form-label {
                font-size: 13px;
            }

            .photo-upload {
                width: 100px;
                height: 100px;
            }

            .photo-placeholder i {
                font-size: 25px;
                margin-bottom: 5px;
            }

            .photo-placeholder .upload-text {
                font-size: 10px;
            }

            .personal-data-layout {
                gap: 12px;
            }

            .school-suggestions {
                    position: absolute;
                    background: #fff;
                    border: 1px solid #ddd;
                    max-height: 200px;
                    overflow-y: auto;
                    z-index: 10;
                    width: 100%;
                }

                .school-suggestions div {
                    padding: 8px;
                    cursor: pointer;
                }

                .school-suggestions div:hover {
                    background-color: #f0f0f0;
                }
                .alert {
    animation: slideDown 0.3s ease-out;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h2 class="form-title">Form Data Diri PMB</h2>

            <div class="info-card">
                <div class="info-title">
                    <i class="fas fa-info-circle me-2"></i>Informasi Pengisian Data
                </div>
                <div class="info-text">
                    Lengkapi semua data dengan benar sesuai dokumen resmi. Pastikan foto yang diupload jelas dan data yang dimasukkan valid.
                </div>
            </div>

            <form id="dataForm" method="POST" action="<?php echo e(route('form.data-diri.store')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
                <!-- Personal Data Section with Photo -->
                <div class="form-section-personal">
                    <h4 class="section-title">
                        <i class="fas fa-user me-2"></i>Data Pribadi
                    </h4>

                    <div class="personal-data-layout">
                        <!-- Photo Section -->
                        <div class="photo-section">
                            <div class="photo-upload" onclick="document.getElementById('foto').click()">
                                <input type="file" id="foto" name="foto" accept="image/*" required>
                                <div class="photo-placeholder" id="photo-placeholder">
                                    <i class="fas fa-camera"></i>
                                    <div class="upload-text">Upload Foto</div>
                                </div>
                            </div>
                            <div class="error-message" id="foto-error"></div>
                            <small class="text-muted d-block text-center mt-2">JPG/PNG, max 2MB</small>
                        </div>

                        <!-- Data Fields -->
                        <div class="data-fields">
                            <div class="row">
                                <div class="col-lg-6 mb-3">
                                    <label for="namaLengkap" class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                       <input type="text" class="form-control" id="namaLengkap" name="namaLengkap" value="<?php echo e($calon->namaLengkap ?? ''); ?>" readonly>
                                    <div class="error-message" id="namaLengkap-error"></div>
                                </div>

                                <div class="col-lg-6 mb-3">
                                    <label for="nik" class="form-label">NIK <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="nik" name="nik" placeholder="16 digit NIK" maxlength="16" required>
                                    <div class="error-message" id="nik-error"></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-4 mb-3">
                                    <label for="tempatLahir" class="form-label">Tempat Lahir <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="tempatLahir" name="tempatLahir" placeholder="Kota tempat lahir" required>
                                    <div class="error-message" id="tempatLahir-error"></div>
                                </div>

                                <div class="col-lg-8 mb-3">
                                    <label for="tanggalLahir" class="form-label">Tanggal Lahir <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control date-input" id="tanggalLahir" name="tanggalLahir" required>
                                    <div class="error-message" id="tanggalLahir-error"></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-6 mb-3">
                                    <label for="jenisKelamin" class="form-label">Jenis Kelamin <span class="text-danger">*</span></label>
                                    <select class="form-select" id="jenisKelamin" name="jnsKelamin" required>
    <option value="">Pilih jenis kelamin</option>
    <option value="L">Laki-laki</option>
    <option value="P">Perempuan</option>
</select>
                                    <div class="error-message" id="jenisKelamin-error"></div>
                                </div>

                                <div class="col-lg-6 mb-3">
                                    <label for="agama" class="form-label">Agama <span class="text-danger">*</span></label>
                                    <select class="form-select" id="agama" name="agama" required>
                                        <option value="">Pilih agama</option>
                                        <option value="Islam">Islam</option>
                                        <option value="Kristen Protestan">Kristen Protestan</option>
                                        <option value="Kristen Katolik">Kristen Katolik</option>
                                        <option value="Hindu">Hindu</option>
                                        <option value="Buddha">Buddha</option>
                                        <option value="Konghucu">Konghucu</option>
                                    </select>
                                    <div class="error-message" id="agama-error"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Address Section -->
                <div class="form-section-address">
                    <h4 class="section-title">
                        <i class="fas fa-map-marker-alt me-2"></i>Alamat
                    </h4>

                    <div class="address-section">
                        <div class="row">
                            <div class="col-lg-6 mb-3">
                                <label for="provinsi" class="form-label">Provinsi <span class="text-danger">*</span></label>
                                <select class="form-select" id="provinsi" name="provinsi_id" required>
    <option value="">Pilih provinsi</option>
    <?php $__currentLoopData = $provinsis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provinsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($provinsi->id); ?>"><?php echo e($provinsi->namaProvinsi); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

                                <div class="error-message" id="provinsi-error"></div>
                            </div>

                            <div class="col-lg-6 mb-3">
                                <label for="kabupatenKota" class="form-label">Kabupaten/Kota <span class="text-danger">*</span></label>
                              <select class="form-select" id="kabupatenKota" name="kabupaten_id" required>
    <option value="">Pilih kabupaten/kota</option>
</select>
                                <div class="error-message" id="kabupatenKota-error"></div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-6 mb-3">
                                <label for="kecamatan" class="form-label">Kecamatan <span class="text-danger">*</span></label>
                               <select class="form-select" id="kecamatan" name="kecamatan_id" required>
    <option value="">Pilih kecamatan</option>
</select>
                                <div class="error-message" id="kecamatan-error"></div>
                            </div>

                            <div class="col-lg-6 mb-3">
    <label for="kelurahanDesa" class="form-label">Kelurahan/Desa <span class="text-danger">*</span></label>
    <input type="text" class="form-control" id="kelurahanDesa" name="kelurahan" placeholder="Masukkan kelurahan/desa" required>
    <div class="error-message" id="kelurahanDesa-error"></div>
</div>

                        </div>

                        <div class="row">
    <div class="col-lg-4 mb-3">
        <label for="rt" class="form-label">RT <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="rt" name="rt" placeholder="Contoh: 01" maxlength="3" inputmode="numeric" pattern="[0-9]*" required>
        <div class="error-message text-danger" id="rt-error"></div>
    </div>

    <div class="col-lg-4 mb-3">
        <label for="rw" class="form-label">RW <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="rw" name="rw" placeholder="Contoh: 07" maxlength="3" inputmode="numeric" pattern="[0-9]*" required>
        <div class="error-message text-danger" id="rw-error"></div>
    </div>

    <div class="col-lg-4 mb-3">
        <label for="kodePos" class="form-label">Kode Pos <span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="kodePos" name="kodePos" placeholder="Contoh: 405112" maxlength="6" inputmode="numeric" pattern="[0-9]*" required>
        <div class="error-message text-danger" id="kodePos-error"></div>
    </div>
</div>


                        <div class="mb-3">
                            <label for="alamatLengkap" class="form-label">Alamat Lengkap <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="alamatLengkap" name="alamatLengkap" rows="3" placeholder="Masukkan alamat lengkap dengan detail (nama jalan, nomor rumah, dll)" required></textarea>
                            <div class="error-message" id="alamatLengkap-error"></div>
                        </div>
                    </div>
                </div>

                <!-- Contact Section -->

                <div class="row justify-content-center">
                    <div class="col-12 col-md-8 col-lg-6">
                        <button type="submit" class="btn btn-simpan">
                            <i class="fas fa-save me-2"></i>
                            Simpan Data Diri
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const provinsiSelect = document.getElementById('provinsi');
    const kabupatenSelect = document.getElementById('kabupatenKota');
    const kecamatanSelect = document.getElementById('kecamatan');

    // Fungsi input hanya angka
    ['nik', 'rt', 'rw', 'kodePos'].forEach(id => {
        const input = document.getElementById(id);
        input.addEventListener('input', () => {
            input.value = input.value.replace(/[^0-9]/g, '');
        });
    });

    // Load kabupaten berdasarkan provinsi
    provinsiSelect.addEventListener('change', function () {
        const provId = this.value;
        kabupatenSelect.innerHTML = '<option value="">Pilih kabupaten/kota</option>';
        kecamatanSelect.innerHTML = '<option value="">Pilih kecamatan</option>';
        kabupatenSelect.disabled = true;
        kecamatanSelect.disabled = true;

        if (provId) {
            fetch(`/get-kabupaten/${provId}`)
                .then(res => res.json())
                .then(data => {
                    data.forEach(kab => {
                        kabupatenSelect.innerHTML += `<option value="${kab.id}">${kab.namaKabupaten}</option>`;
                    });
                    kabupatenSelect.disabled = false;
                });
        }
    });

    // Load kecamatan berdasarkan kabupaten
    kabupatenSelect.addEventListener('change', function () {
        const kabId = this.value;
        kecamatanSelect.innerHTML = '<option value="">Pilih kecamatan</option>';
        kecamatanSelect.disabled = true;

        if (kabId) {
            fetch(`/get-kecamatan/${kabId}`)
                .then(res => res.json())
                .then(data => {
                    data.forEach(kec => {
                        kecamatanSelect.innerHTML += `<option value="${kec.id}">${kec.namaKecamatan}</option>`;
                    });
                    kecamatanSelect.disabled = false;
                });
        }
    });


    // Validasi real-time
    document.querySelectorAll('input, select').forEach(element => {
        element.addEventListener('blur', () => validateField(element));
    });

    function validateField(el) {
        const error = document.getElementById(`${el.id}-error`);
        if (el.hasAttribute('required') && (!el.value || el.value.trim() === '')) {
            el.classList.add('is-invalid');
            if (error) error.textContent = 'Field ini wajib diisi';
        } else {
            el.classList.remove('is-invalid');
            if (error) error.textContent = '';
        }
    }

    document.getElementById('foto').addEventListener('change', function(e) {
        const file = e.target.files[0];
        const previewContainer = document.getElementById('photo-placeholder');
        const errorMessage = document.getElementById('foto-error');

        if (file) {
            if (!file.type.startsWith('image/')) {
                errorMessage.textContent = 'File harus berupa gambar.';
                return;
            }

            if (file.size > 2 * 1024 * 1024) {
                errorMessage.textContent = 'Ukuran gambar maksimal 2MB.';
                return;
            }

            const reader = new FileReader();
            reader.onload = function(event) {
                previewContainer.innerHTML = `
                    <img src="${event.target.result}" class="photo-preview" alt="Preview Foto">
                `;
            };
            reader.readAsDataURL(file);
        }
    });

    // Validasi dan submit form
document.getElementById('dataForm').addEventListener('submit', function (e) {
    e.preventDefault(); // cegah submit default dulu

    let valid = true;
    const fields = ['foto', 'namaLengkap', 'nik', 'tempatLahir', 'tanggalLahir',
                    'jenisKelamin', 'agama', 'provinsi', 'kabupatenKota', 'kecamatan',
                    'kelurahanDesa', 'rt', 'rw', 'kodePos', 'alamatLengkap'];

    fields.forEach(id => {
        const el = document.getElementById(id);
        if (el && (!el.value || el.value.trim() === '')) {
            el.classList.add('is-invalid');
            const error = document.getElementById(`${id}-error`);
            if (error) error.textContent = 'Field ini wajib diisi';
            valid = false;
        }
    });

    // Validasi panjang NIK
    const nik = document.getElementById('nik');
    if (nik.value.length !== 16) {
        nik.classList.add('is-invalid');
        document.getElementById('nik-error').textContent = 'NIK harus 16 digit';
        valid = false;
    }

    if (!valid) {
        // kalau tidak valid, scroll ke error
        document.querySelector('.is-invalid')?.scrollIntoView({ behavior: 'smooth' });
        return;
    }

    // ✅ jika valid, tampilkan SweetAlert dan submit
    Swal.fire({
        icon: 'success',
        title: 'Data Berhasil Disimpan!',
        text: 'Silakan lanjutkan mengisi form Data Orang Tua.',
        confirmButtonText: 'Lanjutkan',
        confirmButtonColor: '#019BA4',
        allowOutsideClick: false
    }).then((result) => {
        if (result.isConfirmed) {
            // submit form setelah modal ditutup
            document.getElementById('dataForm').submit();
        }
    });
});
});
</script>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\PMB1\resources\views/maba/form/data_diri.blade.php ENDPATH**/ ?>