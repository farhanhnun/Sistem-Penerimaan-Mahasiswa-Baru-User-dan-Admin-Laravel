<?php $__env->startSection('title', 'Detail Promo'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 mx-auto grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Detail Promo</h4>
                                <p class="card-description">Informasi lengkap data promo</p>
                            </div>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Nama Promo:</h6>
                            <p class="p-2 rounded "><?php echo e($promo->namaPromo); ?></p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Jenis Promo:</h6>
                            <p class="p-2 rounded "><?php echo e($promo->jnsPromo); ?></p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Jumlah Promo:</h6>
                            <p class="p-2 rounded "><?php echo e($promo->jmlPromo); ?></p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Tanggal Mulai:</h6>
                            <p class="p-2 rounded "><?php echo e(\Carbon\Carbon::parse($promo->tglMulai)->format('d M Y')); ?></p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Tanggal Berakhir:</h6>
                            <p class="p-2 rounded "><?php echo e(\Carbon\Carbon::parse($promo->tglBerakhir)->format('d M Y')); ?></p>
                        </div>

                        <div class="d-flex justify-content-between align-items-center pt-3 mt-4">
                            <a href="<?php echo e(url('promo/index')); ?>" class="btn btn-secondary">
                                <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                            </a>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .btn + .btn {
            margin-left: 0.75rem;
        }

        .p-2.bg-light {
            border: 1px solid #e0e0e0;
        }
    </style>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\Downloads\PMB\resources\views/admin/promo/show.blade.php ENDPATH**/ ?>