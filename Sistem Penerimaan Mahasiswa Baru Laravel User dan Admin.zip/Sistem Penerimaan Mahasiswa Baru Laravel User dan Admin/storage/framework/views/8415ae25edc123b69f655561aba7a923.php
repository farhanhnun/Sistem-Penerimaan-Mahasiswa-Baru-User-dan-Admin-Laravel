<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no"
    />
    <title>Form Informasi - Skydash Admin</title>
    <!-- plugins:css -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.2/css/bootstrap.min.css"
    />
    <!-- Custom CSS to match Skydash theme -->
    <style>
      body {
        font-family: "Poppins", sans-serif;
        background-color: #f4f5f7;
      }
      .navbar {
        background: linear-gradient(90deg, #4b73e1 0%, #9baaf3 100%);
        padding: 0.75rem 0;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      }
      .navbar-brand {
        color: white !important;
        font-size: 1.5rem;
        font-weight: 600;
      }
      .card {
        border: none;
        border-radius: 15px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08),
          0 2px 8px rgba(0, 0, 0, 0.04);
        background: linear-gradient(135deg, #ffffff 0%, #f8f9fb 100%);
        overflow: hidden;
        position: relative;
      }
      .card::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 4px;
        background: linear-gradient(
          90deg,
          #4b73e1 0%,
          #667eea 50%,
          #764ba2 100%
        );
      }
      .card-body {
        padding: 2.5rem;
      }
      .card-title {
        color: #2d3748;
        font-weight: 700;
        font-size: 1.5rem;
        margin-bottom: 0.5rem;
        background: linear-gradient(135deg, #4b73e1 0%, #667eea 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
      }
      .card-description {
        color: #718096;
        font-size: 0.95rem;
        margin-bottom: 2rem;
        font-weight: 400;
      }
      .form-control {
        border: 1px solid #e3e6f0;
        border-radius: 8px;
        padding: 0.75rem 1rem;
        font-size: 0.875rem;
        transition: all 0.3s ease;
        background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
      }
      .form-control:focus {
        border-color: #4b73e1;
        box-shadow: 0 0 0 0.2rem rgba(75, 115, 225, 0.25),
          0 2px 8px rgba(75, 115, 225, 0.15);
        background: #ffffff;
        transform: translateY(-1px);
      }
      .form-group label {
        color: #495057;
        font-weight: 600;
        margin-bottom: 0.5rem;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        opacity: 0.9;
      }
      .form-control[type="textarea"] {
        min-height: 120px;
        resize: vertical;
      }
      .btn-primary {
        background: linear-gradient(135deg, #4b73e1 0%, #667eea 100%);
        border: none;
        border-radius: 8px;
        padding: 0.75rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
        box-shadow: 0 3px 6px rgba(75, 115, 225, 0.3);
      }
      .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(75, 115, 225, 0.5);
        background: linear-gradient(135deg, #3d63d4 0%, #4b73e1 100%);
      }
      .btn-light {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        border: 1px solid #dee2e6;
        color: #6c757d;
        border-radius: 8px;
        padding: 0.75rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      }
      .btn-light:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
        background: linear-gradient(135deg, #e9ecef 0%, #dee2e6 100%);
        color: #495057;
      }
      .btn-secondary {
        background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
        border: none;
        color: white;
        border-radius: 8px;
        padding: 0.75rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(108, 117, 125, 0.2);
      }
      .btn-secondary:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(108, 117, 125, 0.4);
        color: white;
      }
      .btn-danger {
        background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
        border: none;
        color: white;
        border-radius: 8px;
        padding: 0.75rem 1.5rem;
        font-weight: 500;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(220, 53, 69, 0.2);
      }
      .btn-danger:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(220, 53, 69, 0.4);
        color: white;
      }
      .container-fluid {
        padding: 2rem;
      }
      .grid-margin {
        margin-bottom: 2rem;
      }

      /* Modal Styles */
      .modal-content {
        border: none;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
      }
      .modal-header {
        background: linear-gradient(90deg, #28a745 0%, #20c997 100%);
        color: white;
        border-radius: 10px 10px 0 0;
        border-bottom: none;
      }
      .modal-header.delete {
        background: linear-gradient(90deg, #dc3545 0%, #c82333 100%);
      }
      .modal-title {
        font-weight: 600;
      }
      .btn-close {
        color: white;
        opacity: 0.8;
      }
      .btn-close:hover {
        opacity: 1;
      }
      .modal-body {
        padding: 2rem;
        text-align: center;
      }
      .success-icon {
        font-size: 4rem;
        color: #28a745;
        margin-bottom: 1rem;
      }
      .alert-success {
        background: linear-gradient(90deg, #d4edda 0%, #c3e6cb 100%);
        border: 1px solid #c3e6cb;
        color: #155724;
        border-radius: 8px;
      }

      /* Responsive Improvements */
      @media (max-width: 768px) {
        .container-fluid {
          padding: 1rem;
        }

        .card-body {
          padding: 1.5rem;
        }

        .card-title {
          font-size: 1.25rem;
        }

        .card-description {
          font-size: 0.875rem;
          margin-bottom: 1.5rem;
        }

        .form-control {
          padding: 0.875rem 1rem;
          font-size: 1rem;
        }

        .form-group label {
          font-size: 0.875rem;
        }

        .btn {
          padding: 0.875rem 1.25rem;
          font-size: 0.875rem;
          width: 100%;
          margin-bottom: 0.5rem;
        }

        .d-flex.justify-content-between {
          flex-direction: column-reverse;
        }

        .d-flex.align-items-center {
          flex-direction: column;
          width: 100%;
        }

        .btn-kembali {
          margin-top: 1rem;
        }

        .modal-body {
          padding: 1.5rem;
        }

        .success-icon {
          font-size: 3rem;
        }
      }

      @media (max-width: 576px) {
        .container-fluid {
          padding: 0.75rem;
        }

        .card {
          border-radius: 10px;
          margin: 0;
        }

        .card-body {
          padding: 1rem;
        }

        .card-title {
          font-size: 1.125rem;
          text-align: center;
        }

        .card-description {
          text-align: center;
          margin-bottom: 1.25rem;
        }

        .form-control {
          padding: 1rem;
          font-size: 1rem;
        }

        .form-group {
          margin-bottom: 1.25rem;
        }

        .btn {
          padding: 1rem;
          font-size: 1rem;
        }

        .modal-dialog {
          margin: 1rem;
        }

        .modal-body {
          padding: 1rem;
        }

        .success-icon {
          font-size: 2.5rem;
        }
      }

      /* Touch friendly improvements */
      @media (hover: none) and (pointer: coarse) {
        .btn {
          min-height: 48px;
        }

        .form-control {
          min-height: 48px;
        }
      }

      /* Landscape phone adjustments */
      @media (max-width: 896px) and (orientation: landscape) {
        .container-fluid {
          padding: 1rem 2rem;
        }

        .card-body {
          padding: 1.5rem 2rem;
        }
      }
    </style>
  </head>

  <body>
    <div class="container-fluid">
      <div class="row justify-content-center">
        <div class="col-12 col-lg-8 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title">Form Informasi</h4>
              <p class="card-description">
                Formulir untuk menambah atau mengedit data informasi
              </p>
              <form class="forms-sample" id="informasiForm">
                <div class="form-group">
                  <label for="jenisInformasi">Jenis Informasi</label>
                  <select class="form-control" id="jenisInformasi" required>
                    <option value="">Pilih Jenis Informasi</option>
                    <option value="Pengumuman">Pengumuman</option>
                    <option value="Berita">Berita</option>
                    <option value="Event">Event</option>
                    <option value="Pemberitahuan">Pemberitahuan</option>
                    <option value="Agenda">Agenda</option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="isiInformasi">Isi Informasi</label>
                  <textarea
                    class="form-control"
                    id="isiInformasi"
                    rows="6"
                    placeholder="Masukkan isi informasi secara detail..."
                    required
                  ></textarea>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                  <a
                    href="../../pages/informasi/informasi.html"
                    class="btn btn-secondary btn-kembali"
                  >
                    <i class="fas fa-arrow-left mr-2"></i>Kembali
                  </a>
                  <div class="d-flex align-items-center">
                    <button type="submit" class="btn btn-primary mr-2">
                      <i class="fas fa-save mr-2"></i>Simpan
                    </button>
                    <button type="reset" class="btn btn-light">
                      <i class="fas fa-undo mr-2"></i>Reset
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Edit Modal -->
    <div
      class="modal fade"
      id="editModal"
      tabindex="-1"
      aria-labelledby="editModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="editModalLabel">
              <i class="fas fa-edit mr-2"></i>Edit Informasi
            </h5>
            <button
              type="button"
              class="btn-close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form id="editForm">
              <input type="hidden" id="editId" />
              <div class="form-group">
                <label for="editJenisInformasi">Jenis Informasi</label>
                <select class="form-control" id="editJenisInformasi" required>
                  <option value="">Pilih Jenis Informasi</option>
                  <option value="Pengumuman">Pengumuman</option>
                  <option value="Berita">Berita</option>
                  <option value="Event">Event</option>
                  <option value="Pemberitahuan">Pemberitahuan</option>
                  <option value="Agenda">Agenda</option>
                </select>
              </div>
              <div class="form-group">
                <label for="editIsiInformasi">Isi Informasi</label>
                <textarea
                  class="form-control"
                  id="editIsiInformasi"
                  rows="6"
                  required
                ></textarea>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-dismiss="modal"
            >
              <i class="fas fa-times mr-2"></i>Batal
            </button>
            <button type="button" class="btn btn-primary" onclick="saveEdit()">
              <i class="fas fa-save mr-2"></i>Simpan Perubahan
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div
      class="modal fade"
      id="deleteModal"
      tabindex="-1"
      aria-labelledby="deleteModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header delete">
            <h5 class="modal-title" id="deleteModalLabel">
              <i class="fas fa-exclamation-triangle mr-2"></i>Konfirmasi Hapus
            </h5>
            <button
              type="button"
              class="btn-close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="text-center">
              <div class="mb-3">
                <i
                  class="fas fa-exclamation-triangle text-danger"
                  style="font-size: 3rem"
                ></i>
              </div>
              <h5>Apakah Anda yakin?</h5>
              <p class="mb-0">
                Data informasi "<span id="deleteInformasiJenis"></span>" akan
                dihapus secara permanen dan tidak dapat dikembalikan.
              </p>
            </div>
            <input type="hidden" id="deleteId" />
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-dismiss="modal"
            >
              <i class="fas fa-times mr-2"></i>Batal
            </button>
            <button
              type="button"
              class="btn btn-danger"
              onclick="confirmDelete()"
            >
              <i class="fas fa-trash mr-2"></i>Ya, Hapus
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Success Modal -->
    <div
      class="modal fade"
      id="successModal"
      tabindex="-1"
      aria-labelledby="successModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header success">
            <h5 class="modal-title" id="successModalLabel">
              <i class="fas fa-check-circle mr-2"></i>Berhasil!
            </h5>
            <button
              type="button"
              class="btn-close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="text-center">
              <div class="mb-3">
                <i
                  class="fas fa-check-circle text-success"
                  style="font-size: 3rem"
                ></i>
              </div>
              <h5 id="successMessage">Operasi berhasil dilakukan!</h5>
              <p class="mb-0" id="successDetail"></p>
              <div
                class="alert alert-success mt-3"
                id="savedDataInfo"
                style="display: none"
              >
                <!-- Data yang disimpan akan ditampilkan di sini -->
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" data-dismiss="modal">
              <i class="fas fa-check mr-2"></i>OK
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.2/js/bootstrap.bundle.min.js"></script>

    <script>
      // Function to edit informasi
      function editInformasi(id, jenis, isi) {
        $("#editId").val(id);
        $("#editJenisInformasi").val(jenis);
        $("#editIsiInformasi").val(isi);
        $("#editModal").modal("show");
      }

      // Function to delete informasi
      function deleteInformasi(id, jenis) {
        $("#deleteId").val(id);
        $("#deleteInformasiJenis").text(jenis);
        $("#deleteModal").modal("show");
      }

      // Function to save edit
      function saveEdit() {
        const id = $("#editId").val();
        const jenis = $("#editJenisInformasi").val();
        const isi = $("#editIsiInformasi").val();

        // Validate form
        if (!jenis || !isi.trim()) {
          alert("Mohon lengkapi semua field!");
          return;
        }

        // Simulate saving process
        const saveButton = $("#editModal .btn-primary");
        const originalText = saveButton.html();

        saveButton
          .html('<i class="fas fa-spinner fa-spin mr-2"></i>Menyimpan...')
          .prop("disabled", true);

        setTimeout(() => {
          // Reset button
          saveButton.html(originalText).prop("disabled", false);

          // Close edit modal
          $("#editModal").modal("hide");

          // Update table row (simulate)
          updateTableRow(id, jenis, isi);

          // Show success modal
          showSuccessModal(
            "Data Berhasil Diubah!",
            `Data informasi "${jenis}" telah berhasil diperbarui.`
          );
        }, 1500);
      }

      // Function to confirm delete
      function confirmDelete() {
        const id = $("#deleteId").val();
        const jenis = $("#deleteInformasiJenis").text();

        // Simulate delete process
        const deleteButton = $("#deleteModal .btn-danger");
        const originalText = deleteButton.html();

        deleteButton
          .html('<i class="fas fa-spinner fa-spin mr-2"></i>Menghapus...')
          .prop("disabled", true);

        setTimeout(() => {
          // Reset button
          deleteButton.html(originalText).prop("disabled", false);

          // Close delete modal
          $("#deleteModal").modal("hide");

          // Remove table row (simulate)
          $(`#informasiTableBody tr:nth-child(${id})`).fadeOut(
            300,
            function () {
              $(this).remove();
              updateRowNumbers();
            }
          );

          // Show success modal
          showSuccessModal(
            "Data Berhasil Dihapus!",
            `Data informasi "${jenis}" telah berhasil dihapus dari sistem.`
          );
        }, 1500);
      }

      // Function to update table row
      function updateTableRow(id, jenis, isi) {
        const row = $(`#informasiTableBody tr:nth-child(${id})`);
        row.find("td:nth-child(2)").text(jenis);

        // Truncate isi for display
        const truncatedIsi =
          isi.length > 50 ? isi.substring(0, 50) + "..." : isi;
        row.find("td:nth-child(3)").text(truncatedIsi);

        // Update onclick functions
        row
          .find(".btn-warning")
          .attr(
            "onclick",
            `editInformasi(${id}, '${jenis}', '${isi.replace(/'/g, "\\'")}' )`
          );
        row
          .find(".btn-danger")
          .attr("onclick", `deleteInformasi(${id}, '${jenis}')`);

        // Add highlight effect
        row.addClass("table-success");
        setTimeout(() => {
          row.removeClass("table-success");
        }, 2000);
      }

      // Function to update row numbers after deletion
      function updateRowNumbers() {
        $("#informasiTableBody tr").each(function (index) {
          $(this)
            .find("td:first-child")
            .text(index + 1);
        });
      }

      // Function to show success modal
      function showSuccessModal(title, message) {
        $("#successMessage").text(title);
        $("#successDetail").text(message);
        $("#successModal").modal("show");
      }

      // Form submission handler
      $("#informasiForm").on("submit", function (e) {
        e.preventDefault();

        const jenis = $("#jenisInformasi").val();
        const isi = $("#isiInformasi").val();

        // Validate form
        if (!jenis || !isi.trim()) {
          alert("Mohon lengkapi semua field!");
          return;
        }

        // Simulate saving process
        const submitButton = $(this).find('button[type="submit"]');
        const originalText = submitButton.html();

        submitButton
          .html('<i class="fas fa-spinner fa-spin mr-2"></i>Menyimpan...')
          .prop("disabled", true);

        setTimeout(() => {
          // Reset button
          submitButton.html(originalText).prop("disabled", false);

          // Show success modal
          const truncatedIsi =
            isi.length > 100 ? isi.substring(0, 100) + "..." : isi;
          const dataInfo = `
            <strong>Jenis:</strong> ${jenis}<br>
            <strong>Isi:</strong> ${truncatedIsi}
          `;

          $("#savedDataInfo").html(dataInfo).show();
          showSuccessModal(
            "Data Berhasil Disimpan!",
            "Data informasi telah berhasil ditambahkan ke dalam sistem."
          );

          // Reset form
          this.reset();
          $(".form-control").removeClass("is-valid is-invalid");
        }, 1500);
      });

      // Document ready
      $(document).ready(function () {
        // Add hover effects to buttons
        $(".btn").hover(
          function () {
            $(this).addClass("shadow");
          },
          function () {
            $(this).removeClass("shadow");
          }
        );

        // Add form validation styling
        $(".form-control").on("input change", function () {
          if ($(this).val()) {
            $(this).removeClass("is-invalid").addClass("is-valid");
          } else {
            $(this).removeClass("is-valid");
          }
        });

        // Reset form validation when modal is closed
        $("#editModal").on("hidden.bs.modal", function () {
          $("#editForm")[0].reset();
          $(".form-control").removeClass("is-valid is-invalid");
        });

        // Auto-resize textarea
        $("textarea").on("input", function () {
          this.style.height = "auto";
          this.style.height = this.scrollHeight + "px";
        });
      });
    </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\PMB\resources\views/admin/form/form_informasi.blade.php ENDPATH**/ ?>