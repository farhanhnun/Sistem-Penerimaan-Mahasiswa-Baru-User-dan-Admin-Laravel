<?php $__env->startSection('title', 'Detail Prodi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 mx-auto grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Detail Prodi</h4>
                                <p class="card-description">Informasi lengkap data program studi</p>
                            </div>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Nama Prodi:</h6>
                            <p class=" p-2 rounded "><?php echo e($prodi->namaProdi); ?></p>
                        </div>

                        <div class="mb-3">
                            <h6 class="font-weight-bold mb-1">Jumlah SKS:</h6>
                            <p class=" p-2 rounded "><?php echo e($prodi->jmlSKS); ?></p>
                        </div>

                        <div class="d-flex justify-content-between align-items-center pt-3 mt-4">
                            <a href="<?php echo e(url('prodi/index')); ?>" class="btn btn-secondary">
                                <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                            </a>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .btn+.btn {
            margin-left: 0.75rem;
        }

        .form-control:focus,
        textarea.form-control:focus {
            border-color: #0d6efd;
        }

        .form-control.is-valid {
            border-color: #0d6efd;
        }

        .form-control.is-invalid {
            border-color: #dc3545;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\Downloads\PMBnazwa\PMB\resources\views/admin/prodi/show.blade.php ENDPATH**/ ?>