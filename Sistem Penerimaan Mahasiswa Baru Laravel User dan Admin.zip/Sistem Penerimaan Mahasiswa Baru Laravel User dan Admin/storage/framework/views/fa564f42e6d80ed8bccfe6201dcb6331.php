<?php $__env->startSection('title', 'Data Kabupaten'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert" id="successAlert">
            <span id="successMessage"><?php echo e(session('success')); ?></span>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

        
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Data Kabupaten</h4>
                                <p class="card-description">Kelola data Kabupaten</p>
                            </div>
                            <a href="<?php echo e(url('admin/form_kabupaten')); ?>" class="btn btn-primary btn-icon-text">
                                <i class="fa-solid fa-plus"></i>
                                Tambah Kabupaten
                            </a>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <form method="GET" action="<?php echo e(url('admin/kabupaten')); ?>">
                                    <div class="form-group">
                                        <div class="input-group search-box">
                                            <input type="text" class="form-control"
                                                placeholder="Cari kabupaten atau provinsi..." name="search"
                                                value="<?php echo e(request('search')); ?>" id="searchInput" />
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="submit">
                                                    <i class="fa-solid fa-magnifying-glass"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Kabupaten</th>
                                        <th>Provinsi</th>
                                        <th width="200px">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="kabupatenTableBody">
                                    <?php $__empty_1 = true; $__currentLoopData = $kabupatens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kabupaten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr id="row-<?php echo e($kabupaten->id); ?>">
                                            <td><?php echo e($kabupatens->firstItem() + $index); ?></td>
                                            <td><?php echo e($kabupaten->namaKabupaten); ?></td>
                                            <td><?php echo e($kabupaten->provinsi->namaProvinsi ?? 'N/A'); ?></td>
                                            <td>
                                                <div class="table-actions">
                                                    <button class="btn btn-inverse-warning btn-sm"
                                                        onclick="editKabupaten(<?php echo e($kabupaten->id); ?>)" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-danger btn-sm"
                                                        onclick="deleteKabupaten(<?php echo e($kabupaten->id); ?>)" title="Hapus">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>
                                                    <button class="btn btn-inverse-success btn-sm"
                                                        onclick="showDetailKabupaten(<?php echo e($kabupaten->id); ?>)"
                                                        title="Show">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">
                                                <?php if(request('search')): ?>
                                                    Tidak ada data kabupaten yang sesuai dengan pencarian
                                                    "<?php echo e(request('search')); ?>"
                                                <?php else: ?>
                                                    Belum ada data kabupaten
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        
                        <?php if($kabupatens->hasPages()): ?>
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div>
                                    <p class="text-muted">
                                        Menampilkan <?php echo e($kabupatens->firstItem()); ?> sampai
                                        <?php echo e($kabupatens->lastItem()); ?> dari <?php echo e($kabupatens->total()); ?> data
                                    </p>
                                </div>
                                <nav>
                                    <?php echo e($kabupatens->links('pagination::bootstrap-4')); ?>

                                </nav>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Function to delete kabupaten dengan AJAX
    function deleteKabupaten(id) {
        if (confirm("Apakah Anda yakin ingin menghapus data kabupaten ini?")) {
            // Tambahkan CSRF token untuk Laravel
            const csrfToken = document.querySelector('meta[name="csrf-token"]');
            const token = csrfToken ? csrfToken.getAttribute('content') : '';

            fetch(`kabupaten/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': token,
                        'Accept': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Hapus baris dari tabel
                        const row = document.getElementById(`row-${id}`);
                        if (row) {
                            row.remove();
                        }
                        showSuccessAlert(data.message);
                    } else {
                        alert('Gagal menghapus data: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Terjadi kesalahan saat menghapus data');
                });
        }
    }

    // Function to show success alert
    function showSuccessAlert(message) {
        // Buat alert element jika tidak ada
        let alert = document.getElementById("successAlert");
        if (!alert) {
            alert = document.createElement('div');
            alert.id = 'successAlert';
            alert.className = 'alert alert-success alert-dismissible fade show';
            alert.setAttribute('role', 'alert');
            alert.innerHTML = `
            <span id="successMessage">${message}</span>
            <button type="button" class="close" onclick="closeAlert()" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        `;

            // Insert di awal content-wrapper
            const contentWrapper = document.querySelector('.content-wrapper');
            if (contentWrapper) {
                contentWrapper.insertBefore(alert, contentWrapper.firstChild);
            }
        } else {
            document.getElementById("successMessage").textContent = message;
            alert.style.display = "block";
        }

        // Auto hide after 5 seconds
        setTimeout(() => {
            closeAlert();
        }, 5000);
    }

    // Function to close alert
    function closeAlert() {
        const alert = document.getElementById("successAlert");
        if (alert) {
            alert.style.display = "none";
        }
    }

    // Function to edit kabupaten
    function editKabupaten(id) {
        window.location.href = `/admin/form/kabupaten?edit=${id}`;
    }

    // Function to show detail kabupaten
    function showDetailKabupaten(id) {
        alert("Melihat detail kabupaten dengan ID: " + id);
        // Implementasi detail view logic di sini
    }
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PMB\resources\views/admin/kabupaten.blade.php ENDPATH**/ ?>