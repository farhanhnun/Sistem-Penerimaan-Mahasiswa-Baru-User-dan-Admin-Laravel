<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sistem PMB - Politeknik LP3I Bandung</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
      overflow-x: hidden;
    }

    /* Hero Section Styles */
    .hero-section {
      min-height: 100vh;
      position: relative;
      display: flex;
      align-items: center;
      padding: 2rem 0;
    }

    .hero-content {
      position: relative;
      z-index: 3;
    }

    .hero-badge {
      background: linear-gradient(to right, #019BA4, #004168);
      color: white;
      padding: 0.5rem 1.5rem;
      border-radius: 50px;
      font-size: 0.9rem;
      font-weight: 600;
      display: inline-block;
      margin-bottom: 1.5rem;
      box-shadow: 0 4px 15px rgba(0, 166, 192, 0.3);
    }

    .hero-title {
      font-size: clamp(2rem, 5vw, 3.5rem);
      font-weight: 800;
      color: #28377C;
      line-height: 1.2;
      margin-bottom: 1rem;
      background: linear-gradient(45deg, #28377C, #003a63);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .hero-subtitle {
      font-size: clamp(1.1rem, 3vw, 1.5rem);
      font-weight: 600;
      color: #00a6c0;
      margin-bottom: 2rem;
      line-height: 1.4;
    }

    .hero-description {
      font-size: 1.1rem;
      color: #6c757d;
      margin-bottom: 1.5rem;
      line-height: 1.6;
      max-width: 500px;
    }

    .hero-info {
      background: rgba(255, 255, 255, 0.8);
      backdrop-filter: blur(10px);
      padding: 1rem 1.5rem;
      border-radius: 15px;
      border-left: 4px solid #00a6c0;
      margin-bottom: 2.5rem;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    .hero-info p {
      margin: 0;
      color: #28377C;
      font-weight: 600;
      font-size: 1rem;
    }

    .btn-group-custom {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
    }

    .btn-primary-custom {
      background: linear-gradient(45deg, #003a63, #28377C);
      color: white;
      border: none;
      padding: 0.875rem 2rem;
      font-size: 1rem;
      font-weight: 600;
      border-radius: 50px;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(0, 58, 99, 0.3);
      cursor: pointer;
    }

    .btn-primary-custom:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(0, 58, 99, 0.4);
      color: white;
    }

    .btn-secondary-custom {
      background: transparent;
      color: #28377C;
      border: 2px solid #28377C;
      padding: 0.875rem 2rem;
      font-size: 1rem;
      font-weight: 600;
      border-radius: 50px;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      transition: all 0.3s ease;
      cursor: pointer;
    }

    .btn-secondary-custom:hover {
      background: #28377C;
      color: white;
      transform: translateY(-2px);
    }

    .btn-info-custom {
      background: linear-gradient(45deg, #00a6c0, #019BA4);
      color: white;
      border: none;
      padding: 0.875rem 2rem;
      font-size: 1rem;
      font-weight: 600;
      border-radius: 50px;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(0, 166, 192, 0.3);
      cursor: pointer;
    }

    .btn-info-custom:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(0, 166, 192, 0.4);
      color: white;
    }

    .hero-visual {
      position: relative;
      height: 500px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .circle-bg {
      position: absolute;
      width: 400px;
      height: 400px;
      background: linear-gradient(135deg, #00a6c0, #003a63);
      border-radius: 50%;
      opacity: 0.1;
      animation: float 6s ease-in-out infinite;
    }

    .circle-bg:nth-child(2) {
      width: 300px;
      height: 300px;
      background: linear-gradient(45deg, #28377C, #00a6c0);
      animation-delay: -2s;
      top: 50px;
      right: 50px;
    }

    .circle-bg:nth-child(3) {
      width: 200px;
      height: 200px;
      background: linear-gradient(225deg, #003a63, #28377C);
      animation-delay: -4s;
      bottom: 100px;
      left: 100px;
    }

    .hero-icon {
      position: relative;
      z-index: 2;
      font-size: 8rem;
      color: #28377C;
      opacity: 0.8;
      animation: pulse 4s ease-in-out infinite;
    }

    /* Alur PMB Section Styles */
    .alur-section {
      background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
      padding: 5rem 0;
      position: relative;
      min-height: 100vh;
    }

    .alur-section::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-image:
        radial-gradient(circle at 20% 30%, rgba(0, 166, 192, 0.05) 0%, transparent 50%),
        radial-gradient(circle at 80% 70%, rgba(40, 55, 124, 0.05) 0%, transparent 50%);
      pointer-events: none;
    }

    .wrapper-gray {
      background: rgba(243, 244, 249, 0.8);
      backdrop-filter: blur(10px);
      padding: 3rem 2rem;
      border-radius: 20px;
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
      border: 1px solid rgba(255, 255, 255, 0.2);
      position: relative;
      z-index: 2;
    }

    .tahap-section {
      margin-bottom: 2rem;
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    .tahap-header {
      background: linear-gradient(135deg, #004168 0%, #0066a3 100%);
      color: white;
      padding: 15px 25px;
      border-radius: 25px;
      font-weight: 600;
      text-align: center;
      margin-bottom: 1rem;
      box-shadow: 0 6px 15px rgba(0, 65, 104, 0.3);
      position: relative;
      overflow: hidden;
    }

    .tahap-header::before {
      content: '';
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      transition: left 0.5s;
    }

    .tahap-header:hover::before {
      left: 100%;
    }

    .tahap-content {
      background: rgba(255, 255, 255, 0.95);
      backdrop-filter: blur(10px);
      padding: 25px;
      border-radius: 15px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
      border-left: 4px solid #004168;
      border: 1px solid rgba(255, 255, 255, 0.3);
      flex-grow: 1;
      transition: all 0.3s ease;
    }

    .tahap-content:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    }

    .alur-title {
      text-align: center;
      color: #004168;
      font-weight: 800;
      margin-bottom: 3rem;
      font-size: 2.5rem;
      position: relative;
      background: linear-gradient(45deg, #004168, #28377C);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .alur-title::after {
      content: '';
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
      width: 100px;
      height: 3px;
      background: linear-gradient(to right, #004168, #00a6c0);
      border-radius: 2px;
    }

    .content-text {
      color: #4b5563;
      line-height: 1.8;
      margin: 0;
      font-size: 1rem;
    }

    .link-text {
      color: #004168;
      text-decoration: none;
      font-weight: 600;
    }

    .link-text:hover {
      text-decoration: underline;
      color: #00a6c0;
    }

    /* Animations */
    @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-20px); }
    }

    @keyframes pulse {
      0%, 100% { opacity: 0.8; }
      50% { opacity: 0.4; }
    }

    /* Decorative elements */
    .decoration-dots {
      position: absolute;
      top: 20%;
      right: 10%;
      width: 100px;
      height: 100px;
      background-image: radial-gradient(circle, #00a6c0 2px, transparent 2px);
      background-size: 20px 20px;
      opacity: 0.3;
      animation: float 8s ease-in-out infinite;
    }

    .decoration-lines {
      position: absolute;
      bottom: 20%;
      left: 5%;
      width: 80px;
      height: 80px;
      background: linear-gradient(45deg, transparent 40%, #28377C 40%, #28377C 60%, transparent 60%);
      opacity: 0.2;
      animation: float 6s ease-in-out infinite reverse;
    }

    .alur-decoration-dots {
      position: absolute;
      top: 10%;
      left: 5%;
      width: 80px;
      height: 80px;
      background-image: radial-gradient(circle, #004168 2px, transparent 2px);
      background-size: 15px 15px;
      opacity: 0.2;
      animation: float 10s ease-in-out infinite;
    }

    .alur-decoration-lines {
      position: absolute;
      bottom: 10%;
      right: 8%;
      width: 60px;
      height: 60px;
      background: linear-gradient(45deg, transparent 30%, #00a6c0 30%, #00a6c0 70%, transparent 70%);
      opacity: 0.15;
      animation: float 7s ease-in-out infinite reverse;
    }

    /* Responsive Design */
    @media (max-width: 992px) {
      .hero-visual {
        height: 300px;
        margin-top: 2rem;
      }

      .hero-icon {
        font-size: 5rem;
      }

      .circle-bg {
        width: 250px;
        height: 250px;
      }

      .circle-bg:nth-child(2) {
        width: 180px;
        height: 180px;
      }

      .circle-bg:nth-child(3) {
        width: 120px;
        height: 120px;
      }

      .alur-title {
        font-size: 2rem;
      }
    }

    @media (max-width: 768px) {
      .hero-section {
        text-align: center;
        padding: 1rem 0;
      }

      .hero-visual {
        height: 250px;
        order: -1;
        margin-bottom: 2rem;
      }

      .hero-icon {
        font-size: 4rem;
      }

      .btn-group-custom {
        justify-content: center;
      }

      .alur-section {
        padding: 3rem 0;
      }

      .wrapper-gray {
        padding: 2rem 1rem;
      }

      .alur-title {
        font-size: 1.8rem;
        margin-bottom: 2rem;
      }

      .tahap-section {
        margin-bottom: 1.5rem;
      }

      .tahap-content {
        padding: 20px;
      }
    }

    @media (max-width: 576px) {
      .hero-badge {
        font-size: 0.8rem;
        padding: 0.4rem 1rem;
      }

      .hero-description {
        font-size: 1rem;
      }

      .btn-primary-custom,
      .btn-secondary-custom,
      .btn-info-custom {
        padding: 0.75rem 1.5rem;
        font-size: 0.9rem;
        width: 100%;
        justify-content: center;
      }

      .btn-group-custom {
        flex-direction: column;
      }

      .hero-visual {
        height: 200px;
      }

      .hero-icon {
        font-size: 3rem;
      }

      .wrapper-gray {
        padding: 1.5rem 1rem;
        border-radius: 15px;
      }

      .tahap-header {
        padding: 12px 20px;
        font-size: 0.9rem;
      }

      .tahap-content {
        padding: 18px;
      }

      .alur-title {
        font-size: 1.5rem;
      }
    }

    /* Smooth scroll */
    html {
      scroll-behavior: smooth;
    }
  </style>
</head>
<body>

  <!-- Hero Section -->
  <div class="hero-section" id="hero">
    <div class="container">
      <div class="row align-items-center min-vh-100">
        <div class="col-lg-6">
          <div class="hero-content">
            <div class="hero-badge">
              <i class="fas fa-graduation-cap me-2"></i>
              Pendaftaran Mahasiswa Baru Angkatan 2025
            </div>

            <h1 class="hero-title">
              Sistem Penerimaan Mahasiswa Baru
            </h1>

            <h2 class="hero-subtitle">
              Politeknik LP3I Bandung
            </h2>

            <div class="btn-group-custom">
                    <a href="<?php echo e(route('form.akun')); ?>" class="btn-primary-custom">
                        <i class="fas fa-user-plus"></i>
                        Buat Akun PMB
                    </a>

                    <a href="<?php echo e(route('login')); ?>" class="btn-primary-custom">
                        <i class="fas fa-sign-in-alt"></i>
                        Login Akun PMB
                    </a>

              <a href="#alur" class="btn-info-custom">
                <i class="fas fa-info-circle"></i>
                Informasi Alur Penerimaan Mahasiswa Baru
              </a>
            </div>
          </div>
        </div>

        <div class="col-lg-6">
          <div class="hero-visual">
            <div class="circle-bg"></div>
            <div class="circle-bg"></div>
            <div class="circle-bg"></div>
            <i class="fas fa-university hero-icon"></i>
          </div>
        </div>
      </div>
    </div>

    <!-- Decorative Elements -->
    <div class="decoration-dots"></div>
    <div class="decoration-lines"></div>
  </div>

  <!-- Alur PMB Section -->
  <div class="alur-section" id="alur">
    <div class="container">
      <div class="wrapper-gray">
        <h1 class="alur-title">Alur Pendaftaran Mahasiswa Baru</h1>
        <div class="row">
          <!-- Tahap 1 -->
          <div class="col-lg-6 col-md-12 mb-4">
            <div class="tahap-section">
              <div class="tahap-header">
                <i class="fas fa-user-plus me-2"></i>
                Tahap 1 - Membuat Akun PMB
              </div>
              <div class="tahap-content">
                <p class="content-text">
                  Daftar dan buat akun PMB melalui website resmi Politeknik LP3I Bandung. Isi data dasar untuk membuat akun dengan username dan password yang akan digunakan untuk mengakses sistem PMB.
                </p>
              </div>
            </div>
          </div>

          <!-- Tahap 2 -->
          <div class="col-lg-6 col-md-12 mb-4">
            <div class="tahap-section">
              <div class="tahap-header">
                <i class="fas fa-credit-card me-2"></i>
                Tahap 2 - Mengisi Form Pembayaran
              </div>
              <div class="tahap-content">
                <p class="content-text">
                  Lengkapi form pembayaran dan lakukan pembayaran biaya pendaftaran. Pilih metode pembayaran yang tersedia seperti virtual account, transfer bank, atau e-wallet sesuai preferensi Anda.
                </p>
              </div>
            </div>
          </div>

          <!-- Tahap 3 -->
          <div class="col-lg-6 col-md-12 mb-4">
            <div class="tahap-section">
              <div class="tahap-header">
                <i class="fas fa-user me-2"></i>
                Tahap 3 - Mengisi Data Diri
              </div>
              <div class="tahap-content">
                <p class="content-text">
                  Isi formulir data diri secara lengkap dan akurat meliputi informasi personal, alamat tempat tinggal, kontak yang dapat dihubungi, dan dokumen identitas seperti KTP atau Kartu Pelajar.
                </p>
              </div>
            </div>
          </div>

          <!-- Tahap 4 -->
          <div class="col-lg-6 col-md-12 mb-4">
            <div class="tahap-section">
              <div class="tahap-header">
                <i class="fas fa-users me-2"></i>
                Tahap 4 - Mengisi Data Orang Tua
              </div>
              <div class="tahap-content">
                <p class="content-text">
                  Lengkapi informasi data orang tua atau wali termasuk nama lengkap, pekerjaan, alamat, nomor telepon, dan informasi lain yang diperlukan untuk kepentingan administrasi dan komunikasi.
                </p>
              </div>
            </div>
          </div>

          <!-- Tahap 5 -->
          <div class="col-lg-6 col-md-12 mb-4">
            <div class="tahap-section">
              <div class="tahap-header">
                <i class="fas fa-graduation-cap me-2"></i>
                Tahap 5 - Mengisi Data Riwayat Akhir Sekolah
              </div>
              <div class="tahap-content">
                <p class="content-text">
                  Input data pendidikan terakhir meliputi nama sekolah, jurusan, tahun lulus, nilai rata-rata, dan upload dokumen pendukung seperti ijazah, transkrip nilai, dan sertifikat prestasi jika ada.
                </p>
              </div>
            </div>
          </div>

          <!-- Tahap 6 -->
          <div class="col-lg-6 col-md-12 mb-4">
            <div class="tahap-section">
              <div class="tahap-header">
                <i class="fas fa-id-card me-2"></i>
                Tahap 6 - Menerima Nomor Induk Mahasiswa
              </div>
              <div class="tahap-content">
                <p class="content-text">
                  Setelah semua data terverifikasi dan pembayaran dikonfirmasi, Anda akan menerima Nomor Induk Mahasiswa (NIM) melalui email dan dapat dilihat di dashboard akun PMB Anda.
                </p>
              </div>
            </div>
          </div>

          <!-- Tahap 7 -->
          <div class="col-lg-6 col-md-6 mb-4">
            <div class="tahap-section">
              <div class="tahap-header">
                <i class="fas fa-laptop me-2"></i>
                Tahap 7 - Memasuki Website SIAKAD
              </div>
              <div class="tahap-content">
                <p class="content-text">
                  Gunakan Nomor Induk Mahasiswa (NIM) yang telah diterima untuk login ke website SIAKAD (Sistem Informasi Akademik) dan mulai mengakses layanan akademik seperti registrasi mata kuliah, jadwal perkuliahan, dan informasi akademik lainnya.
                </p>
              </div>
            </div>
          </div>

          <div class="col-lg-6 col-md-6 mb-4">
            <div class="tahap-section">
              <div class="tahap-header">
                <i class="fas fa-star me-2"></i>
                Tahap 8 - Selamat Anda Mahasiswa Angkatan 2025
              </div>
              <div class="tahap-content">
                <p class="content-text">
                  Selamat! Anda telah resmi menjadi mahasiswa Politeknik LP3I Bandung Angkatan 2025. Bersiaplah untuk memulai perjalanan akademik yang menantang dan penuh dengan kesempatan untuk mengembangkan diri dan meraih prestasi.
                </p>
              </div>
            </div>
          </div>
        </div>

        <!-- Back to Top Button -->
        <div class="text-center mt-4">
          <button class="btn-secondary-custom" onclick="scrollToHero()">
            <i class="fas fa-arrow-up"></i>
            Kembali ke Atas
          </button>
        </div>
      </div>
    </div>

    <!-- Alur Decorative Elements -->
    <div class="alur-decoration-dots"></div>
    <div class="alur-decoration-lines"></div>
  </div>
  <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    function scrollToHero() {
      document.getElementById('hero').scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }

    // Add smooth scrolling for all anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
          target.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      });
    });
  </script>

</body>
</html>
<?php /**PATH C:\Users\Lenovo\Downloads\PMBnazwa\PMB\resources\views/maba/index.blade.php ENDPATH**/ ?>