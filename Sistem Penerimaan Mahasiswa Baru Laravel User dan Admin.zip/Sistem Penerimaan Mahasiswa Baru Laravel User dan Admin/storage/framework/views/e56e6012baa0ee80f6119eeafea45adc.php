<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Form Data Orang Tua</title>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
      rel="stylesheet"
    />
    <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      body {
        background: linear-gradient(to right, #019ba4, #004168) top,
          #ffffff bottom;
        background-repeat: no-repeat;
        background-size: 100% 33.33%, 100% 66.67%;
        background-position: top, bottom;
        min-height: 100vh;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
          sans-serif;
      }

      .container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 40px 20px;
      }

      .form-container {
        background-color: #ffffff;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        margin-top: 60px;
      }

      .form-title {
        text-align: center;
        font-weight: bold;
        margin-bottom: 40px;
        font-size: 28px;
        color: #004168;
      }

      .section-title {
        font-size: 18px;
        font-weight: 600;
        color: #019ba4;
        margin-bottom: 20px;
        padding-bottom: 8px;
        border-bottom: 2px solid #e9ecef;
      }

      .form-label {
        font-weight: 600;
        color: #333;
        margin-bottom: 8px;
        font-size: 14px;
      }

      .form-control,
      .form-select {
        border: 2px solid #e9ecef;
        border-radius: 10px;
        padding: 12px 16px;
        font-size: 14px;
        transition: all 0.3s ease;
        height: 48px;
      }

      .form-control:focus,
      .form-select:focus {
        border-color: #019ba4;
        box-shadow: 0 0 0 0.2rem rgba(1, 155, 164, 0.15);
        outline: none;
      }

      .form-section {
            background-color: #f8f9fa;   /* abu-abu muda */
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05); /* opsional */
        }

      textarea.form-control {
        height: 100px;
        resize: vertical;
      }

      .btn-next {
        background: linear-gradient(135deg, #004168 0%, #019ba4 100%);
        color: white;
        border: none;
        padding: 15px 40px;
        border-radius: 12px;
        font-weight: 700;
        font-size: 16px;
        float: right;
        margin-top: 30px;
        transition: all 0.3s ease;
      }

      .btn-next:hover {
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
      }

      .row-custom {
        display: flex;
        gap: 15px;
      }

      .col-custom {
        flex: 1;
      }

      .col-custom-small {
        flex: 0 0 100px;
      }

      .loading {
        opacity: 0.6;
        pointer-events: none;
      }

      .form-select:disabled {
        background-color: #f8f9fa;
        opacity: 0.6;
      }

      /* Success Popup Styles */
      .success-popup-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        opacity: 0;
        animation: fadeIn 0.3s ease forwards;
      }

      @keyframes fadeIn {
        to {
          opacity: 1;
        }
      }

      .success-popup {
        background: white;
        padding: 40px 30px;
        border-radius: 20px;
        text-align: center;
        max-width: 400px;
        width: 90%;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        transform: scale(0.7);
        animation: popIn 0.3s ease 0.1s forwards;
      }

      @keyframes popIn {
        to {
          transform: scale(1);
        }
      }

      .success-popup-icon {
        margin-bottom: 20px;
      }

      .checkmark-circle {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #28a745, #20c997);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
        position: relative;
        animation: pulse 0.6s ease-in-out;
      }

      @keyframes pulse {
        0% {
          transform: scale(0);
        }
        50% {
          transform: scale(1.1);
        }
        100% {
          transform: scale(1);
        }
      }

      .checkmark-circle i {
        color: white;
        font-size: 32px;
        animation: checkmarkAppear 0.3s ease 0.3s both;
      }

      @keyframes checkmarkAppear {
        from {
          opacity: 0;
          transform: scale(0);
        }
        to {
          opacity: 1;
          transform: scale(1);
        }
      }

      .success-popup h3 {
        color: #004168;
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 15px;
        animation: slideUp 0.3s ease 0.4s both;
      }

      .success-popup p {
        color: #666;
        font-size: 16px;
        margin-bottom: 30px;
        line-height: 1.5;
        animation: slideUp 0.3s ease 0.5s both;
      }

      @keyframes slideUp {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .btn-lanjutkan {
        background: linear-gradient(135deg, #004168 0%, #019ba4 100%);
        color: white;
        border: none;
        padding: 12px 30px;
        border-radius: 25px;
        font-weight: 600;
        font-size: 16px;
        cursor: pointer;
        transition: all 0.3s ease;
        animation: slideUp 0.3s ease 0.6s both;
        min-width: 120px;
      }

      .btn-lanjutkan:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
      }

      @media (max-width: 992px) {
        .form-container {
          padding: 30px 25px;
        }

        .form-title {
          font-size: 26px;
        }

        .row-custom {
          gap: 10px;
        }
      }

      @media (max-width: 768px) {
        .container {
          padding: 20px 15px;
        }

        .form-container {
          padding: 25px 20px;
          margin-top: 30px;
          border-radius: 12px;
        }

        .form-title {
          font-size: 24px;
          margin-bottom: 30px;
        }

        .section-title {
          font-size: 16px;
          margin-bottom: 15px;
        }

        .row-custom {
          flex-direction: column;
          gap: 0;
        }

        .col-custom-small {
          flex: 1;
        }

        .btn-next {
          width: 100%;
          float: none;
          margin-top: 20px;
          padding: 12px 30px;
        }

        .form-control,
        .form-select {
          height: 50px;
          font-size: 16px;
        }

        textarea.form-control {
          height: 80px;
        }

        .success-popup {
          padding: 30px 25px;
          max-width: 350px;
        }

        .success-popup h3 {
          font-size: 22px;
        }

        .success-popup p {
          font-size: 15px;
        }
      }

      @media (max-width: 576px) {
        body {
          background-size: 100% 25%, 100% 75%;
        }

        .container {
          padding: 15px 10px;
        }

        .form-container {
          padding: 20px 15px;
          margin-top: 20px;
          border-radius: 10px;
        }

        .form-title {
          font-size: 22px;
          margin-bottom: 25px;
        }

        .section-title {
          font-size: 15px;
          margin-bottom: 12px;
        }

        .form-label {
          font-size: 13px;
          margin-bottom: 6px;
        }

        .form-control,
        .form-select {
          height: 48px;
          padding: 10px 12px;
          font-size: 16px;
        }

        textarea.form-control {
          height: 70px;
          padding: 10px 12px;
        }

        .btn-next {
          padding: 14px 20px;
          font-size: 15px;
          margin-top: 15px;
        }

        .row-custom {
          gap: 0;
        }

        .mb-3 {
          margin-bottom: 1rem !important;
        }

        .mb-4 {
          margin-bottom: 1.25rem !important;
        }

        .success-popup {
          padding: 25px 20px;
          max-width: 320px;
        }

        .checkmark-circle {
          width: 70px;
          height: 70px;
        }

        .checkmark-circle i {
          font-size: 28px;
        }

        .success-popup h3 {
          font-size: 20px;
        }

        .success-popup p {
          font-size: 14px;
        }

        .btn-lanjutkan {
          padding: 10px 25px;
          font-size: 15px;
        }
      }

      @media (max-width: 400px) {
        .form-title {
          font-size: 20px;
          margin-bottom: 20px;
        }

        .section-title {
          font-size: 14px;
        }

        .form-container {
          padding: 15px 12px;
        }

        .btn-next {
          padding: 12px 15px;
          font-size: 14px;
        }
      }

      .alert {
        border: none;
        border-radius: 10px;
        padding: 15px 20px;
      }

      .alert-success {
        background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
        color: #155724;
      }

      .alert-warning {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
        color: #856404;
      }

      .alert-danger {
        background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
        color: #721c24;
      }

      .is-invalid {
        border-color: #dc3545 !important;
        box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.15) !important;
      }

      .invalid-feedback {
        display: block;
        width: 100%;
        margin-top: 0.25rem;
        font-size: 0.875em;
        color: #dc3545;
      }


    </style>
  </head>
  <body>
    <div class="container">
      <!-- Alert container for warnings -->
      <div id="alertContainer" style="display: none;">
        <div class="alert alert-danger" role="alert">
          <strong><i class="fas fa-exclamation-triangle me-2"></i>Peringatan!</strong>
          <span id="alertMessage">Mohon lengkapi semua field yang wajib diisi sebelum melanjutkan ke halaman berikutnya.</span>
        </div>
      </div>

      <div class="form-container">
        <h2 class="form-title">Data Orang Tua</h2>

        <form id="parentForm">
          <div class="row g-4">
            <!-- Left Column - Data Ayah/Wali -->
            <div class="col-lg- col-md-12">
              <h4 class="section-title">
                <i class="fas fa-male me-2"></i>Data Ayah/Wali
              </h4>

              <div class="form-section">
              <div class="mb-3">
                <label class="form-label">Nama Ayah/Wali</label>
                <input
                  type="text"
                  class="form-control"
                  name="namaAyah"
                  placeholder="Masukkan nama lengkap ayah/wali"
                  required
                />
              </div>

              <div class="mb-3">
                <label class="form-label">Nama Ibu/Wali</label>
                <input
                  type="text"
                  class="form-control"
                  name="namaIbu"
                  placeholder="Masukkan nama lengkap ibu/wali"
                  required
                />
              </div>

              <div class="mb-3">
                <label class="form-label">No WhatsApp</label>
                <input
                  type="tel"
                  class="form-control"
                  name="noTelp"
                  placeholder="Contoh: 08123456789"
                  required
                />
              </div>

              <div class="mb-3">
                <label class="form-label">Email</label>
                <input
                  type="email"
                  class="form-control"
                  name="email"
                  placeholder="contoh@email.com"
                  required
                />
              </div>

              <div class="mb-3">
                <label class="form-label">Agama</label>
                <select class="form-select" name="agama" required>
                  <option value="" selected disabled>Pilih agama</option>
                  <option value="islam">Islam</option>
                  <option value="kristen">Kristen</option>
                  <option value="katolik">Katolik</option>
                  <option value="hindu">Hindu</option>
                  <option value="buddha">Buddha</option>
                  <option value="konghucu">Konghucu</option>
                </select>
              </div>

              <div class="mb-3">
                <label class="form-label">Pekerjaan</label>
                <select class="form-select" name="pekerjaan" required>
                  <option value="" selected disabled>Pilih pekerjaan</option>
                  <option value="pns">PNS</option>
                  <option value="swasta">Karyawan Swasta</option>
                  <option value="wiraswasta">Wiraswasta</option>
                  <option value="petani">Petani</option>
                  <option value="pedagang">Pedagang</option>
                  <option value="buruh">Buruh</option>
                  <option value="pensiunan">Pensiunan</option>
                  <option value="ibu_rumah_tangga">Ibu Rumah Tangga</option>
                  <option value="lainnya">Lainnya</option>
                </select>
              </div>

              <div class="mb-4">
                <label class="form-label">Pendidikan Terakhir</label>
                <select class="form-select" name="pendidikan" required>
                  <option value="" selected disabled>
                    Pilih pendidikan terakhir
                  </option>
                  <option value="sd">SD/Sederajat</option>
                  <option value="smp">SMP/Sederajat</option>
                  <option value="sma">SMA/SMK/Sederajat</option>
                </select>
              </div>
              </div>
            </div>

            <!-- Right Column - Alamat & Info Tambahan -->
            <div class="col-lg- col-md-12">
              <h4 class="section-title">
                <i class="fas fa-map-marker-alt me-2"></i>Alamat & Informasi
                Tambahan
              </h4>

              <div class="form-section">
              <div class="mb-3">
                <label class="form-label">Provinsi</label>
                <select
                  class="form-select"
                  name="provinsi"
                  id="provinsi"
                  required
                >
                  <option value="" selected disabled>Pilih provinsi</option>
                </select>
              </div>

              <div class="mb-3">
                <label class="form-label">Kabupaten/Kota</label>
                <select
                  class="form-select"
                  name="kabupaten"
                  id="kabupaten"
                  required
                  disabled
                >
                  <option value="" selected disabled>
                    Pilih kabupaten/kota
                  </option>
                </select>
              </div>

              <div class="mb-3">
                <label class="form-label">Kecamatan</label>
                <select
                  class="form-select"
                  name="kecamatan"
                  id="kecamatan"
                  required
                  disabled
                >
                  <option value="" selected disabled>Pilih kecamatan</option>
                </select>
              </div>

              <div class="mb-3">
                <label class="form-label">Desa/Kelurahan</label>
                <select
                  class="form-select"
                  name="desa"
                  id="desa"
                  required
                  disabled
                >
                  <option value="" selected disabled>Pilih desa/kelurahan</option>
                </select>
              </div>

              <div class="mb-3">
                <label class="form-label">Alamat</label>
                <textarea
                  class="form-control"
                  name="alamat"
                  placeholder="Masukkan alamat lengkap"
                  required
                ></textarea>
              </div>

              <div class="row-custom mb-3">
                <div class="col-3">
                  <label class="form-label">RT</label>
                  <input
                    type="text"
                    class="form-control"
                    name="rt"
                    placeholder="RT"
                    maxlength="3"
                    required
                  />
                </div>

                <div class="col-3">
                  <label class="form-label">RW</label>
                  <input
                    type="text"
                    class="form-control"
                    name="rw"
                    placeholder="RW"
                    maxlength="3"
                    required
                  />
                </div>
                <div class="col-5">
                  <label class="form-label">Kode Pos</label>
                  <input
                    type="text"
                    class="form-control"
                    name="kodepos"
                    placeholder="Kode pos"
                    maxlength="5"
                    required
                  />
                </div>
              </div>

              <div class="mb-4">
                <label class="form-label">Penghasilan Per Bulan</label>
                <select class="form-select" name="penghasilan" required>
                  <option value="" selected disabled>
                    Pilih rentang penghasilan
                  </option>
                  <option value="1jt">Kurang dari Rp 1.000.000</option>
                  <option value="1-3jt">Rp 1.000.000 - Rp 3.000.000</option>
                  <option value="3-5jt">Rp 3.000.000 - Rp 5.000.000</option>
                  <option value="5-10jt">Rp 5.000.000 - Rp 10.000.000</option>
                  <option value=">10jt">Lebih dari Rp 10.000.000</option>
                </select>
              </div>

              <button type="button" id="nextButton" class="btn btn-next">
                <i class="fas fa-save me-2"></i>
                Simpan Data Orang Tua
              </button>
            </div>
            </div>
          </div>
        </form>
      </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
      // Get DOM elements with correct IDs
      const provinsiSelect = document.getElementById('provinsi');
      const kabupatenSelect = document.getElementById('kabupaten');
      const kecamatanSelect = document.getElementById('kecamatan');
      const desaSelect = document.getElementById('desa');

      // Helper function to show loading state
      function showLoading(element) {
        element.classList.add('loading');
        element.innerHTML = '<option value="">Loading...</option>';
      }

      // Helper function to reset and disable select
      function resetSelect(element, placeholder) {
        element.innerHTML = `<option value="" selected disabled>${placeholder}</option>`;
        element.disabled = true;
        element.classList.remove('loading');
      }

      // Helper function to enable select and remove loading
      function enableSelect(element) {
        element.disabled = false;
        element.classList.remove('loading');
      }

      // Load provinces on page load
      document.addEventListener('DOMContentLoaded', function() {
        loadProvinces();
      });

      // Function to load provinces
      async function loadProvinces() {
        try {
          showLoading(provinsiSelect);
          const response = await fetch('https://www.emsifa.com/api-wilayah-indonesia/api/provinces.json');
          const provinces = await response.json();

          provinsiSelect.innerHTML = '<option value="" selected disabled>Pilih provinsi</option>';

          provinces.forEach(province => {
            const option = document.createElement('option');
            option.value = province.id;
            option.textContent = province.name;
            provinsiSelect.appendChild(option);
          });

          enableSelect(provinsiSelect);
        } catch (error) {
          console.error('Error loading provinces:', error);
          provinsiSelect.innerHTML = '<option value="">Error loading provinces</option>';
        }
      }

      // Event listener for province selection
      provinsiSelect.addEventListener('change', async function() {
        const provinsiId = this.value;

        // Reset dependent selects
        resetSelect(kabupatenSelect, 'Pilih kabupaten/kota');
        resetSelect(kecamatanSelect, 'Pilih kecamatan');
        resetSelect(desaSelect, 'Pilih desa/kelurahan');

        if (provinsiId) {
          try {
            showLoading(kabupatenSelect);
            const response = await fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/regencies/${provinsiId}.json`);
            const regencies = await response.json();

            kabupatenSelect.innerHTML = '<option value="" selected disabled>Pilih kabupaten/kota</option>';

            regencies.forEach(regency => {
              const option = document.createElement('option');
              option.value = regency.id;
              option.textContent = regency.name;
              kabupatenSelect.appendChild(option);
            });

            enableSelect(kabupatenSelect);
          } catch (error) {
            console.error('Error loading regencies:', error);
            kabupatenSelect.innerHTML = '<option value="">Error loading kabupaten/kota</option>';
          }
        }
      });

      // Event listener for regency selection
      kabupatenSelect.addEventListener('change', async function() {
        const kabupatenId = this.value;

        // Reset dependent selects
        resetSelect(kecamatanSelect, 'Pilih kecamatan');
        resetSelect(desaSelect, 'Pilih desa/kelurahan');

        if (kabupatenId) {
          try {
            showLoading(kecamatanSelect);
            const response = await fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/districts/${kabupatenId}.json`);
            const districts = await response.json();

            kecamatanSelect.innerHTML = '<option value="" selected disabled>Pilih kecamatan</option>';

            districts.forEach(district => {
              const option = document.createElement('option');
              option.value = district.id;
              option.textContent = district.name;
              kecamatanSelect.appendChild(option);
            });

            enableSelect(kecamatanSelect);
          } catch (error) {
            console.error('Error loading districts:', error);
            kecamatanSelect.innerHTML = '<option value="">Error loading kecamatan</option>';
          }
        }
      });

      // Event listener for district selection
      kecamatanSelect.addEventListener('change', async function() {
        const kecamatanId = this.value;

        // Reset dependent select
        resetSelect(desaSelect, 'Pilih desa/kelurahan');

        if (kecamatanId) {
          try {
            showLoading(desaSelect);
            const response = await fetch(`https://www.emsifa.com/api-wilayah-indonesia/api/villages/${kecamatanId}.json`);
            const villages = await response.json();

            desaSelect.innerHTML = '<option value="" selected disabled>Pilih desa/kelurahan</option>';

            villages.forEach(village => {
              const option = document.createElement('option');
              option.value = village.id;
              option.textContent = village.name;
              desaSelect.appendChild(option);
            });

            enableSelect(desaSelect);
          } catch (error) {
            console.error('Error loading villages:', error);
            desaSelect.innerHTML = '<option value="">Error loading desa/kelurahan</option>';
          }
        }
      });

      // Success Popup Functions
      function showSuccessPopup() {
        const popup = document.createElement('div');
        popup.className = 'success-popup-overlay';
        popup.innerHTML = `
            <div class="success-popup">
                <div class="success-popup-icon">
                    <div class="checkmark-circle">
                        <i class="fas fa-check"></i>
                    </div>
                </div>
                <h3>Data Berhasil Disimpan!</h3>
                <p>Data orang tua telah berhasil disimpan. Silakan lanjutkan ke halaman berikutnya.</p>
                <button class="btn-lanjutkan" onclick="closeSuccessPopup()">
                    Lanjutkan
                </button>
            </div>
        `;

        document.body.appendChild(popup);
      }

      function closeSuccessPopup() {
        const popup = document.querySelector('.success-popup-overlay');
        if (popup) {
          popup.remove();
        }

        // Redirect ke halaman dashboard atau halaman berikutnya
        window.location.href = '../dashboard.html';
        // Untuk demo, kita tampilkan alert
        // alert('Redirect ke halaman dashboard atau halaman berikutnya');
      }

      // Form validation and next button functionality
      document.getElementById('nextButton').addEventListener('click', function() {
        validateAndProceed();
      });

      // Also validate on form submit
      document.getElementById('parentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        validateAndProceed();
      });

      // Function to validate form and show warnings
      function validateAndProceed() {
        const form = document.getElementById('parentForm');
        const requiredFields = form.querySelectorAll('[required]');
        let isValid = true;
        let emptyFields = [];

        // Hide previous alerts
        hideAlert();

        // Remove previous invalid classes
        document.querySelectorAll('.is-invalid').forEach(field => {
          field.classList.remove('is-invalid');
          const feedback = field.parentNode.querySelector('.invalid-feedback');
          if (feedback) {
            feedback.remove();
          }
        });

        requiredFields.forEach(field => {
          const fieldName = getFieldDisplayName(field);

          if (!field.value.trim()) {
            isValid = false;
            emptyFields.push(fieldName);
            field.classList.add('is-invalid');

            // Add invalid feedback message
            const feedback = document.createElement('div');
            feedback.className = 'invalid-feedback';
            feedback.textContent = `${fieldName} wajib diisi`;
            field.parentNode.appendChild(feedback);
          }
        });

        if (!isValid) {
          // // Show warning alert
          // showAlert(`Mohon lengkapi field berikut: ${emptyFields.join(', ')}`);

          // Scroll to first invalid field
          const firstInvalidField = document.querySelector('.is-invalid');
          if (firstInvalidField) {
            firstInvalidField.scrollIntoView({
              behavior: 'smooth',
              block: 'center'
            });
            firstInvalidField.focus();
          }
        } else {
          // All fields are valid, show success popup
          showSuccessPopup();
        }
      }

      // Function to get display name for fields
      function getFieldDisplayName(field) {
        const labels = {
          'namaAyah': 'Nama Ayah/Wali',
          'namaIbu': 'Nama Ibu/Wali',
          'noTelp': 'No Telp',
          'email': 'Email',
          'agama': 'Agama',
          'pekerjaan': 'Pekerjaan',
          'pendidikan': 'Pendidikan Terakhir',
          'provinsi': 'Provinsi',
          'kabupaten': 'Kabupaten/Kota',
          'kecamatan': 'Kecamatan',
          'desa': 'Desa/Kelurahan',
          'alamat': 'Alamat',
          'rt': 'RT',
          'rw': 'RW',
          'kodepos': 'Kode Pos',
          'penghasilan': 'Penghasilan Per Bulan'
        };

        return labels[field.name] || field.name;
      }

      // Function to show alert
      function showAlert(message) {
        const alertContainer = document.getElementById('alertContainer');
        const alertMessage = document.getElementById('alertMessage');

        alertMessage.textContent = message;
        alertContainer.style.display = 'block';
        alertContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }

      // Function to hide alert
      function hideAlert() {
        const alertContainer = document.getElementById('alertContainer');
        alertContainer.style.display = 'none';
      }

      // Auto-hide alert when user starts typing in invalid fields
      document.addEventListener('input', function(e) {
        if (e.target.classList.contains('is-invalid')) {
          e.target.classList.remove('is-invalid');
          const feedback = e.target.parentNode.querySelector('.invalid-feedback');
          if (feedback) {
            feedback.remove();
          }

          // Check if there are still invalid fields
          const stillInvalidFields = document.querySelectorAll('.is-invalid');
          if (stillInvalidFields.length === 0) {
            hideAlert();
          }
        }
      });

      // Auto-hide alert when user changes select options
      document.addEventListener('change', function(e) {
        if (e.target.classList.contains('is-invalid')) {
          e.target.classList.remove('is-invalid');
          const feedback = e.target.parentNode.querySelector('.invalid-feedback');
          if (feedback) {
            feedback.remove();
          }

          // Check if there are still invalid fields
          const stillInvalidFields = document.querySelectorAll('.is-invalid');
          if (stillInvalidFields.length === 0) {
            hideAlert();
          }
        }
      });

      // Phone number validation
      document.querySelector('input[name="noTelp"]').addEventListener('input', function() {
        let value = this.value.replace(/\D/g, ''); // Remove non-numeric characters
        if (value.length > 12) {
          value = value.substring(0, 12);
        }
        this.value = value;
      });

      // Postal code validation
      document.querySelector('input[name="kodepos"]').addEventListener('input', function() {
        let value = this.value.replace(/\D/g, ''); // Remove non-numeric characters
        if (value.length > 5) {
          value = value.substring(0, 5);
        }
        this.value = value;
      });

      // RT/RW validation
      document.querySelector('input[name="rt"]').addEventListener('input', function() {
        let value = this.value.replace(/\D/g, '');
        if (value.length > 3) {
          value = value.substring(0, 3);
        }
        this.value = value;
      });

      document.querySelector('input[name="rw"]').addEventListener('input', function() {
        let value = this.value.replace(/\D/g, '');
        if (value.length > 3) {
          value = value.substring(0, 3);
        }
        this.value = value;
      });
     </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\PMB\resources\views/maba/form/data_orangtua.blade.php ENDPATH**/ ?>