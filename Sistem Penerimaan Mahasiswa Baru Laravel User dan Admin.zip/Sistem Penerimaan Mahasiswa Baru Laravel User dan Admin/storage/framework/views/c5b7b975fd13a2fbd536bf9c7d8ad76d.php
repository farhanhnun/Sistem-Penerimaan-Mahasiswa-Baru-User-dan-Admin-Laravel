<?php $__env->startSection('title', 'Dashboard'); ?>


<?php $__env->startSection('content'); ?>
    
          <div class="content-wrapper">
            <div class="row">
              <div class="col-md-12 grid-margin">
                <div class="row">
                  <div class="col-12 col-xl-8 mb-3 mb-xl-0">
                    <h3 class="font-weight-bold">Selamat Datang Admin</h3>
                    <h6 class="font-weight-normal mb-0">
                    Selamat datang di dashboard pendaftaran
                    </h6>
                  </div>
                      <div class="col-12 col-xl-4">
                        <div class="justify-content-end d-flex">
                          <div class="dropdown flex-md-grow-1 flex-xl-grow-0">
                            <button
                              class="btn btn-sm btn-light bg-white dropdown-toggle"
                              type="button"
                              id="dropdownMenuDate2"
                              data-toggle="dropdown"
                              aria-haspopup="true"
                              aria-expanded="true"
                            >
                              <i class="fa-solid fa-calendar m-1"></i> Today (10 Jan 2021)
                            </button>
                            <div
                              class="dropdown-menu dropdown-menu-right"
                              aria-labelledby="dropdownMenuDate2"
                            >
                              <a class="dropdown-item" href="#">January - March</a>
                              <a class="dropdown-item" href="#">March - June</a>
                              <a class="dropdown-item" href="#">June - August</a>
                              <a class="dropdown-item" href="#"
                                >August - November</a
                              >
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Bagian Kartu: Registrasi & Daftar -->
                    <div class="row">
                      <div class="col-md-6 mb-4 stretch-card transparent">
                        <a href="form-registrasi.html" class="text-decoration-none text-dark w-100">
                          <div class="card card-tale h-100">
                            <div class="card-body">
                              <p class="mb-4">Registrasi</p>
                              <p class="fs-30 mb-2">4006</p>
                              <p>10.00% (30 days)</p>
                            </div>
                          </div>
                        </a>
                      </div>
                      <div class="col-md-6 mb-4 stretch-card transparent">
                        <a href="form-daftar.html" class="text-decoration-none text-dark w-100">
                          <div class="card card-dark-blue h-100">
                            <div class="card-body">
                              <p class="mb-4">Daftar</p>
                              <p class="fs-30 mb-2">61344</p>
                              <p>22.00% (30 days)</p>
                            </div>
                          </div>
                        </a>
                      </div>
                    </div>

    <!-- Tabel Data Calon Mahasiswa -->
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Data Calon Mahasiswa</h4>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead class="thead">
                        <tr>
                            <th>No</th>
                            <th>No Pendaftaran</th>
                            <th>Nama Lengkap</th>
                            <th>Email</th>
                            <th>No. Telepon</th>
                            <th>Prodi</th>
                            <th>Kelas</th>
                            <th>Alamat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($mahasiswas->firstItem() + $index); ?></td>
                                <td><?php echo e($mhs->noPendaftaran); ?></td>
                                <td><?php echo e($mhs->namaLengkap); ?></td>
                                <td><?php echo e($mhs->email); ?></td>
                                <td><?php echo e($mhs->telepon); ?></td>
                                <td><?php echo e($mhs->prodi->namaProdi ?? '-'); ?></td>
                                <td><?php echo e($mhs->kelas->namaKelas ?? '-'); ?></td>
                                <td><?php echo e($mhs->alamat->alamatLengkap ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center">Belum ada data calon mahasiswa</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($mahasiswas->hasPages()): ?>
                <div class="mt-3 d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted">
                            Menampilkan <?php echo e($mahasiswas->firstItem()); ?> - <?php echo e($mahasiswas->lastItem()); ?> dari <?php echo e($mahasiswas->total()); ?> data
                        </small>
                    </div>
                    <div>
                        <?php echo e($mahasiswas->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PMB1\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>