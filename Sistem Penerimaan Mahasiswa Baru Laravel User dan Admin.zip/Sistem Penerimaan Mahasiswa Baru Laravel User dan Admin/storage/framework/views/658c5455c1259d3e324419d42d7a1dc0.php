<?php $__env->startSection('title', 'Data Pendaftar'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Data Pendaftar</h4>
                                <p class="card-description">Kelola data pendaftar</p>
                            </div>
                            <a href="<?php echo e(url('verifdaftar/create')); ?>" class="btn btn-primary btn-icon-text">
                                <i class="fa-solid fa-plus"></i>
                                Tambah Pendaftar
                            </a>
                        </div>

                        
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <form method="GET" action="<?php echo e(url('verifdaftar/index')); ?>">
                                    <div class="form-group">
                                        <div class="input-group search-box">
                                            <input type="text" class="form-control" placeholder="Cari nama/email..."
                                                name="search" value="<?php echo e(request('search')); ?>" />
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="submit">
                                                    <i class="fa-solid fa-magnifying-glass"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Lengkap</th>
                                        <th>Email</th>
                                        <th>No WA</th>
                                        <th>Promo</th>
                                        <th>Jumlah Bayar</th>
                                        <th>Foto Bukti</th>
                                        <th>Status Bayar</th>
                                        <th width="220px">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $pendaftarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr id="row-<?php echo e($data->id); ?>">
                                            <td><?php echo e($pendaftarans->firstItem() + $index); ?></td>
                                            <td><?php echo e($data->calonMahasiswa->namaLengkap); ?></td>
                                            <td><?php echo e($data->calonMahasiswa->email); ?></td>
                                            <td><?php echo e($data->calonMahasiswa->telepon); ?></td>
                                            <td><?php echo e($data->promo->namaPromo ?? '-'); ?></td>
                                            <td><?php echo e($data->totalBayar); ?></td>
                                            <td>
                                                <?php if($data->buktiBayar): ?>
                                                    <img src="<?php echo e(asset('storage/' . $data->buktiBayar)); ?>" width="60" height="60"
                                                        style="object-fit: cover; border-radius: 5px;">
                                                <?php else: ?>
                                                    <span class="badge badge-secondary">Belum Upload</span>
                                                <?php endif; ?>
                                            </td>
                                           <td>
                                                

                                                <?php if($data->statusBayar === 'lunas'): ?>
                                                    <span class="badge badge-success">Lunas</span>
                                                <?php elseif($data->statusBayar === 'pending'): ?>
                                                    <span class="badge badge-warning">Pending</span>
                                                <?php elseif($data->statusBayar === 'gagal'): ?>
                                                    <span class="badge badge-danger">Gagal</span>
                                                <?php endif; ?>
                                            </td>


                                            <td class="text-nowrap">
                                                <div class="d-flex align-items-center">
                                                    
                                                    <a href="<?php echo e(url('verifdaftar/edit/' . $data->calonMahasiswa->id)); ?>"
                                                        class="btn btn-inverse-warning btn-sm m-1" title="Edit">
                                                        <i class="fa-solid fa-pen-to-square"></i>
                                                    </a>

                                                    <button class="btn btn-inverse-danger btn-sm m-1"
                                                        onclick="hapusPendaftaran(<?php echo e($data->id); ?>)" title="Hapus">
                                                        <i class="fa-solid fa-trash-can"></i>
                                                    </button>

                                                    <a href="<?php echo e(url('verifdaftar/show/' . $data->calonMahasiswa->id)); ?>" class="btn btn-inverse-success btn-sm" title="Lihat Detail">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </a>


                                                    <button class="btn btn-inverse-success btn-sm m-1"
                                                        onclick="verifikasi(<?php echo e($data->id); ?>)" title="Verifikasi">
                                                        <i class="fa-solid fa-check"></i>
                                                    </button>
                                                </div>
                                            </td>


                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="9" class="text-center">Belum ada data pendaftar</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>

                            </table>
                        </div>

                        
                        <?php if($pendaftarans->hasPages()): ?>
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div>
                                    <p class="text-muted">
                                        Menampilkan <?php echo e($pendaftarans->firstItem()); ?> sampai
                                        <?php echo e($pendaftarans->lastItem()); ?> dari <?php echo e($pendaftarans->total()); ?> data
                                    </p>
                                </div>
                                <nav>
                                    <?php echo e($pendaftarans->links('pagination::bootstrap-4')); ?>

                                </nav>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function hapusPendaftaran(id) {
        Swal.fire({
            title: 'Yakin ingin menghapus?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch(`/verifdaftar/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire('Berhasil', data.message, 'success');
                        document.getElementById('row-' + id).remove();
                    } else {
                        Swal.fire('Gagal', data.message, 'error');
                    }
                });
            }
        });
    }

    function verifikasi(id) {
        Swal.fire({
            title: 'Verifikasi pembayaran?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Verifikasi',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch(`/verifdaftar/verifikasi/${id}`, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire('Berhasil', data.message, 'success');
                        location.reload();
                    } else {
                        Swal.fire('Gagal', data.message, 'error');
                    }
                });
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\Downloads\PMBnazwa\PMB\resources\views/admin/verifdaftar/index.blade.php ENDPATH**/ ?>