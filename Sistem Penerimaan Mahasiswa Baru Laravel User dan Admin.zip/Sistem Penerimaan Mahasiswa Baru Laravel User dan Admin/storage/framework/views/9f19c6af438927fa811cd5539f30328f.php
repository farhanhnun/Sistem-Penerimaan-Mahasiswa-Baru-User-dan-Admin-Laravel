<?php $__env->startSection('title', 'Tambah Data Promo'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">

                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div>
                                <h4 class="card-title mb-2">Tambah Data Promo</h4>
                                <p class="card-description">Isi form data promo baru</p>
                            </div>
                        </div>

                        <form id="promoForm" action="<?php echo e(url('/promo/create')); ?>" method="POST" class="forms-sample">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="namaPromo">Nama Promo <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['namaPromo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="namaPromo" name="namaPromo" placeholder="Masukkan nama promo"
                                    value="<?php echo e(old('namaPromo')); ?>" required>
                                <?php $__errorArgs = ['namaPromo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="jnsPromo">Jenis Promo <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['jnsPromo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="jnsPromo" name="jnsPromo" placeholder="Masukkan jenis promo"
                                    value="<?php echo e(old('jnsPromo')); ?>" required>
                                <?php $__errorArgs = ['jnsPromo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="jmlPromo">Jumlah Promo <span class="text-danger">*</span></label>
                                <input type="number" class="form-control <?php $__errorArgs = ['jmlPromo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="jmlPromo" name="jmlPromo" placeholder="Contoh: 50000" value="<?php echo e(old('jmlPromo')); ?>"
                                    min="0" required>
                                <small class="form-text text-muted">Masukkan jumlah dalam bentuk nominal, contoh: 50000
                                    untuk Rp50.000.</small>
                                <?php $__errorArgs = ['jmlPromo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="form-group">
                                <label for="tglMulai">Tanggal Mulai <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tglMulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="tglMulai" name="tglMulai" value="<?php echo e(old('tglMulai')); ?>" required>
                                <?php $__errorArgs = ['tglMulai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="tglBerakhir">Tanggal Berakhir <span class="text-danger">*</span></label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tglBerakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="tglBerakhir" name="tglBerakhir" value="<?php echo e(old('tglBerakhir')); ?>" required>
                                <?php $__errorArgs = ['tglBerakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-4">
                                <a href="<?php echo e(url('promo/index')); ?>" class="btn btn-secondary">
                                    <i class="fa-solid fa-arrow-left mr-1"></i> Kembali
                                </a>
                                <div class="d-flex gap-3">
                                    <button type="reset" class="btn btn-light" id="resetBtn">
                                        <i class="fa-solid fa-undo mr-1"></i> Reset
                                    </button>
                                    <button type="submit" class="btn btn-primary" id="submitBtn">
                                        <i class="fa-solid fa-save mr-1"></i> Simpan
                                    </button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .btn+.btn {
            margin-left: 0.75rem;
        }

        .form-control:focus,
        textarea.form-control:focus {
            border-color: #0d6efd;
        }

        .form-control.is-valid {
            border-color: #0d6efd;
        }

        .form-control.is-invalid {
            border-color: #dc3545;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            <?php if(session('success')): ?>
                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    text: "<?php echo e(session('success')); ?>",
                    timer: 2500,
                    showConfirmButton: false
                });
            <?php endif; ?>

            <?php if(session('error')): ?>
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: "<?php echo e(session('error')); ?>",
                    showConfirmButton: true
                });
            <?php endif; ?>

            <?php if($errors->any()): ?>
                let errorMessages = '';
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    errorMessages += '- <?php echo e($error); ?>\n';
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                Swal.fire({
                    icon: 'error',
                    title: 'Validasi Gagal',
                    text: errorMessages,
                    customClass: {
                        popup: 'text-left'
                    }
                });
            <?php endif; ?>

            $('#promoForm').on('submit', function() {
                const submitBtn = $('#submitBtn');
                const originalHtml = submitBtn.html();

                submitBtn.prop('disabled', true).html(
                    '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Menyimpan...'
                    );

                setTimeout(() => {
                    submitBtn.prop('disabled', false).html(originalHtml);
                }, 3000);
            });

            $('.form-control[required]').on('input change', function() {
                const $input = $(this);
                if ($input.val().trim() !== '') {
                    $input.removeClass('is-invalid').addClass('is-valid');
                } else {
                    $input.removeClass('is-valid is-invalid');
                }
            });

            $('#resetBtn').on('click', function(e) {
                e.preventDefault();
                $('#promoForm')[0].reset();
                $('.form-control').removeClass('is-valid is-invalid');
                $('.invalid-feedback').hide();
                $(this).prop('disabled', true).html(
                    '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Resetting...'
                    );
                setTimeout(() => {
                    $(this).prop('disabled', false).html(
                        '<i class="fa-solid fa-undo mr-1"></i> Reset');
                    $('#namaPromo').focus();
                }, 500);
            });

            if ($('.is-invalid').length > 0) {
                $('html, body').animate({
                    scrollTop: $('.is-invalid').first().offset().top - 100
                }, 500);
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Lenovo\Downloads\PMB\resources\views/admin/promo/create.blade.php ENDPATH**/ ?>