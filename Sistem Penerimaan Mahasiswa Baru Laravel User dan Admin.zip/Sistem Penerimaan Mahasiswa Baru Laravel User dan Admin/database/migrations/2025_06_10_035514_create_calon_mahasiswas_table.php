<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
       Schema::create('calon_mahasiswas', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained('users');

    // Boleh null karena belum diisi saat daftar akun
    $table->foreignId('prodi_id')->nullable()->constrained('prodis');
    $table->foreignId('kelas_id')->nullable()->constrained('kelas');

    $table->string('noPendaftaran')->unique(); // diisi saat create akun

    $table->string('namaLengkap'); // diisi saat create akun
    $table->string('nik')->nullable();
    $table->string('tempatLahir')->nullable();
    $table->date('tglLahir')->nullable();
    $table->string('foto')->nullable();
    $table->string('ktp')->nullable();
    $table->string('kartuKeluarga')->nullable();

    $table->foreignId('alamat_id')->nullable()->constrained('alamats');

    $table->string('telepon'); // diisi saat create akun
    $table->string('email');   // diisi saat create akun

    $table->enum('jnsKelamin', ['L', 'P'])->nullable(); // wajib nullable
    $table->string('agama')->nullable();
    $table->string('golonganDarah')->nullable();
    $table->string('statusPernikahan')->nullable();

    $table->timestamps();
});

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('calon_mahasiswas');
    }
};
