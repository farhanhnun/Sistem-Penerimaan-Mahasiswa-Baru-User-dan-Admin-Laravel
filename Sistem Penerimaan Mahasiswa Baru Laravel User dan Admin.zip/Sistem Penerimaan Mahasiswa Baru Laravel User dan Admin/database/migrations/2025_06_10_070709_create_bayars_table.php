<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('bayars', function (Blueprint $table) {
            $table->id();
            $table->foreignId('calon_mahasiswa_id')->constrained('calon_mahasiswas');
            $table->foreignId('promo_id')->nullable()->constrained('promos');
            $table->foreignId('admin_id')->nullable()->constrained('admins');
            $table->decimal('totalBayar', 15, 2);
            $table->date('tglBayar');
            $table->enum('statusBayar', ['pending', 'lunas', 'gagal'])->default('pending');
            $table->string('buktiBayar')->nullable(); // file
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('bayars');
    }
};
