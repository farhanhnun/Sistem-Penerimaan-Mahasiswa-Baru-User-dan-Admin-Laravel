<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_progresses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('calon_mahasiswa_id')->constrained('calon_mahasiswas')->onDelete('cascade');
            $table->boolean('biaya_pendaftaran_completed')->default(false);
            $table->boolean('biaya_registrasi_completed')->default(false); // Opsional, tergantung apakah ada pembayaran terpisah
            $table->boolean('data_pribadi_completed')->default(false);
            $table->boolean('data_orangtua_completed')->default(false);
            $table->boolean('asal_sekolah_completed')->default(false);
            $table->timestamps();
            $table->unique('calon_mahasiswa_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_progresses');
    }
};
