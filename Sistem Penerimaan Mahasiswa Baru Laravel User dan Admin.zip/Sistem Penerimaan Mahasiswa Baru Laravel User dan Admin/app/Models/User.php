<?php
// User.php - Tambahan untuk keamanan
namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    protected $fillable = ['role', 'username', 'password'];

    // TAMBAHAN: Hidden fields untuk keamanan
    protected $hidden = ['password', 'remember_token'];

    // TAMBAHAN: Cast untuk konsistensi data
    protected $casts = [
        'password' => 'hashed', // Laravel 10+
    ];

    public function calonMahasiswa()
    {
        return $this->hasOne(CalonMahasiswa::class);
    }

    public function admin()
    {
        return $this->hasOne(Admin::class);
    }

    // TAMBAHAN: Helper method untuk cek role
    public function isAdmin()
    {
        return $this->role === 'admin';
    }

    public function isCalonMahasiswa()
    {
        return $this->role === 'calon_mahasiswa';
    }

    // TAMBAHAN: Accessor untuk mendapatkan nama berdasarkan role
    public function getNamaAttribute()
    {
        if ($this->role === 'admin' && $this->admin) {
            return $this->admin->namaAdmin;
        } elseif ($this->role === 'calon_mahasiswa' && $this->calonMahasiswa) {
            return $this->calonMahasiswa->namaLengkap;
        }
        return $this->username;
    }
}
