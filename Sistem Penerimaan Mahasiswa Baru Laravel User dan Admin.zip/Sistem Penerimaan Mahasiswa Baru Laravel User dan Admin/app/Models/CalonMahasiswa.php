<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CalonMahasiswa extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'prodi_id',
        'kelas_id',
        'noPendaftaran',
        'namaLengkap',
        'nik',
        'tempatLahir',
        'tglLahir',
        'foto',
        'ktp',
        'kartuKeluarga',
        'alamat_id',
        'telepon',
        'email',
        'jnsKelamin',
        'agama',
        'golonganDarah',
        'statusPernikahan',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function prodi()
    {
        return $this->belongsTo(Prodi::class);
    }

    public function kelas()
    {
        return $this->belongsTo(Kelas::class);
    }

    public function alamat()
    {
        return $this->belongsTo(Alamat::class);
    }

    public function orangTua()
    {
        return $this->hasOne(OrangTua::class);
    }

    public function riwayatPendidikan()
    {
        return $this->hasOne(RiwayatPendidikan::class);
    }

    public function bayar()
    {
        return $this->hasOne(Bayar::class);
    }

    public function bayarRegis()
{
    return $this->hasOne(BayarRegis::class);
}
}
