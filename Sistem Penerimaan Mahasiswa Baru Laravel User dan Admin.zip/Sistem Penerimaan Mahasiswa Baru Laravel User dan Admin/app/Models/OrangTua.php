<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class OrangTua extends Model
{
    use HasFactory;

    protected $table = 'orang_tuas';

    protected $fillable = [
        'calon_mahasiswa_id',
        'namaAyah',
        'namaIbu',
        'alamat_id',
        'telepon',
        'email',
        'agama',
        'pendidikanTerakhir',
        'pekerjaan',
        'penghasilanPerBulan',
    ];

    public function calonMahasiswa()
    {
        return $this->belongsTo(CalonMahasiswa::class);
    }

    public function alamat()
    {
        return $this->belongsTo(Alamat::class);
    }
}
