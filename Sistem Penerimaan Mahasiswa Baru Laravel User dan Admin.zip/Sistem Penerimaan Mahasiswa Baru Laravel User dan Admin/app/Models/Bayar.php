<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Bayar extends Model
{
    use HasFactory;

    protected $table = 'bayars'; // eksplisitkan nama tabel (opsional)

    protected $fillable = [
        'calon_mahasiswa_id',
        'promo_id',
        'admin_id',
        'totalBayar',
        'tglBayar',
        'statusBayar',
        'buktiBayar_blob',
        'is_include_regis',
        'nama_file_bukti_bayar',
    ];

    protected $casts = [
        'tglBayar' => 'date',
        'totalBayar' => 'decimal:2',
        'is_include_regis' => 'boolean',
    ];

    /**
     * Relasi ke Calon Mahasiswa
     */
    public function calonMahasiswa()
    {
        return $this->belongsTo(CalonMahasiswa::class);
    }

    /**
     * Relasi ke Promo (jika ada promo digunakan)
     */
    public function promo()
    {
        return $this->belongsTo(Promo::class);
    }

    /**
     * Relasi ke Admin (jika diverifikasi oleh admin)
     */
    public function admin()
    {
        return $this->belongsTo(Admin::class);
    }

    /**
     * Mengambil tipe MIME dari file bukti bayar (opsional untuk preview)
     *
     * @return string|null
     */
    public function getFileMimeType(): ?string
    {
        if (!$this->buktiBayar_blob) {
            return null;
        }

        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        return $finfo->buffer($this->buktiBayar_blob);
    }

    /**
     * Mengecek apakah pembayaran sudah termasuk registrasi
     */
    public function includesRegistrasi(): bool
    {
        return $this->is_include_regis === true;
    }
}
