<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Provinsi extends Model
{
    use HasFactory;

    protected $fillable = ['namaProvinsi'];

    public function alamats()
    {
        return $this->hasMany(Alamat::class);
    }

    public function kabupatens()
{
    return $this->hasMany(Kabupaten::class);
}
}
