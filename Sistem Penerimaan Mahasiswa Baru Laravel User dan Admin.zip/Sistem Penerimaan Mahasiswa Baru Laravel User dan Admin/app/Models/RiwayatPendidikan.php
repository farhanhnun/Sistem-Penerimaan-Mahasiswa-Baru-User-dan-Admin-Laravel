<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class RiwayatPendidikan extends Model
{
    use HasFactory;

    protected $fillable = [
        'calon_mahasiswa_id',
        'sekolah_id',
        'nisn',
        'jurusan',
        'tahunLulus',
        'ijazah'
    ];

    public function calonMahasiswa()
    {
        return $this->belongsTo(CalonMahasiswa::class);
    }

    public function asalSekolah()
    {
        return $this->belongsTo(AsalSekolah::class, 'sekolah_id');
    }
}
