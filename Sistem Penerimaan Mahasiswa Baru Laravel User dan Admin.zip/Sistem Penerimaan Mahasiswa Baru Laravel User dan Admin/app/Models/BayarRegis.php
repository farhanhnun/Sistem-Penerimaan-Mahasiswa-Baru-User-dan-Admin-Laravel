<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class BayarRegis extends Model
{
    use HasFactory;

    // Menentukan nama tabel (jika tidak mengikuti pluralisasi otomatis Laravel)
    protected $table = 'bayarregis';

    // Field yang boleh diisi secara mass assignment
    protected $fillable = [
        'calon_mahasiswa_id',
        'promo_id',
        'admin_id',
        'totalBayar',
        'tglBayar',
        'statusBayar',
        'buktiBayar_blob',
    ];

    // Tipe data otomatis untuk casting
    protected $casts = [
        'tglBayar' => 'date',
        'totalBayar' => 'decimal:2',
    ];

    /**
     * Relasi ke Calon Mahasiswa
     */
    public function calonMahasiswa()
    {
        return $this->belongsTo(CalonMahasiswa::class);
    }

    /**
     * Relasi ke Promo (jika promo digunakan saat bayar registrasi)
     */
    public function promo()
    {
        return $this->belongsTo(Promo::class);
    }

    /**
     * Relasi ke Admin (yang memverifikasi)
     */
    public function admin()
    {
        return $this->belongsTo(Admin::class);
    }

    /**
     * Ambil MIME type file dari field longblob untuk preview/download
     *
     * @return string|null
     */
    public function getFileMimeType(): ?string
    {
        if (!$this->buktiBayar_blob) {
            return null;
        }

        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        return $finfo->buffer($this->buktiBayar_blob);
    }
}
