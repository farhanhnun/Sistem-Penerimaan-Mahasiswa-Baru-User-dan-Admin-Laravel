<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserProgress extends Model
{
    use HasFactory;

    protected $table = 'user_progresses';
    protected $fillable = [
        'calon_mahasiswa_id',
        'biaya_pendaftaran_completed',
        'biaya_registrasi_completed',
        'data_pribadi_completed',
        'data_orangtua_completed',
        'asal_sekolah_completed',
    ];

    // Relasi ke CalonMahasiswa
    public function calonMahasiswa()
    {
        return $this->belongsTo(CalonMahasiswa::class);
    }
}
