<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class AsalSekolah extends Model
{
    use HasFactory;

    protected $fillable = ['namaSekolah', 'alamat'];

    public function riwayatPendidikans()
    {
        return $this->hasMany(RiwayatPendidikan::class, 'sekolah_id');
    }
}
