<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Promo;

class PromoController extends Controller
{
    public function index(Request $request)
    {
        $query = Promo::query();

        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('namaPromo', 'LIKE', "%{$search}%")
                    ->orWhere('jnsPromo', 'LIKE', "%{$search}%")
                    ->orWhere('jmlPromo', 'LIKE', "%{$search}%");
            });
        }

        $promoList = $query->orderBy('created_at', 'desc')
            ->paginate(5)
            ->appends($request->query());

        return view('admin.promo.index', compact('promoList'));
    }

    public function create()
    {
        return view('admin.promo.create');
    }

    public function store(Request $request)
    {
        // Validasi data
        $request->validate([
            'namaPromo' => 'required|string|max:255',
            'jnsPromo' => 'required|string|max:255',
            'jmlPromo' => 'required|numeric|min:0',
            'tglMulai' => 'required|date',
            'tglBerakhir' => 'required|date|after_or_equal:tglMulai',
        ]);

        try {
            // Simpan data ke database
            Promo::create([
                'namaPromo' => $request->namaPromo,
                'jnsPromo' => $request->jnsPromo,
                'jmlPromo' => $request->jmlPromo,
                'tglMulai' => $request->tglMulai,
                'tglBerakhir' => $request->tglBerakhir,
            ]);

            return redirect('/promo/index')->with('success', 'Data promo berhasil disimpan.');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Terjadi kesalahan saat menyimpan data.');
        }
    }

    public function edit($id)
    {
        $promo = Promo::findOrFail($id);
        return view('admin.promo.edit', compact('promo'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'namaPromo' => 'required|string|max:255',
            'jnsPromo' => 'required|string|max:255',
            'jmlPromo' => 'required|numeric',
        ]);

        $promo = Promo::findOrFail($id);
        $promo->namaPromo = $request->namaPromo;
        $promo->jnsPromo = $request->jnsPromo;
        $promo->jmlPromo = $request->jmlPromo;
        $promo->save();

          return redirect('/promo/index')->with('success', 'Data berhasil diperbarui.');
    }

    public function destroy($id)
    {
        try {
            $promo = Promo::findOrFail($id);
            $promo->delete();

            return response()->json([
                'success' => true,
                'message' => 'Data promo berhasil dihapus.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus data promo.'
            ], 500);
        }
    }

    public function show($id)
    {
        $promo = Promo::findOrFail($id);
        return view('admin.promo.show', compact('promo'));
    }

    public function cekKode($kode)
{
    $promo = Promo::whereRaw('LOWER(namaPromo) = ?', [strtolower($kode)])
        ->whereDate('tglMulai', '<=', now())
        ->whereDate('tglBerakhir', '>=', now())
        ->first();

    if ($promo) {
        return response()->json([
            'valid' => true,
            'namaPromo' => $promo->namaPromo,
            'diskon' => $promo->jmlPromo,
        ]);
    } else {
        return response()->json(['valid' => false]);
    }
}


}
