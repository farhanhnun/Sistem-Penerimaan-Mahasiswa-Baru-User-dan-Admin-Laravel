<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bayar;
use App\Models\CalonMahasiswa;
use App\Models\Kelas;
use App\Models\Prodi;
use Illuminate\Support\Facades\DB;

class VerifdaftarController extends Controller
{
    public function index(Request $request)
    {
        $query = Bayar::with(['calonMahasiswa', 'promo']);

        if ($search = $request->search) {
            $query->whereHas('calonMahasiswa', function ($q) use ($search) {
                $q->where('namaLengkap', 'like', "%$search%")
                  ->orWhere('email', 'like', "%$search%");
            });
        }

        $pendaftarans = $query->orderByDesc('tglBayar')->paginate(10);
        return view('admin.verifdaftar.index', compact('pendaftarans'));
    }

    public function edit($id)
    {
        $pendaftaran = CalonMahasiswa::findOrFail($id);
        $bayar = Bayar::where('calon_mahasiswa_id', $id)->firstOrFail();
        $kelas = Kelas::all();
        $prodi = Prodi::all();

        return view('admin.verifdaftar.edit', compact('pendaftaran', 'bayar', 'kelas', 'prodi'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'namaLengkap'   => 'required|string|max:255',
            'email'         => 'required|email|max:255',
            'telepon'       => 'required|string|max:20',
            'kelas_id'      => 'required|exists:kelas,id',
            'prodi_id'      => 'required|exists:prodis,id',
            'buktiBayar'    => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:5120',
            'statusBayar'   => 'required|in:pending,lunas,gagal',
        ]);

        DB::beginTransaction();
        try {
            $pendaftaran = CalonMahasiswa::findOrFail($id);
            $pendaftaran->update([
                'namaLengkap' => $request->namaLengkap,
                'email'       => $request->email,
                'telepon'     => $request->telepon,
                'kelas_id'    => $request->kelas_id,
                'prodi_id'    => $request->prodi_id,
            ]);

            $bayar = Bayar::where('calon_mahasiswa_id', $id)->firstOrFail();

            if ($request->hasFile('buktiBayar')) {
                $file = $request->file('buktiBayar');
                $bayar->buktiBayar_blob = file_get_contents($file->getRealPath());
                $bayar->nama_file_bukti_bayar = $file->getClientOriginalName();
            }

            $bayar->statusBayar = $request->statusBayar;
            $bayar->tglBayar = now();
            $bayar->save();

            DB::commit();

            return redirect()->route('verifdaftar.index')->with('success', 'Data berhasil diperbarui.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withErrors(['error' => 'Terjadi kesalahan: ' . $e->getMessage()]);
        }
    }

    public function show($id)
    {
        $pendaftaran = CalonMahasiswa::with(['kelas', 'prodi', 'bayar.promo', 'bayar.admin'])->findOrFail($id);
        return view('admin.verifdaftar.show', compact('pendaftaran'));
    }

    public function lihatBukti($id)
    {
        $bayar = Bayar::findOrFail($id);
        $mimeType = finfo_buffer(finfo_open(), $bayar->buktiBayar_blob, FILEINFO_MIME_TYPE);

        return response($bayar->buktiBayar_blob)
            ->header('Content-Type', $mimeType)
            ->header('Content-Disposition', 'inline; filename="' . ($bayar->nama_file_bukti_bayar ?? 'bukti.pdf') . '"');
    }


    public function destroy($id)
{
    try {
        $bayar = Bayar::findOrFail($id);

        // Hapus data bayar
        $bayar->delete();

        // Opsional: jika ingin hapus juga data calon mahasiswa
        // CalonMahasiswa::where('id', $bayar->calon_mahasiswa_id)->delete();

        return response()->json([
            'success' => true,
            'message' => 'Data pendaftar berhasil dihapus.'
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Gagal menghapus data pendaftar.'
        ], 500);
    }
}


public function verifikasi($id)
{
    try {
        $pendaftaran = Bayar::findOrFail($id);

        // Update status pembayaran
        $pendaftaran->statusBayar = 'lunas';
        $pendaftaran->save();

        return response()->json([
            'success' => true,
            'message' => 'Pembayaran berhasil diverifikasi.'
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Terjadi kesalahan saat memverifikasi pembayaran.'
        ]);
    }
}

}
