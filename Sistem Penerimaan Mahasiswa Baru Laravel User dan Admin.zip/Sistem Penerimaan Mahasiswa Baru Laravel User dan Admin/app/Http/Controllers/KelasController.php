<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kelas;

class KelasController extends Controller
{
    public function index(Request $request)
    {
        $query = Kelas::query();

        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('namaKelas', 'LIKE', "%{$search}%")
                    ->orWhere('jnsKelas', 'LIKE', "%{$search}%");
            });
        }

        $kelasList = $query->orderBy('created_at', 'desc')
            ->paginate(5)
            ->appends($request->query());

        return view('admin.kelas.index', compact('kelasList'));
    }

    public function create()
    {
        return view('admin.kelas.create');
    }

    public function store(Request $request)
    {
        // Validasi data
        $request->validate([
            'namaKelas' => 'required|string|max:255',
            'jnsKelas' => 'required|string|max:255',
        ]);

        try {
            // Simpan data ke database
            Kelas::create([
                'namaKelas' => $request->namaKelas,
                'jnsKelas' => $request->jnsKelas,
            ]);

            return redirect('/kelas/index')->with('success', 'Data kelas berhasil disimpan.');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Terjadi kesalahan saat menyimpan data.');
        }
    }

    public function edit($id)
    {
        $kelas = Kelas::findOrFail($id);
        return view('admin.kelas.edit', compact('kelas'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'namaKelas' => 'required|string|max:255',
            'jnsKelas' => 'required|string|max:255',
        ]);

        $kelas = Kelas::findOrFail($id);
        $kelas->namaKelas = $request->namaKelas;
        $kelas->jnsKelas = $request->jnsKelas;
        $kelas->save();

           return redirect('/kelas/index')->with('success', 'Data berhasil diperbarui.');
    }

    public function destroy($id)
    {
        try {
            $kelas = Kelas::findOrFail($id);
            $kelas->delete();

            return response()->json([
                'success' => true,
                'message' => 'Data kelas berhasil dihapus.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus data kelas.'
            ], 500);
        }
    }

    public function show($id)
    {
        $kelas = Kelas::findOrFail($id);
        return view('admin.kelas.show', compact('kelas'));
    }

}
