<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BayarRegis;
use App\Models\Promo;
use App\Models\CalonMahasiswa;
use App\Models\UserProgress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class BayarRegisController extends Controller
{
    /**
     * Tampilkan halaman form pembayaran registrasi
     */
   public function create()
{
    $user = Auth::user();
    if (!$user) {
        return redirect()->route('login')->withErrors(['error' => 'Anda harus login.']);
    }

    // Tambahkan with('kelas', 'prodi') untuk load relasi
    $calon = $user->calonMahasiswa()->with(['kelas', 'prodi'])->first();

    if (!$calon) {
        return redirect()->route('form.data_diri')->with('info', 'Silakan isi data diri terlebih dahulu.');
    }

    // Cek jika sudah pernah bayar registrasi
    $sudahBayar = BayarRegis::where('calon_mahasiswa_id', $calon->id)->exists();
    if ($sudahBayar) {
        return redirect()->route('maba.dashboard')->with('info', 'Anda sudah mengirimkan pembayaran registrasi.');
    }

    return view('maba.form.registrasi', compact('calon'));
}


    /**
     * Simpan pembayaran registrasi
     */
    public function store(Request $request)
    {
        Log::info("Request Pembayaran Registrasi Masuk", $request->except(['buktiBayar']));

        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login')->withErrors(['error' => 'Anda harus login.']);
        }

        $calon = $user->calonMahasiswa;
        if (!$calon) {
            return back()->withErrors(['error' => 'Data calon mahasiswa tidak ditemukan.']);
        }

        $request->validate([
            'buktiBayar'  => 'required|file|mimes:jpg,jpeg,png,pdf|max:5120',
            'totalBayar'  => 'required|numeric|min:10000',
            'promo_nama'  => 'nullable|string'
        ]);

        DB::beginTransaction();
        try {
            // Cek promo
            $promo = null;
            $diskon = 0;
            if ($request->promo_nama) {
                $promo = Promo::whereRaw('LOWER(namaPromo) = ?', [strtolower($request->promo_nama)])
                    ->whereDate('tglMulai', '<=', now())
                    ->whereDate('tglBerakhir', '>=', now())
                    ->first();

                if (!$promo) {
                    return back()->withErrors(['promo_nama' => 'Kode promo tidak valid atau kedaluwarsa.']);
                }

                $diskon = intval($promo->jmlPromo);
            }

            $total = 3000000 - $diskon;
            $total = max(0, $total);

            // Simpan file bukti pembayaran (BLOB)
            $buktiBayarBlob = null;
            if ($request->hasFile('buktiBayar') && $request->file('buktiBayar')->isValid()) {
                $file = $request->file('buktiBayar');
                $buktiBayarBlob = file_get_contents($file->getRealPath());
            }

            $bayar = new BayarRegis();
            $bayar->calon_mahasiswa_id = $calon->id;
            $bayar->promo_id = $promo?->id;
            $bayar->admin_id = null;
            $bayar->totalBayar = $total;
            $bayar->tglBayar = now();
            $bayar->statusBayar = 'pending';
            $bayar->buktiBayar_blob = $buktiBayarBlob;
            $bayar->save();

            // Tandai progress registrasi selesai
            $progress = UserProgress::firstOrNew(['calon_mahasiswa_id' => $calon->id]);
            $progress->biaya_registrasi_completed = true;
            $progress->save();

            DB::commit();
            return redirect()->route('maba.dashboard')->with('success', 'Pembayaran registrasi berhasil dikirim!');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Gagal menyimpan pembayaran registrasi', [
                'error' => $e->getMessage(),
            ]);
            return back()->withErrors(['error' => 'Terjadi kesalahan saat menyimpan pembayaran.']);
        }
    }

    /**
     * Tampilkan bukti bayar untuk admin (inline preview)
     */
    public function lihatBukti($id)
    {
        $bayar = BayarRegis::findOrFail($id);
        if (!$bayar->buktiBayar_blob) {
            abort(404, 'Bukti bayar tidak ditemukan.');
        }

        $mimeType = $bayar->getFileMimeType() ?? 'application/octet-stream';

        return response($bayar->buktiBayar_blob)
            ->header('Content-Type', $mimeType)
            ->header('Content-Disposition', 'inline; filename="bukti_registrasi"');
    }
}
