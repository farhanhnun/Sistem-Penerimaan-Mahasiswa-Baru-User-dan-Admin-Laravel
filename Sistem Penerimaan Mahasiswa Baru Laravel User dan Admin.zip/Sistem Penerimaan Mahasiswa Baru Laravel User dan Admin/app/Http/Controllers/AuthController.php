<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use App\Models\CalonMahasiswa;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth; // Tetap diimport jika ada fungsi lain yang menggunakannya (misal prosesLogin)
use App\Models\UserProgress;

class AuthController extends Controller
{
    public function prosesDaftar(Request $request)
    {
        $request->validate([
            'namaLengkap' => 'required',
            'noHP' => 'required|max:15',
            'email' => 'required|email',
            'username' => 'required|unique:users',
            'password' => 'required|min:6|confirmed',
        ]);

        try {
            DB::beginTransaction();

            // Simpan password mentah sementara sebelum di-hash untuk ditampilkan di pop-up
            // PERINGATAN KEAMANAN: Mengirim password mentah ke frontend tidak disarankan.
            // Gunakan ini dengan risiko Anda sendiri atau hanya tampilkan username saja.
            $rawPassword = $request->password;

            $user = User::create([
                'username' => $request->username,
                'password' => Hash::make($request->password), // Password di-hash saat disimpan
                'role' => 'calon_mahasiswa',
            ]);

            $calon = CalonMahasiswa::create([
                'user_id' => $user->id,
                'namaLengkap' => $request->namaLengkap,
                'email' => $request->email,
                'telepon' => $request->noHP,
                'alamat_id' => null,
                'prodi_id' => null,
                'kelas_id' => null,
                'noPendaftaran' => 'PMB-' . now()->format('YmdHis') . '-' . $user->id,
                'nik' => null,
                'tempatLahir' => null,
                'tglLahir' => null,
                'jnsKelamin' => null,
                'agama' => null,
                'golonganDarah' => null,
                'statusPernikahan' => null,
            ]);

            // Inisialisasi UserProgress untuk calon mahasiswa yang baru mendaftar
            UserProgress::create([
                'calon_mahasiswa_id' => $calon->id,
                'biaya_pendaftaran_completed' => false,
                'biaya_registrasi_completed' => false,
                'data_pribadi_completed' => false,
                'data_orangtua_completed' => false,
                'asal_sekolah_completed' => false,
            ]);

            DB::commit();

            \Log::info('SUKSES prosesDaftar: User and CalonMahasiswa created and UserProgress initialized.', ['user_id' => $user->id, 'calon_id' => $calon->id]);

            // --- KARENA PENGGUNA INGIN POP-UP LALU KE HALAMAN LOGIN ---
            // Hapus Auth::login($user); // JANGAN login otomatis di sini

            // Respons untuk request AJAX (jika Anda punya front-end yang mengirim AJAX)
            if ($request->ajax()) {
                return response()->json([
                    'success' => true,
                    'message' => 'Akun berhasil dibuat!',
                    'username' => $user->username,
                    'password' => $rawPassword, // Peringatan keamanan: Mengirim password mentah.
                    'data' => [
                        'user_id' => $user->id,
                        'no_pendaftaran' => $calon->noPendaftaran
                    ]
                ]);
            }

            // Respons untuk form submission biasa (non-AJAX)
            // Redirect kembali ke halaman registrasi dengan flash message
            return back()->with([
                'registration_success' => true, // Flag untuk JavaScript di Blade
                'username' => $user->username,
                'registered_password' => $rawPassword, // Peringatan keamanan: Mengirim password mentah ke session.
                'message' => 'Akun berhasil dibuat! Silakan login.'
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error('ERROR prosesDaftar: ' . $e->getMessage(), ['exception' => $e]);

            if ($request->ajax()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Gagal membuat akun: ' . $e->getMessage()
                ], 422);
            }

            return back()->withErrors(['error' => 'Gagal membuat akun: ' . $e->getMessage()])->withInput();
        }
    }

    // Metode prosesLogin tetap sama seperti sebelumnya
    public function prosesLogin(Request $request)
    {
        $credentials = $request->validate([
            'username' => 'required|string',
            'password' => 'required|string'
        ]);

        if (Auth::attempt($credentials, $request->boolean('remember'))) {
            $request->session()->regenerate();
            $user = Auth::user();

            if ($user->role === 'admin') {
                return redirect()->intended(route('admin.index'));
            }

            return redirect()->intended(route('maba.dashboard'));
        }

        return back()->withErrors([
            'loginError' => 'Username atau password salah.'
        ])->onlyInput('username');
    }

    // ... (metode cariEmail, prosesResetPassword, dll. yang sudah ada)

    public function logout(Request $request)
{
    Auth::logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();

    return redirect()->route('login');
}
}
