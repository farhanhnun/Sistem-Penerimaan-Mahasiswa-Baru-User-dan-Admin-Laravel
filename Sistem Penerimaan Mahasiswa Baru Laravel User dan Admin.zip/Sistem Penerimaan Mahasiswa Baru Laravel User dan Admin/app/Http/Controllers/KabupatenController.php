<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kabupaten;

class KabupatenController extends Controller
{
    public function index(Request $request)
    {
        $query = Kabupaten::with('provinsi'); // include relasi provinsi

        // Filter pencarian berdasarkan nama kabupaten
        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where('namaKabupaten', 'like', '%' . $search . '%')
                  ->orWhereHas('provinsi', function ($q) use ($search) {
                      $q->where('namaProvinsi', 'like', '%' . $search . '%');
                  });
        }

        $kabupatens = $query->orderBy('namaKabupaten')->paginate(10);

        return view('admin.kabupaten.index', compact('kabupatens'));
    }

   public function create()
{
    $provinsis = \App\Models\Provinsi::orderBy('namaProvinsi')->get();
    return view('admin.kabupaten.create', compact('provinsis'));
}


    public function store(Request $request)
    {
        $request->validate([
            'namaKabupaten' => 'required|string|max:255',
            'provinsi_id' => 'required|exists:provinsis,id',
        ]);

        try {
            Kabupaten::create([
                'namaKabupaten' => $request->namaKabupaten,
                'provinsi_id' => $request->provinsi_id,
            ]);

            return redirect('/kabupaten/index')->with('success', 'Data kabupaten berhasil disimpan.');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Terjadi kesalahan saat menyimpan data.');
        }
    }

    public function destroy($id)
    {
        try {
            $kabupaten = Kabupaten::findOrFail($id);
            $kabupaten->delete();

            return response()->json([
                'success' => true,
                'message' => 'Data kabupaten berhasil dihapus.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus data kabupaten.'
            ], 500);
        }
    }


    public function edit($id)
    {
        $kabupaten = \App\Models\Kabupaten::findOrFail($id); // cari kabupaten berdasarkan ID
        $provinsis = \App\Models\Provinsi::orderBy('namaProvinsi')->get(); // ambil semua provinsi

        return view('admin.kabupaten.edit', compact('kabupaten', 'provinsis'));
    }

    public function update(Request $request, $id)
    {
        // Validasi input
        $request->validate([
            'namaKabupaten' => 'required|string|max:255',
            'provinsi_id' => 'required|exists:provinsis,id',
        ]);

        try {
            $kabupaten = \App\Models\Kabupaten::findOrFail($id);

            // Update data
            $kabupaten->update([
                'namaKabupaten' => $request->namaKabupaten,
                'provinsi_id' => $request->provinsi_id,
            ]);

        return redirect('/kabupaten/index')->with('success', 'Data berhasil diperbarui.');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Terjadi kesalahan saat memperbarui data.');
        }
    }

    public function show($id)
    {
        $kabupaten = Kabupaten::with('provinsi')->findOrFail($id);

        return view('admin.kabupaten.show', compact('kabupaten'));
    }


}
