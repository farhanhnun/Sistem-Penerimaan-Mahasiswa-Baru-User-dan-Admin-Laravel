<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Prodi;

class ProdiController extends Controller
{
    public function index(Request $request)
    {
        $query = Prodi::query();

        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('namaProdi', 'LIKE', "%{$search}%")
                    ->orWhere('jmlSKS', 'LIKE', "%{$search}%");
            });
        }

        $prodiList = $query->orderBy('created_at', 'desc')
            ->paginate(5)
            ->appends($request->query());

        return view('admin.prodi.index', compact('prodiList'));
    }

    public function create()
    {
        return view('admin.prodi.create');
    }

    public function store(Request $request)
    {
        // Validasi data
        $request->validate([
            'namaProdi' => 'required|string|max:255',
            'jmlSKS' => 'required|integer',
        ]);

        try {
            // Simpan data ke database
            Prodi::create([
                'namaProdi' => $request->namaProdi,
                'jmlSKS' => $request->jmlSKS,
            ]);

            return redirect('/prodi/index')->with('success', 'Data prodi berhasil disimpan.');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Terjadi kesalahan saat menyimpan data.');
        }
    }

    public function edit($id)
    {
        $prodi = Prodi::findOrFail($id);
        return view('admin.prodi.edit', compact('prodi'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'namaProdi' => 'required|string|max:255',
            'jmlSKS' => 'required|integer',
        ]);

        $prodi = Prodi::findOrFail($id);
        $prodi->namaProdi = $request->namaProdi;
        $prodi->jmlSKS = $request->jmlSKS;
        $prodi->save();

         return redirect('/prodi/index')->with('success', 'Data berhasil diperbarui.');
    }

    public function destroy($id)
    {
        try {
            $prodi = Prodi::findOrFail($id);
            $prodi->delete();

            return response()->json([
                'success' => true,
                'message' => 'Data prodi berhasil dihapus.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus data prodi.'
            ], 500);
        }
    }

    public function show($id)
    {
        $prodi = Prodi::findOrFail($id);
        return view('admin.prodi.show', compact('prodi'));
    }

}
