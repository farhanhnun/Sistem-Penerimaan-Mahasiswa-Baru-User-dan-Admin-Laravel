<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Alamat;
use App\Models\OrangTua;
use App\Models\Kabupaten; // Pastikan ini diimport jika digunakan di getKabupaten/getKecamatan
use App\Models\Kecamatan; // Pastikan ini diimport jika digunakan di getKabupaten/getKecamatan
use App\Models\CalonMahasiswa;
use App\Models\Provinsi;
use App\Models\UserProgress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class OrangTuaController extends Controller
{
    /**
     * Tampilkan form data orang tua
     */
    public function create()
    {
        $provinsis = Provinsi::all();
        $user = Auth::user(); // Gunakan Auth::user()
        $calonMahasiswa = $user->calonMahasiswa; // Dapatkan calon mahasiswa dari user yang login

        $orangTua = null;
        $alamatOrtu = null;

        // Pastikan calonMahasiswa ada sebelum mencoba mengakses relasi orangTua
        if ($calonMahasiswa) {
            $orangTua = $calonMahasiswa->orangTua; // Coba ambil data orang tua yang sudah ada

            // Jika data orang tua ditemukan, coba ambil alamatnya
            if ($orangTua) {
                $alamatOrtu = $orangTua->alamat;
            }
        }

        // Jika Anda ingin mengisi form dengan data yang sudah ada
        return view('maba.form.data_orangtua', compact('provinsis', 'orangTua', 'alamatOrtu'));
    }

    /**
     * Simpan atau perbarui data orang tua ke database
     */
    public function store(Request $request)
    {
        Log::info('Masuk ke method store data orang tua');
        Log::info($request->all());

        // Dapatkan calon mahasiswa yang sedang login
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login')->withErrors(['error' => 'Anda harus login untuk menyimpan data.']);
        }
        $calonMahasiswa = $user->calonMahasiswa;

        // Pengecekan defensif jika calonMahasiswa belum ditemukan (meskipun seharusnya sudah dibuat saat registrasi)
        if (!$calonMahasiswa) {
            // Ini bisa terjadi jika ada inkonsistensi data atau flow registrasi tidak sempurna
            Log::error('Data calon mahasiswa tidak ditemukan untuk user_id: ' . $user->id);
            return redirect()->back()->with('error', 'Data calon mahasiswa tidak ditemukan. Silakan hubungi admin.');
        }

        $request->validate([
            'namaAyah' => 'required|string|max:255',
            'namaIbu' => 'required|string|max:255',
            'telepon' => 'required|string|max:15',
            'email' => 'required|email|max:255',
            'agama' => 'required|string|max:50',
            'pendidikanTerakhir' => 'required|string|max:255',
            'pekerjaan' => 'required|string|max:255',
            'penghasilan' => 'required|string', // Ini akan diconvert ke numeric

            'provinsi_id' => 'required|numeric|exists:provinsis,id',
            'kabupaten_id' => 'required|numeric|exists:kabupatens,id',
            'kecamatan_id' => 'required|numeric|exists:kecamatans,id',
            'desa' => 'required|string|max:255', // Ini mapping ke kelurahan
            'alamat' => 'required|string|max:500', // Ini mapping ke alamatLengkap
            'rt' => 'required|string|max:5',
            'rw' => 'required|string|max:5',
            'kodepos' => 'required|string|max:10', // Ini mapping ke kodePos
        ]);

        DB::beginTransaction(); // Memulai transaksi database

        try {
            // Mengubah format penghasilan dari string ke angka
            $penghasilanPerBulan = match ($request->penghasilan) {
                '1jt' => 1000000,
                '1-3jt' => 3000000,
                '3-5jt' => 5000000,
                '5-10jt' => 10000000,
                '>10jt' => 15000000,
                default => 0,
            };

            // --- Logic untuk mengelola Alamat Orang Tua ---
            // Cari data OrangTua yang sudah ada untuk calon mahasiswa ini
            $orangTua = OrangTua::firstOrNew(['calon_mahasiswa_id' => $calonMahasiswa->id]);

            // Jika OrangTua sudah ada dan memiliki alamat_id, ambil objek Alamatnya. Jika tidak, buat Alamat baru.
            // Pastikan relasi 'alamat' ada di model OrangTua
            $alamatOrtu = $orangTua->alamat()->firstOrNew([]);

            // Isi data Alamat
            $alamatOrtu->provinsi_id = $request->provinsi_id;
            $alamatOrtu->kabupaten_id = $request->kabupaten_id;
            $alamatOrtu->kecamatan_id = $request->kecamatan_id;
            $alamatOrtu->kelurahan = $request->desa;
            $alamatOrtu->alamatLengkap = $request->alamat;
            $alamatOrtu->rt = $request->rt;
            $alamatOrtu->rw = $request->rw;
            $alamatOrtu->kodePos = $request->kodepos;
            $alamatOrtu->save(); // Simpan alamat

            // Isi dan simpan data OrangTua
            $orangTua->namaAyah = $request->namaAyah;
            $orangTua->namaIbu = $request->namaIbu;
            $orangTua->alamat_id = $alamatOrtu->id; // Pastikan alamat_id diisi
            $orangTua->telepon = $request->telepon;
            $orangTua->email = $request->email;
            $orangTua->agama = $request->agama;
            $orangTua->pendidikanTerakhir = $request->pendidikanTerakhir;
            $orangTua->pekerjaan = $request->pekerjaan;
            $orangTua->penghasilanPerBulan = $penghasilanPerBulan;
            $orangTua->save(); // Simpan data OrangTua

            // --- Logika Update UserProgress ---
            // Dapatkan atau buat entri UserProgress untuk calon mahasiswa ini
            $userProgress = UserProgress::firstOrNew(['calon_mahasiswa_id' => $calonMahasiswa->id]);
            $userProgress->data_orangtua_completed = true; // Set menjadi true
            $userProgress->save();
            // --- Akhir Logika Update UserProgress ---

            DB::commit(); // Mengakhiri transaksi jika semua berhasil

            Log::info('Data orang tua berhasil disimpan.');
            return redirect()->route('maba.dashboard')->with('success', 'Data orang tua berhasil disimpan.');

        } catch (\Exception $e) {
            DB::rollBack(); // Rollback transaksi jika ada error
            Log::error('Gagal menyimpan data orang tua: ' . $e->getMessage(), ['exception' => $e]);
            return redirect()->back()->with('error', 'Terjadi kesalahan saat menyimpan data orang tua. Silakan coba lagi.');
        }
    }

    // Fungsi untuk mendapatkan data kabupaten dan kecamatan (jika digunakan di form ini)
    public function getKabupaten($provinsi_id)
    {
        $kabupatens = Kabupaten::where('provinsi_id', $provinsi_id)->get();
        return response()->json($kabupatens);
    }

    public function getKecamatan($kabupaten_id)
    {
        $kecamatans = Kecamatan::where('kabupaten_id', $kabupaten_id)->get();
        return response()->json($kecamatans);
    }
}
