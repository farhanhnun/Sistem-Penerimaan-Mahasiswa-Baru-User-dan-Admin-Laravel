<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\BayarRegis;
use App\Models\CalonMahasiswa;
use Illuminate\Support\Facades\DB;

class VerifregisController extends Controller
{
    /**
     * Menampilkan daftar pembayaran registrasi
     */
    public function index(Request $request)
    {
        $query = BayarRegis::with(['calonMahasiswa', 'promo']);

        if ($search = $request->search) {
            $query->whereHas('calonMahasiswa', function ($q) use ($search) {
                $q->where('namaLengkap', 'like', "%$search%")
                  ->orWhere('email', 'like', "%$search%");
            });
        }

        $registrasis = $query->orderByDesc('created_at')->paginate(10);
        return view('admin.verifregis.index', compact('registrasis'));
    }

    /**
     * Menampilkan form edit pembayaran registrasi
     */
    public function edit($id)
    {
        $bayar = BayarRegis::with(['calonMahasiswa'])->findOrFail($id);
        return view('admin.verifregis.edit', compact('bayar'));
    }

    /**
     * Proses update data registrasi
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'namaLengkap' => 'required|string|max:255',
            'email' => 'required|email',
            'telepon' => 'required|string|max:20',
            'statusBayar' => 'required|in:pending,lunas,gagal',
            'buktiBayar' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:2048',
        ]);

        DB::beginTransaction();
        try {
            $bayar = BayarRegis::with('calonMahasiswa')->findOrFail($id);

            // Update data calon mahasiswa
            $calon = $bayar->calonMahasiswa;
            $calon->update([
                'namaLengkap' => $request->namaLengkap,
                'email'       => $request->email,
                'telepon'     => $request->telepon,
            ]);

            // Update status bayar dan file
            $bayar->statusBayar = $request->statusBayar;

            if ($request->hasFile('buktiBayar')) {
                $file = $request->file('buktiBayar');
                $bayar->buktiBayar_blob = file_get_contents($file);
                $bayar->nama_file_bukti_bayar = $file->getClientOriginalName();
            }

            $bayar->save();

            DB::commit();
            return redirect()->route('verifregis.index')->with('success', 'Data berhasil diperbarui.');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->withErrors(['error' => 'Terjadi kesalahan: ' . $e->getMessage()]);
        }
    }

    /**
     * Tampilkan detail registrasi
     */
    public function show($id)
    {
        $bayar = BayarRegis::with(['calonMahasiswa', 'promo', 'admin'])->findOrFail($id);
        return view('admin.verifregis.show', compact('bayar'));
    }

    /**
     * Menampilkan file bukti bayar secara inline
     */
    public function lihatBukti($id)
    {
        $bayar = BayarRegis::findOrFail($id);
        if (!$bayar->buktiBayar_blob) {
            abort(404, 'Bukti bayar tidak ditemukan.');
        }

        $mimeType = finfo_buffer(finfo_open(), $bayar->buktiBayar_blob, FILEINFO_MIME_TYPE);

        return response($bayar->buktiBayar_blob)
            ->header('Content-Type', $mimeType)
            ->header('Content-Disposition', 'inline; filename="' . ($bayar->nama_file_bukti_bayar ?? 'bukti.pdf') . '"');
    }

    

    /**
     * Hapus data pembayaran registrasi
     */
    public function destroy($id)
    {
        try {
            $bayar = BayarRegis::findOrFail($id);
            $bayar->delete();

            return response()->json(['success' => true, 'message' => 'Data registrasi berhasil dihapus.']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Gagal menghapus data.'], 500);
        }
    }


    public function verifikasi($id)
{
    try {
        $pendaftaran = BayarRegis::findOrFail($id);

        // Update status pembayaran
        $pendaftaran->statusBayar = 'lunas';
        $pendaftaran->save();

        return response()->json([
            'success' => true,
            'message' => 'Pembayaran berhasil diverifikasi.'
        ]);
    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'message' => 'Terjadi kesalahan saat memverifikasi pembayaran.'
        ]);
    }
}
}
