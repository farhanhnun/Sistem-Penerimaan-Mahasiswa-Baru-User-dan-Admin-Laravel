<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Provinsi;

class ProvinsiController extends Controller
{
    public function index(Request $request)
    {
        $query = Provinsi::query();

        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('namaProvinsi', 'LIKE', "%{$search}%");
            });
        }

        $provinsis = $query->orderBy('created_at', 'desc')
            ->paginate(5)
            ->appends($request->query());

        return view('admin.provinsi.index', compact('provinsis'));
    }

    public function destroy($id)
    {
        try {
            $provinsi = Provinsi::findOrFail($id);
            $provinsi->delete();

            return response()->json([
                'success' => true,
                'message' => 'Data provinsi berhasil dihapus.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus provinsi sekolah.'
            ], 500);
        }
    }

    public function create()
    {
        return view('admin.provinsi.create');
    }

    public function store(Request $request)
    {
        // Validasi data
        $request->validate([
            'namaProvinsi' => 'required|string|max:255',
        ]);

        try {
            // Simpan data ke database
            Provinsi::create([
                'namaProvinsi' => $request->namaProvinsi,
            ]);

            // Redirect kembali dengan pesan sukses
            return redirect('/provinsi/index')->with('success', 'Data provinsi berhasil disimpan.');

        } catch (\Exception $e) {
            // Redirect kembali dengan pesan error
            return redirect()->back()->with('error', 'Terjadi kesalahan saat menyimpan data.');
        }
    }

     public function edit($id)
    {
        $provinsi = Provinsi::findOrFail($id); // cari provinsi berdasarkan ID
        return view('admin.provinsi.edit', compact('provinsi'));
    }


    // Method untuk menyimpan hasil edit
    public function update(Request $request, $id)
    {
        $request->validate([
            'namaProvinsi' => 'required|string|max:255',
        ]);

        $provinsi = Provinsi::findOrFail($id);

        $provinsi->namaProvinsi = $request->namaProvinsi;
        $provinsi->save();

          return redirect('/provinsi/index')->with('success', 'Data berhasil diperbarui.');
    }

    public function show($id)
{
    $provinsi = Provinsi::findOrFail($id); // cari berdasarkan ID, kalau tidak ketemu akan error 404

    return view('admin.provinsi.show', compact('provinsi'));
}

}
