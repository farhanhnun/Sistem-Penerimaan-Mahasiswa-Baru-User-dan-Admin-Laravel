<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CalonMahasiswa;
use App\Models\Alamat;
use Illuminate\Support\Facades\Storage;
use App\Models\Provinsi;
use App\Models\Kabupaten;
use App\Models\Kecamatan;
use Illuminate\Support\Facades\Log;
use App\Models\UserProgress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB; // Tambahkan untuk transaksi

class DataDiriController extends Controller
{
    /**
     * Tampilkan form data diri
     */
    public function create()
    {
        // Gunakan Auth::user() untuk mendapatkan user yang sedang login
        $user = Auth::user();

        // Pastikan user adalah calon_mahasiswa dan memiliki relasi CalonMahasiswa
        if (!$user || $user->role !== 'calon_mahasiswa') {
            return redirect()->route('login')->withErrors(['error' => 'Akses tidak sah.']);
        }

        // Ambil data calon mahasiswa yang terhubung. Ini bisa null jika user baru register
        // dan belum mengisi form data diri pertama kali.
        $calon = $user->calonMahasiswa;

        // Jika data calon mahasiswa belum ada, inisialisasi objek kosong
        // ini untuk mencegah error di view jika properti diakses pada null
        // dan untuk pre-fill form kosong pada isian pertama kali.
        if (!$calon) {
            $calon = new CalonMahasiswa();
            // Anda bisa set user_id di sini jika CalonMahasiswa baru akan dibuat di method store
            $calon->user_id = $user->id; // Penting untuk menyimpan relasi jika ini form pengisian pertama
        }

        $provinsis = Provinsi::all();

        return view('maba.form.data_diri', compact('calon', 'provinsis'));
    }

    /**
     * Simpan atau perbarui data diri ke database
     */
    public function store(Request $request)
    {
        Log::info("Request Data Diri", $request->all());

        $request->validate([
            'foto' => 'nullable|image|mimes:jpg,jpeg,png|max:2048', // Ubah ke nullable jika foto bisa diupdate nanti tanpa harus upload ulang
            'nik' => 'required|digits:16',
            'tempatLahir' => 'required|string|max:255',
            'tanggalLahir' => 'required|date', // 'tanggalLahir' sesuai nama input di form
            'jnsKelamin' => 'required|in:L,P',
            'agama' => 'required|string|max:50',
            'provinsi_id' => 'required|numeric|exists:provinsis,id', // Validasi exists
            'kabupaten_id' => 'required|numeric|exists:kabupatens,id', // Validasi exists
            'kecamatan_id' => 'required|numeric|exists:kecamatans,id', // Validasi exists
            'kelurahan' => 'required|string|max:255',
            'rt' => 'required|string|max:5',
            'rw' => 'required|string|max:5',
            'kodePos' => 'required|string|max:10',
            'alamatLengkap' => 'required|string|max:500',
        ]);

        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login')->withErrors(['error' => 'Anda harus login untuk menyimpan data.']);
        }

        // Dapatkan objek CalonMahasiswa yang terkait dengan user ini
        // Ini akan mengembalikan objek jika ada, atau null jika belum ada.
        $calon = $user->calonMahasiswa;

        // Jika CalonMahasiswa belum ada (misal, ini adalah submit form data diri pertama setelah registrasi),
        // maka buat baru. Kalau sudah ada, maka kita akan update.
        // Seharusnya ini tidak lagi null karena sudah dibuat di prosesDaftar.
        // Namun, ini adalah pengecekan defensif.
        if (!$calon) {
            $calon = CalonMahasiswa::create(['user_id' => $user->id]); // Buat instance dasar
        }

        DB::beginTransaction(); // Mulai transaksi database untuk atomicity

        try {
            // --- Logika untuk mengelola Alamat ---
            // Cari alamat yang sudah terhubung dengan calon mahasiswa ini, atau buat instance baru
            $alamat = $calon->alamat()->firstOrNew([]);

            $alamat->provinsi_id = $request->provinsi_id;
            $alamat->kabupaten_id = $request->kabupaten_id;
            $alamat->kecamatan_id = $request->kecamatan_id;
            $alamat->kelurahan = $request->kelurahan;
            $alamat->rt = $request->rt;
            $alamat->rw = $request->rw;
            $alamat->kodePos = $request->kodePos;
            $alamat->alamatLengkap = $request->alamatLengkap;
            $alamat->save(); // Simpan atau update alamat

            // Simpan foto ke penyimpanan jika ada
            $fotoPath = $calon->foto; // Default: pertahankan foto lama
            if ($request->hasFile('foto')) {
                // Hapus foto lama jika ada dan berbeda
                if ($calon->foto && Storage::disk('public')->exists($calon->foto)) {
                    Storage::disk('public')->delete($calon->foto);
                }
                $fotoPath = $request->file('foto')->store('foto_mahasiswa', 'public');
            }

            // Update data calon mahasiswa
            $calon->update([
                'nik' => $request->nik,
                'tempatLahir' => $request->tempatLahir,
                'tglLahir' => $request->tanggalLahir, // Pastikan nama kolom sesuai DB
                'jnsKelamin' => $request->jnsKelamin,
                'agama' => $request->agama,
                // 'foto' => $fotoPath, // Sudah ditangani di atas
                'alamat_id' => $alamat->id, // Pastikan alamat_id terhubung
            ]);
            // Jika ada kolom 'foto' di fillable CalonMahasiswa
            if ($request->hasFile('foto')) {
                $calon->foto = $fotoPath;
                $calon->save(); // Simpan perubahan pada kolom foto
            }

            // --- Logika Update UserProgress ---
            // Dapatkan atau buat entri UserProgress untuk calon mahasiswa ini
            $userProgress = UserProgress::firstOrNew(['calon_mahasiswa_id' => $calon->id]);
            $userProgress->data_pribadi_completed = true; // Set menjadi true
            $userProgress->save();
            // --- Akhir Logika Update UserProgress ---

            DB::commit(); // Commit transaksi jika semua berhasil

            Log::info('Data diri berhasil disimpan.', ['calon_mahasiswa_id' => $calon->id, 'user_id' => $user->id]);
            return redirect()->route('maba.dashboard')->with('success', 'Data diri berhasil disimpan.');

        } catch (\Exception $e) {
            DB::rollBack(); // Rollback transaksi jika ada error
            Log::error('Gagal menyimpan data diri: ' . $e->getMessage(), ['exception' => $e]);
            return back()->withErrors(['error' => 'Terjadi kesalahan saat menyimpan data diri. Silakan coba lagi.'])->withInput();
        }
    }

    public function getKabupaten($provinsi_id)
    {
        $kabupatens = Kabupaten::where('provinsi_id', $provinsi_id)->get();
        return response()->json($kabupatens);
    }

    public function getKecamatan($kabupaten_id)
    {
        $kecamatans = Kecamatan::where('kabupaten_id', $kabupaten_id)->get();
        return response()->json($kecamatans);
    }
}
