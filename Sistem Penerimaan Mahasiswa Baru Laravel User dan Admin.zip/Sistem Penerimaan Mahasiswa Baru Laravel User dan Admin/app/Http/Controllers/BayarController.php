<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Bayar;
use App\Models\Promo;
use App\Models\Kelas;
use App\Models\Prodi;
use App\Models\CalonMahasiswa;
use App\Models\UserProgress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class BayarController extends Controller
{
    /**
     * Tampilkan halaman form pembayaran
     */
    public function create()
    {
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login')->withErrors(['error' => 'Anda harus login untuk mengakses halaman pembayaran.']);
        }

        $calon = $user->calonMahasiswa;
        if (!$calon) {
            return redirect()->route('form.data_diri')->with('info', 'Silakan lengkapi data pribadi Anda terlebih dahulu.');
        }

        $kelas = Kelas::all();
        $prodi = Prodi::all();
        $promos = Promo::all();
        $bayar = Bayar::where('calon_mahasiswa_id', $calon->id)->first();

        return view('maba.form.pembayaran', compact('calon', 'kelas', 'prodi', 'promos', 'bayar'));
    }

    /**
     * Simpan atau update data pembayaran
     */
    public function store(Request $request)
    {
        Log::info("Request Pembayaran Masuk", $request->except(['buktiBayar']));

        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login')->withErrors(['error' => 'Anda harus login untuk menyimpan pembayaran.']);
        }

        $calon = $user->calonMahasiswa;
        if (!$calon) {
            Log::error("Calon Mahasiswa tidak ditemukan untuk user_id: {$user->id}");
            return back()->withErrors(['error' => 'Data calon mahasiswa tidak ditemukan.'])->withInput();
        }

        $request->validate([
            'kelas_id'    => 'required|exists:kelas,id',
            'prodi_id'    => 'required|exists:prodis,id',
            'buktiBayar'  => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:5120',
            'totalBayar'  => 'required|numeric|min:10000',
            'promo_nama'  => 'nullable|string',
            'registrasi'  => 'nullable|in:0,1'
        ]);

        DB::beginTransaction();
        try {
            $calon->update([
                'kelas_id' => $request->kelas_id,
                'prodi_id' => $request->prodi_id,
            ]);

            $includeRegistrasi = $request->input('registrasi') == '1';

            if ($includeRegistrasi) {
                $sudahBayarRegis = Bayar::where('calon_mahasiswa_id', $calon->id)
                    ->where('is_include_regis', true)
                    ->exists();
                if ($sudahBayarRegis) {
                    return redirect()->back()->withErrors(['error' => 'Anda sudah membayar biaya registrasi sebelumnya.'])->withInput();
                }
            }

            // Cek promo
            $promo = null;
            $diskon = 0;
            $promoName = trim($request->input('promo_nama'));
            if ($promoName) {
                $promo = Promo::whereRaw('LOWER(namaPromo) = ?', [strtolower($promoName)])
                    ->whereDate('tglMulai', '<=', now())
                    ->whereDate('tglBerakhir', '>=', now())
                    ->first();

                if (!$promo) {
                    return back()->withErrors(['promo_nama' => 'Kode promo tidak valid atau sudah kedaluwarsa.'])->withInput();
                }

                $diskon = intval($promo->jmlPromo);
            }

            $total = 300000;
            if ($includeRegistrasi) {
                $total += 3000000;
            }
            $total -= $diskon;
            $total = max(0, $total);

            // Handle bukti bayar (BLOB)
            $buktiBayarBlob = null;
            $namaFile = null;
            if ($request->hasFile('buktiBayar') && $request->file('buktiBayar')->isValid()) {
                $file = $request->file('buktiBayar');
                $buktiBayarBlob = file_get_contents($file->getRealPath());
                $namaFile = $file->getClientOriginalName();

                Log::info("Bukti bayar diupload", [
                    'nama_file' => $namaFile,
                    'ukuran' => $file->getSize(),
                    'mime' => $file->getMimeType()
                ]);
            } else {
                Log::info("Tidak ada file bukti bayar yang diupload atau file tidak valid.");
            }

            // Simpan pembayaran
            $bayar = Bayar::firstOrNew(['calon_mahasiswa_id' => $calon->id]);
            $bayar->fill([
                'promo_id'      => $promo?->id,
                'admin_id'      => null,
                'totalBayar'    => $total,
                'tglBayar'      => now(),
                'statusBayar'   => 'pending',
                'buktiBayar_blob' => $buktiBayarBlob,
                'nama_file_bukti_bayar' => $namaFile,
                'is_include_regis' => $includeRegistrasi,
            ]);
            $bayar->save();

            // Simpan progress
            $userProgress = UserProgress::firstOrNew(['calon_mahasiswa_id' => $calon->id]);
            $userProgress->biaya_pendaftaran_completed = true;
            if ($includeRegistrasi) {
                $userProgress->biaya_registrasi_completed = true;
            }
            $userProgress->save();

            DB::commit();
            return redirect()->route('maba.dashboard')->with('success', 'Pembayaran berhasil dikirim! Menunggu verifikasi.');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Gagal menyimpan pembayaran', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return back()->withErrors(['error' => 'Terjadi kesalahan saat menyimpan pembayaran.'])->withInput();
        }
    }

    /**
     * Tampilkan bukti bayar dari database
     */
    public function lihatBukti($id)
    {
        $bayar = Bayar::findOrFail($id);

        if (!$bayar->buktiBayar_blob) {
            abort(404, 'Bukti bayar tidak ditemukan.');
        }

        $mimeType = finfo_buffer(finfo_open(), $bayar->buktiBayar_blob, FILEINFO_MIME_TYPE);
        return response($bayar->buktiBayar_blob)
            ->header('Content-Type', $mimeType)
            ->header('Content-Disposition', 'inline; filename="' . ($bayar->nama_file_bukti_bayar ?? 'bukti_bayar') . '"');
    }


    
}
