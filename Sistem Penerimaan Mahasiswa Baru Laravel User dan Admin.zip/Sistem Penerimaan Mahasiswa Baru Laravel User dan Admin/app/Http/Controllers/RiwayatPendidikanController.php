<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CalonMahasiswa;
use App\Models\RiwayatPendidikan;
use App\Models\AsalSekolah;
use App\Models\UserProgress; // Pastikan ini diimport
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth; // Pastikan ini diimport
use Illuminate\Support\Facades\DB; // Tambahkan untuk transaksi, meskipun tidak wajib di sini, bagus untuk konsistensi

class RiwayatPendidikanController extends Controller
{
    public function create()
    {
        $sekolahList = AsalSekolah::all();
        // Dapatkan user dan calon mahasiswa untuk navbar
        $user = Auth::user();
        $calon = $user ? $user->calonMahasiswa : null;
        // Ambil data riwayat pendidikan yang sudah ada untuk pre-fill form
        $riwayatPendidikan = $calon ? $calon->riwayatPendidikan : null;

        return view('maba.form.data_sekolah', compact('sekolahList', 'calon', 'user', 'riwayatPendidikan'));
    }

    public function store(Request $request)
    {
        Log::info("Request Riwayat Pendidikan", $request->all());

        // Dapatkan user yang sedang login
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login')->withErrors(['error' => 'Anda harus login untuk menyimpan data.']);
        }

        // Dapatkan calon mahasiswa yang terkait
        $calon = $user->calonMahasiswa;

        if (!$calon) {
            Log::error("Calon Mahasiswa tidak ditemukan untuk user_id: " . $user->id);
            return back()->withErrors(['error' => 'Data calon mahasiswa tidak ditemukan. Silakan lengkapi data pribadi terlebih dahulu.']);
        }

        $request->validate([
            'nisn' => 'required|digits:10',
            'schoolId' => 'required|exists:asal_sekolahs,id',
            'jurusan' => 'nullable|string|max:255',
            'tahunKelulusan' => 'required|integer|min:2010|max:' . now()->year,
            'ijazah' => 'nullable|file|mimes:jpg,jpeg,png,pdf|max:5120', // Ubah ke nullable jika update tanpa upload file baru
        ]);

        // Filter hanya data yang dibutuhkan
        $data = $request->only([
            'nisn',
            'schoolId',
            'jurusan',
            'tahunKelulusan',
        ]);

        DB::beginTransaction(); // Mulai transaksi database

        try {
            // Ambil data riwayat pendidikan yang sudah ada atau buat baru
            $riwayatPendidikan = RiwayatPendidikan::firstOrNew(['calon_mahasiswa_id' => $calon->id]);

            // Hapus ijazah lama jika ada ijazah baru diupload
            $ijazahPath = $riwayatPendidikan->ijazah; // Default: pertahankan path lama
            if ($request->hasFile('ijazah')) {
                if ($riwayatPendidikan->ijazah && Storage::disk('public')->exists($riwayatPendidikan->ijazah)) {
                    Storage::disk('public')->delete($riwayatPendidikan->ijazah);
                }
                $ijazahPath = $request->file('ijazah')->store('ijazah', 'public');
            }

            // Update atau buat data riwayat pendidikan
            $riwayatPendidikan->fill([ // Menggunakan fill() untuk mengisi atribut
                'sekolah_id' => $data['schoolId'],
                'nisn' => $data['nisn'],
                'jurusan' => $data['jurusan'],
                'tahunLulus' => $data['tahunKelulusan'],
                'ijazah' => $ijazahPath, // Pastikan kolom ijazah ada di $fillable
            ]);
            $riwayatPendidikan->save(); // Simpan perubahan

            // --- Logika Update UserProgress ---
            UserProgress::updateOrCreate(
                ['calon_mahasiswa_id' => $calon->id],
                ['asal_sekolah_completed' => true]
            );
            // --------------------------------------------------------

            DB::commit(); // Commit transaksi

            Log::info('Data asal sekolah berhasil disimpan.');
            return redirect()->route('maba.dashboard')->with('success', 'Data asal sekolah berhasil disimpan.');

        } catch (\Exception $e) {
            DB::rollBack(); // Rollback transaksi jika ada error
            Log::error('Gagal menyimpan data riwayat pendidikan: ' . $e->getMessage(), ['exception' => $e]);
            return back()->withErrors(['error' => 'Terjadi kesalahan saat menyimpan data asal sekolah. Silakan coba lagi.'])->withInput();
        }
    }
}
