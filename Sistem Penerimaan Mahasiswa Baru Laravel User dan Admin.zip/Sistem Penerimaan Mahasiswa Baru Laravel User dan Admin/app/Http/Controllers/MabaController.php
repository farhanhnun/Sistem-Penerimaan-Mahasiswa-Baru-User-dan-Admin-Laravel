<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\CalonMahasiswa;
use App\Models\Informasi; // <-- PASTIKAN INI DIIMPORT
use App\Models\UserProgress; // <-- PASTIKAN INI DIIMPORT (meskipun tidak dipakai langsung di informasi(), penting untuk konsistensi)
use Illuminate\Support\Facades\Auth; // <-- PASTIKAN INI DIIMPORT

use Illuminate\Http\Request;

class MabaController extends Controller
{
    public function index()
    {
        // Untuk navbar:
        $user = Auth::user();
        $calon = $user ? $user->calonMahasiswa : null;
        return view('maba.index', compact('calon', 'user'));
    }

    public function informasi()
    {
        // --- INI ADALAH BAGIAN YANG PERLU ANDA KEMBALIKAN/PERBAIKI ---
        $informasis = Informasi::orderBy('created_at', 'desc')->get();

        // Untuk navbar (user dan calon):
        $user = Auth::user();
        $calon = $user ? $user->calonMahasiswa : null; // $calon bisa null jika belum login atau belum mengisi data diri

        return view('maba.informasi', compact('informasis', 'calon', 'user'));
    }

    public function kontak()
    {
        // Untuk navbar:
        $user = Auth::user();
        $calon = $user ? $user->calonMahasiswa : null;
        return view('maba.kontak', compact('calon', 'user'));
    }

    public function showLoginForm()
    {
        return view('maba.login.login');
    }

    public function lupaPassword()
    {
        return view('maba.login.lupa_pasword');
    }

    public function passwordBaru()
    {
        return view('maba.login.pass_baru');
    }

    public function dashboard()
    {
        // Pastikan user adalah calon_mahasiswa untuk mengakses dashboard ini
        $user = Auth::user(); // Dapatkan user yang sedang login
        if (!$user || $user->role !== 'calon_mahasiswa') {
            return redirect()->route('login'); // Atau ke halaman lain yang sesuai
        }

        $calonMahasiswa = $user->calonMahasiswa;

        // Ambil data calon mahasiswa dari user

        $userProgress = null; // Inisialisasi default

        if ($calonMahasiswa) {
            // Ambil atau buat instance UserProgress untuk calon mahasiswa ini
            $userProgress = UserProgress::firstOrCreate(
                ['calon_mahasiswa_id' => $calonMahasiswa->id],
                [
                    'biaya_pendaftaran_completed' => false,
                    'biaya_registrasi_completed' => false,
                    'data_pribadi_completed' => false,
                    'data_orangtua_completed' => false,
                    'asal_sekolah_completed' => false,
                ]
            );
        } else {
            $userProgress = new UserProgress();
            $userProgress->biaya_pendaftaran_completed = false;
            $userProgress->biaya_registrasi_completed = false;
            $userProgress->data_pribadi_completed = false;
            $userProgress->data_orangtua_completed = false;
            $userProgress->asal_sekolah_completed = false;
        }

        // Sekarang, Anda bisa melewatkan kedua variabel ini ke view
        return view('maba.dashboard', compact('calonMahasiswa', 'userProgress', 'user')); // Tambahkan 'user' untuk navbar
    }

    public function buatAkun()
    {
        // Untuk navbar:
        $user = Auth::user();
        $calon = $user ? $user->calonMahasiswa : null;
        return view('maba.form.buat_akun', compact('calon', 'user'));
    }

    public function dataDiri()
    {
        $user = Auth::user(); // Gunakan Auth::user()
        if (!$user) {
            return redirect()->route('login')->withErrors(['error' => 'Silakan login terlebih dahulu.']);
        }
        $calon = $user->calonMahasiswa; // Ambil data calon mahasiswa yang login

        // Pastikan $calon ada, jika tidak inisialisasi kosong
        if (!$calon) {
            $calon = new CalonMahasiswa();
            $calon->user_id = $user->id; // Penting untuk menyimpan data baru
        }
        return view('maba.form.data_diri', compact('calon', 'user'));
    }

    public function dataOrangtua()
    {
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login')->withErrors(['error' => 'Silakan login terlebih dahulu.']);
        }
        $calon = $user->calonMahasiswa;
        // Ambil data orang tua jika ada
        $orangTua = $calon ? $calon->orangTua : null; // Asumsi ada relasi orangTua di CalonMahasiswa

        return view('maba.form.data_orangtua', compact('calon', 'user', 'orangTua'));
    }

    public function dataSekolah()
    {
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login')->withErrors(['error' => 'Silakan login terlebih dahulu.']);
        }
        $calon = $user->calonMahasiswa;
        $sekolahList = \App\Models\AsalSekolah::all();
        // Ambil data riwayat pendidikan jika ada
        $riwayatPendidikan = $calon ? $calon->riwayatPendidikan : null; // Asumsi ada relasi riwayatPendidikan di CalonMahasiswa

        return view('maba.form.data_sekolah', compact('sekolahList', 'calon', 'user', 'riwayatPendidikan'));
    }

    public function pembayaran()
    {
        $user = Auth::user();
        if (!$user) {
            return redirect()->route('login')->withErrors(['error' => 'Silakan login terlebih dahulu.']);
        }
        $calon = $user->calonMahasiswa;

        return view('maba.form.pembayaran', compact('calon', 'user'));
    }

    public function formResetPassword($token)
    {
        $reset = DB::table('password_resets')->where('token', $token)->first();

        if (!$reset) {
            return redirect()->route('login')->withErrors(['token' => 'Token tidak valid atau sudah kedaluwarsa.']);
        }

        return view('auth.reset-password', [
            'token' => $token,
            'email' => $reset->email
        ]);
    }
}
