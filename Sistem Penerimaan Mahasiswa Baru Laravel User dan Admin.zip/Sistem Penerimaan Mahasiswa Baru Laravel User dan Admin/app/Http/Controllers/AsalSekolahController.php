<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AsalSekolah;

class AsalSekolahController extends Controller
{
    public function index(Request $request)
    {
        $query = AsalSekolah::query();

        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('namaSekolah', 'LIKE', "%{$search}%")
                    ->orWhere('alamat', 'LIKE', "%{$search}%");
            });
        }

        $sekolahs = $query->orderBy('created_at', 'desc')
            ->paginate(5)
            ->appends($request->query());

        return view('admin.asalsekolah.index', compact('sekolahs'));
    }

    public function destroy($id)
    {
        try {
            $sekolah = AsalSekolah::findOrFail($id);
            $sekolah->delete();

            return response()->json([
                'success' => true,
                'message' => 'Data asal sekolah berhasil dihapus.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus data asal sekolah.'
            ], 500);
        }
    }

    public function create()
    {
        return view('admin.asalsekolah.create');
    }

    public function store(Request $request)
    {
        // Validasi data
        $request->validate([
            'namaSekolah' => 'required|string|max:255',
            'alamat' => 'required|string',
        ]);

        try {
            // Simpan data ke database
            AsalSekolah::create([
                'namaSekolah' => $request->namaSekolah,
                'alamat' => $request->alamat,
            ]);

            // Redirect kembali dengan pesan sukses
           return redirect('/asalsekolah/index')->with('success', 'Data asal sekolah berhasil disimpan.');
        } catch (\Exception $e) {
            // Redirect kembali dengan pesan error
            return redirect()->back()->with('error', 'Terjadi kesalahan saat menyimpan data.');
        }
    }


    public function edit($id)
    {
        $sekolah = AsalSekolah::findOrFail($id); // cari sekolah berdasarkan ID
        return view('admin.asalsekolah.edit', compact('sekolah'));
    }

    // Method untuk menyimpan hasil edit
    public function update(Request $request, $id)
    {
        $request->validate([
            'namaSekolah' => 'required|string|max:255',
            'alamat' => 'required|string',
        ]);

        $sekolah = AsalSekolah::findOrFail($id);

        $sekolah->namaSekolah = $request->namaSekolah;
        $sekolah->alamat = $request->alamat;
        $sekolah->save();

       return redirect('/asalsekolah/index')->with('success', 'Data berhasil diperbarui.');
    }

    public function show($id)
    {
        $sekolah = AsalSekolah::findOrFail($id);
       return view('admin.asalsekolah.show', compact('sekolah'));

    }

}
