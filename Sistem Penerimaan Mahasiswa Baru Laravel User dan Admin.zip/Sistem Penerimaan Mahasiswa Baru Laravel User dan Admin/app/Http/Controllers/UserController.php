<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Admin;
use App\Models\CalonMahasiswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $query = User::with(['admin', 'calonMahasiswa']);

        if ($request->filled('search')) {
            $search = $request->search;

            $query->where('username', 'like', "%{$search}%")
                ->orWhereHas('admin', fn($q) => $q->where('namaAdmin', 'like', "%{$search}%"))
                ->orWhereHas('calonMahasiswa', fn($q) => $q->where('namaLengkap', 'like', "%{$search}%"));
        }

        $users = $query->orderBy('created_at', 'desc')
            ->paginate(10)
            ->appends($request->query());

        return view('admin.user.index', compact('users'));
    }

    public function create()
    {
        return view('admin.user.create');
    }

    public function store(Request $request)
    {
        $validated = $this->validateUserData($request);

        DB::beginTransaction();
        try {
            $user = User::create([
                'role' => $validated['role'],
                'username' => $validated['username'],
                'password' => Hash::make($validated['password']),
            ]);

            $this->createRelatedProfile($user, $validated);

            DB::commit();

            // Ubah ini: gunakan redirect()->back() agar popup muncul di halaman yang sama
            return redirect('user/index')->with('success', 'Data user berhasil disimpan.');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error creating user', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->back()->withInput()->with('error', 'Gagal menyimpan data user: ' . $e->getMessage());
        }
    }

    public function edit($id)
    {
        $user = User::with(['admin', 'calonMahasiswa'])->findOrFail($id);
        return view('admin.user.edit', compact('user'));
    }

    public function update(Request $request, $id)
    {
        $user = User::with(['admin', 'calonMahasiswa'])->findOrFail($id);

        $validated = $this->validateUserData($request, $user->id);

        DB::beginTransaction();
        try {
            $user->username = $validated['username'];

            if (!empty($validated['password'])) {
                $user->password = Hash::make($validated['password']);
            }

            $user->save();

            $this->updateRelatedProfile($user, $validated);

            DB::commit();

            // Ubah ini juga: gunakan redirect()->back() untuk consistency
            return redirect('/user/index')->with('success', 'Data berhasil diperbarui.');

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error updating user', ['error' => $e->getMessage()]);
            return redirect()->back()->withInput()->with('error', 'Gagal memperbarui data user: ' . $e->getMessage());
        }
    }

    public function destroy($id)
    {
        DB::beginTransaction();
        try {
            $user = User::with(['admin', 'calonMahasiswa'])->findOrFail($id);

            $user->admin?->delete();
            $user->calonMahasiswa?->delete();

            $user->delete();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Data user berhasil dihapus.'
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error deleting user', ['error' => $e->getMessage()]);
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus data user.'
            ], 500);
        }
    }

    private function validateUserData(Request $request, $userId = null)
    {
        $rules = [
            'role' => ['required', Rule::in(['admin', 'calon_mahasiswa'])],
            'username' => ['required', 'string', 'max:50', Rule::unique('users', 'username')->ignore($userId)],
            'password' => [$userId ? 'nullable' : 'required', 'string', 'min:6'],
            'telepon' => ['required', 'string', 'max:20'],
            'email' => [
                'required',
                'email',
                'max:255',
                function ($attribute, $value, $fail) use ($userId) {
                    $adminUsed = Admin::where('email', $value)->when($userId, fn($q) => $q->where('user_id', '!=', $userId))->exists();
                    $mahasiswaUsed = CalonMahasiswa::where('email', $value)->when($userId, fn($q) => $q->where('user_id', '!=', $userId))->exists();
                    if ($adminUsed || $mahasiswaUsed) {
                        $fail('Email sudah digunakan.');
                    }
                }
            ],
            'namaAdmin' => ['nullable', 'required_if:role,admin', 'string', 'max:255'],
            'namaLengkap' => ['nullable', 'required_if:role,calon_mahasiswa', 'string', 'max:255'],
        ];

        return $request->validate($rules);
    }

    private function createRelatedProfile(User $user, array $data)
    {
        if ($user->isAdmin()) {
            Admin::create([
                'user_id' => $user->id,
                'namaAdmin' => $data['namaAdmin'],
                'telepon' => $data['telepon'],
                'email' => $data['email'],
            ]);
        } elseif ($user->isCalonMahasiswa()) {
            CalonMahasiswa::create([
                'user_id' => $user->id,
                'namaLengkap' => $data['namaLengkap'],
                'telepon' => $data['telepon'],
                'email' => $data['email'],
                'noPendaftaran' => 'PMB' . now()->format('YmdHis') . rand(100, 999),
            ]);
        }
    }

    private function updateRelatedProfile(User $user, array $data)
    {
        if ($user->isAdmin()) {
            if ($user->admin) {
                $user->admin->update([
                    'namaAdmin' => $data['namaAdmin'],
                    'telepon' => $data['telepon'],
                    'email' => $data['email'],
                ]);
            } else {
                Admin::create([
                    'user_id' => $user->id,
                    'namaAdmin' => $data['namaAdmin'],
                    'telepon' => $data['telepon'],
                    'email' => $data['email'],
                ]);
            }
        } elseif ($user->isCalonMahasiswa()) {
            if ($user->calonMahasiswa) {
                $user->calonMahasiswa->update([
                    'namaLengkap' => $data['namaLengkap'],
                    'telepon' => $data['telepon'],
                    'email' => $data['email'],
                ]);
            } else {
                CalonMahasiswa::create([
                    'user_id' => $user->id,
                    'namaLengkap' => $data['namaLengkap'],
                    'telepon' => $data['telepon'],
                    'email' => $data['email'],
                ]);
            }
        }
    }

      public function show($id)
    {
        $user = User::with(['admin', 'calonMahasiswa'])->findOrFail($id);
        return view('admin.user.show', compact('user'));

    }

}
