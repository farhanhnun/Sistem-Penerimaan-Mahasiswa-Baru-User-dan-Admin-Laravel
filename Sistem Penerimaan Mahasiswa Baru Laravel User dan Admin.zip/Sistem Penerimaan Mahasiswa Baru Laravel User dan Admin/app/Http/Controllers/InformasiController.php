<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Informasi;

class InformasiController extends Controller
{
    public function index(Request $request)
    {
        $query = Informasi::query();

        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('jnsInformasi', 'LIKE', "%{$search}%")
                    ->orWhere('isi', 'LIKE', "%{$search}%");
            });
        }

        $informasis = $query->orderBy('created_at', 'desc')
            ->paginate(5)
            ->appends($request->query());

        return view('admin.informasi.index', compact('informasis'));
    }

    public function create()
    {
        return view('admin.informasi.create');
    }

    public function store(Request $request)
    {
        // Validasi data
        $request->validate([
            'jnsInformasi' => 'required|string|max:255',
            'isi' => 'required|string',
        ]);

        try {
            // Simpan data ke database
            Informasi::create([
                'jnsInformasi' => $request->jnsInformasi,
                'isi' => $request->isi,
            ]);

            return redirect('/informasi/index')->with('success', 'Data informasi berhasil disimpan.');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Terjadi kesalahan saat menyimpan data.');
        }
    }

    public function edit($id)
    {
        $informasi = Informasi::findOrFail($id);
        return view('admin.informasi.edit', compact('informasi'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'jnsInformasi' => 'required|string|max:255',
            'isi' => 'required|string',
        ]);

        $informasi = Informasi::findOrFail($id);
        $informasi->jnsInformasi = $request->jnsInformasi;
        $informasi->isi = $request->isi;
        $informasi->save();

         return redirect('/informasi/index')->with('success', 'Data berhasil diperbarui.');
    }

    public function destroy($id)
    {
        try {
            $informasi = Informasi::findOrFail($id);
            $informasi->delete();

            return response()->json([
                'success' => true,
                'message' => 'Data informasi berhasil dihapus.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus data informasi.'
            ], 500);
        }
    }

    public function show($id)
    {
        $informasi = Informasi::findOrFail($id);
        return view('admin.informasi.show', compact('informasi'));
    }


}
