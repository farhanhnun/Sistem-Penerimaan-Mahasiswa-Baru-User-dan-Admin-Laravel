<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kecamatan;

class KecamatanController extends Controller
{
    public function index(Request $request)
    {
        $query = Kecamatan::with('kabupaten'); // include relasi kabupaten

        // Filter pencarian berdasarkan nama kecamatan
        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where('namaKecamatan', 'like', '%' . $search . '%')
                  ->orWhereHas('kabupaten', function ($q) use ($search) {
                      $q->where('namaKabupaten', 'like', '%' . $search . '%');
                  });
        }

        $kecamatans = $query->orderBy('namaKecamatan')->paginate(10);

        return view('admin.kecamatan.index', compact('kecamatans'));
    }

   public function create()
    {
        $kabupatens = \App\Models\Kabupaten::orderBy('namaKabupaten')->get();
        return view('admin.kecamatan.create', compact('kabupatens'));
    }


    public function store(Request $request)
    {
        $request->validate([
            'namaKecamatan' => 'required|string|max:255',
            'kabupaten_id' => 'required|exists:kabupatens,id',
        ]);

        try {
            Kecamatan::create([
                'namaKecamatan' => $request->namaKecamatan,
                'kabupaten_id' => $request->kabupaten_id,
            ]);

            return redirect('/kecamatan/index')->with('success', 'Data asal sekolah berhasil disimpan.');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Terjadi kesalahan saat menyimpan data.');
        }
    }

    public function destroy($id)
    {
        try {
            $kecamatan = Kecamatan::findOrFail($id);
            $kecamatan->delete();

            return response()->json([
                'success' => true,
                'message' => 'Data kabupaten berhasil dihapus.'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Gagal menghapus data kabupaten.'
            ], 500);
        }
    }


    public function edit($id)
    {
        $kecamatan = \App\Models\Kecamatan::findOrFail($id); // cari kecamatan berdasarkan ID
        $kabupatens = \App\Models\Kabupaten::orderBy('namaKabupaten')->get(); // ambil semua kabupaten

        return view('admin.kecamatan.edit', compact('kecamatan', 'kabupatens'));
    }

    public function update(Request $request, $id)
    {
        // Validasi input
        $request->validate([
            'namaKecamatan' => 'required|string|max:255',
            'kabupaten_id' => 'required|exists:kabupatens,id',
        ]);

        try {
            $kecamatan = \App\Models\Kecamatan::findOrFail($id);

            // Update data
            $kecamatan->update([
                'namaKecamatan' => $request->namaKecamatan,
                'kabupaten_id' => $request->kabupaten_id,
            ]);

            return redirect('/kecamatan/index')->with('success', 'Data kecamatan berhasil disimpan.');

        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Terjadi kesalahan saat memperbarui data.');
        }
    }

    public function show($id)
    {
        $kecamatan = Kecamatan::with('kabupaten')->findOrFail($id);

        return view('admin.kecamatan.show', compact('kecamatan'));
    }

}
