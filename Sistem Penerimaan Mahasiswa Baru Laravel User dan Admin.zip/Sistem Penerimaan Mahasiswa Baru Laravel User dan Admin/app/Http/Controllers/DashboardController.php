<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CalonMahasiswa; // Pastikan ini ada
use Illuminate\Support\Facades\Auth; // Pastikan ini ada

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // Pastikan user adalah admin untuk dashboard ini
        if (!$user || $user->role !== 'admin') {
            return redirect()->route('login'); // Atau ke halaman lain jika bukan admin
        }

        // Logika untuk Dashboard Admin
        $mahasiswas = CalonMahasiswa::with(['prodi', 'kelas', 'alamat'])->latest()->paginate(10);

        return view('admin.dashboard', compact('mahasiswas'));
    }
}
